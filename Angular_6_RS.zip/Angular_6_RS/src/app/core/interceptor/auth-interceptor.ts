import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { tap } from 'rxjs/operators';
import { Injectable, Injector } from "@angular/core";
import { Router } from "@angular/router";
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { RSAConstants } from '../constants/rsaconstant';
// import { d } from "@angular/core/src/render3";

@Injectable()
export class AuthInterceptor {

    private authservice: AuthService;

    constructor(private router: Router, private injector: Injector) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.authservice = this.injector.get(AuthService);

        if (req.headers.get(RSAConstants.headerNoAuth) == 'True') {
            return next.handle(req.clone());
        } else if (this.authservice.getToken() != null) {
              let clonedreq;
            if (req.headers.has('enctype')) {
                clonedreq = req.clone({
                    headers: req.headers.set(RSAConstants.headerAuthorization, RSAConstants.bearer + this.authservice.getToken())
                        .set('locCode', localStorage.getItem('locationcode'))
                        .set('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS')
                        .set('Access-Control-Allow-Origin', '*')
                   });

            } else {
                clonedreq = req.clone({
                    headers: req.headers.set(RSAConstants.headerAuthorization, RSAConstants.bearer + this.authservice.getToken())
                        .set('locCode', localStorage.getItem('locationcode'))
                        .set('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS')
                        .set('Content-Type', 'application/json; charset=utf-8')
                        .set('Access-Control-Allow-Origin', '*')

                });
            }

            // const clonedreq = req.clone({
            //     headers: req.headers.set(RSAConstants.headerAuthorization, RSAConstants.bearer + this.authservice.getToken())
            //         .set('locCode', localStorage.getItem('locationcode'))
            //         // .set('Content-Type', 'application/json; charset=utf-8')
            //         .set('Content-Type', (!req.headers.get('Content-Type')) ? 'application/json; charset=utf-8' :
            //         req.headers.get('Content-Type'))
            //         .set('Access-Control-Allow-Headers', 'Content-Type,Origin,content-type')
            //         .set('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS')
            //         .set('Access-Control-Allow-Origin', '*')
            // });
            return next.handle(clonedreq)
                .pipe(
                    tap(event => {
                        if (event instanceof HttpResponse) {

                            console.log('response received...');
                        }
                    }, error => {

                        if (error.status === 401) {
                            console.log("interceptor 401");
                            this.authservice.logout();
                        }

                    })

                ); // end of pipe
        } else {
            console.log("interceptor else");
            // this.authservice.logout();
        }
    }
}
