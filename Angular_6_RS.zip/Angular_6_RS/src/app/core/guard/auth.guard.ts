import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private router : Router, 
     private userAutherizationService: UserAutherizationService, 
     private authService: AuthService){}
  
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot):  boolean {

      if (this.authService.getAuthToken() !== null){
        let functionid : any = next.data["functionid"];
        let match : boolean = true;
       
          if (functionid!=null || functionid != undefined) {
               
              match = this.userAutherizationService.isAllowed(functionid);
              if (match) return true;
              else {
                this.router.navigate(['/accessdenied']);
                return false;
              }
            }
          else
            return true;
          }
      else {
      this.router.navigate(['/accessdenied']);
      return false;
    }
  }
}
