import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-technicalerror',
  templateUrl: './technicalerror.component.html',
  styleUrls: ['./technicalerror.component.scss']
})
export class TechnicalErrorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
