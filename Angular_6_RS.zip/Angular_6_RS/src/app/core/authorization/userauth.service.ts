import { Injectable } from '@angular/core';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { AppLoadService } from '../../app-load.service';


@Injectable({
  providedIn: 'root'
})
export class UserAutherizationService {
  allowedfunctionids:any;
  returndata:any;
  constructor(private appService:AppLoadService) { 
 }
 isAllowed(functionid:any): boolean {
   this.allowedfunctionids = this.getAuthorizationFunctionIds();
   let isMatch : boolean = this.allowedfunctionids.includes(functionid);
   return isMatch;

  }
  getAuthorizationFunctionIds(){
    return JSON.parse(localStorage.getItem(RSAConstants.functionids));
  }
  setAuthorizationFunctionIds(data){
    localStorage.setItem(RSAConstants.functionids,JSON.stringify(data));
  }
  clearAuthorizationFunctionIds(){
    return localStorage.removeItem(RSAConstants.functionids)
  }

  
}
