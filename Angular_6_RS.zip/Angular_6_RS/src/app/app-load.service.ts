import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { map, catchError } from 'rxjs/operators';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { UserProfile } from 'src/app/shared/model/userprofile';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AppLoadService {
  returndata:any;
  errormsg:string;
  constructor(private http: HttpClient) { }

  getUserAuthorizationData() {
            
            let params = new HttpParams();
            params = params.append('userName', (this.getUserId()).toString());
            params = params.append('locCode',(this.getLocationCode()).toString());
            const httpHeaders = new HttpHeaders();
            httpHeaders.append('Accept', 'application/json');
            httpHeaders.append('Content-Type', 'application/json');
            httpHeaders.append('Access-Control-Allow-Origin', '*');
            httpHeaders.append('Authorization', RSAConstants.bearer + this.getAuthToken());
           
            return this.http.get(RSAENDPOINTConstants.LOGIN_INTERNAL, { params : params, headers: httpHeaders })
            .pipe(
              map(res => res),
              catchError(this.handleError)
             );   
       
   }
   private handleError(error: HttpErrorResponse | any) {

    if (error instanceof Error) {
      return Observable.throw(error.message || error);
    }
  }
   getAuthToken():string{
     return localStorage.getItem(RSAConstants.token);
    //return '564463472653752735';
   }
   getUserId(){
    return localStorage.getItem('userId');
    //  return 'ravi.kesari@rsame.com';
   }
   getLocationCode(){
     return 13;
   }
   
   getUserData() {
      const httpHeaders = new HttpHeaders();
      httpHeaders.append('Accept', 'application/json');
      httpHeaders.append('Content-Type', 'application/json');
      httpHeaders.append('Access-Control-Allow-Origin', '*');
      httpHeaders.append('Authorization', RSAConstants.bearer + this.getAuthToken());

    return this.http.get<UserProfile>(RSAENDPOINTConstants.USERPROFILE, { headers: httpHeaders }).pipe(
      map(res => res),
      catchError((handleErrorObservable<any>('getUserData'))));
  
  }
}
