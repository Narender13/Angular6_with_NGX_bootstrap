import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DraftEditViewButtonComponent } from 'src/app/finance/drfats/drafts-results/draft-edit-view-button/draft-edit-view-button.component';
import { PendingApprovalEditViewButtonComponent } from 'src/app/finance/pending-approvals/pending-approval-edit-view-button/pending-approval-edit-view-button.component';


@Injectable({
    providedIn: 'root'
})
export class PendingapprovalsAgridService {
    constructor(public datepipe: DatePipe) { }



    getEntityColumnHeaderPropertyNames(vvname) {
        if (vvname == 'Receipts') {
            return [
                {
                    headerName: 'Receipt No',
                    field: 'ReceiptNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Receipt No',
                    headerCheckboxSelection: false,
                    checkboxSelection: true,
                    cellRenderer: 'group',
                    cellRendererParams: { suppressCount: true },
                    headerCheckboxSelectionFilteredOnly: true,

                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Approved By',
                    field: 'AssignedName',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Approved By',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: PendingApprovalEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Receipts'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }
        if (vvname == 'Debit Note') {
            return [
                {
                    headerName: 'Debit No',
                    field: 'DebitNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Debit No',
                    headerCheckboxSelection: false,
                    checkboxSelection: true,
                    // cellRenderer: 'group',
                    cellRendererParams: { suppressCount: true },
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'DebitNoteDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Approved By',
                    field: 'AssignedName',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Approved By',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: PendingApprovalEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Debit Note'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'Credit Note') {
            return [
                {
                    headerName: 'Credit No',
                    field: 'CreditNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Debit No',
                    headerCheckboxSelection: false,
                    checkboxSelection: true,
                    // cellRenderer: 'group',
                    cellRendererParams: { suppressCount: true },
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'CreditNoteDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Approved By',
                    field: 'AssignedName',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Approved By',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByname',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: PendingApprovalEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Credit Note'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'Payments') {
            return [
                {
                    headerName: 'Payment No',
                    field: 'PaymentNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Payment No',
                    headerCheckboxSelection: false,
                    checkboxSelection: true,
                    // cellRenderer: 'group',
                    cellRendererParams: { suppressCount: true },
                    headerCheckboxSelectionFilteredOnly: true,
                },

                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Approved By',
                    field: 'AssignedName',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Approved By',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: PendingApprovalEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Payments'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if (vvname == 'JV') {
            return [
                {
                    headerName: 'JV No',
                    field: 'VoucherNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'JV No',
                    headerCheckboxSelection: false,
                    checkboxSelection: true,
                    // cellRenderer: 'group',
                    cellRendererParams: { suppressCount: true },
                    headerCheckboxSelectionFilteredOnly: true,
                },
                {
                    headerName: 'Description',
                    field: 'Description',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',

                },
                {
                    headerName: 'Approved By',
                    field: 'AssignedName',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Approved By',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Debit',
                    field: 'AmountDrStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Debit',
                },
                {
                    headerName: 'Credit',
                    field: 'AmountCrStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Credit',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: PendingApprovalEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'JV'
                    },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }




    }//fun name



    getMasterData(params, vocherName) {
        if (vocherName == 'JV') {
            console.log(params, 'params');
            const counterpartyRefNo = params.data.CounterPartyRef;
            const recptDesc = params.data.Description;
            const refId = params.data.RefTransactionID;
            const refType = params.data.RefTranType;
            const refTranNo = params.data.RefTransactionSerialNo;
            const dept = params.data.DepartmentName;
            const prInd = params.data.AnalysisCode;
            const placeholder = params.data.PlaceHolder;
            const preBy = params.data.PreparedBy;
            const predate = params.data.PreparedDate;
            const aprBy = params.data.ApprovedBy;
            const aprDate = params.data.ApprovedDate;
            return (
                '<div class="entity-parent">' +
                '<div class="entitie-detail">' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Counter Party Refjv.' +
                '</div>' +
                '<div class="e-title-re">' + counterpartyRefNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Description' +
                '</div>' +
                '<div class="e-title-re">' + recptDesc +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran ID' +
                '</div>' +
                '<div class="e-title-re">' + refId +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tan Type' +
                '</div>' +
                '<div class="e-title-re">' + refType +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran Sl No' +
                '</div>' +
                '<div class="e-title-re">' + refTranNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Department Name' +
                '</div>' +
                '<div class="e-title-re">' + dept +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Project Indicator' +
                '</div>' +
                '<div class="e-title-re">' + prInd +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Place Holder' +
                '</div>' +
                '<div class="e-title-re">' + placeholder +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared Date' +
                '</div>' +
                '<div class="e-title-re">' + predate +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved Date' +
                '</div>' +
                '<div class="e-title-re">' + aprDate +
                '</div>' +
                '</div>' +


                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared By ' +
                '</div>' +
                '<div class="e-title-re">' + preBy +
                '</div>' +
                '</div>' +



                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved By ' +
                '</div>' +
                '<div class="e-title-re">' + aprBy +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        }

        if (vocherName == 'Payments') {
            console.log(params, 'params');
            const counterpartyRefNo = params.data.CounterPartyRef;
            const recptDesc = params.data.Description;
            const refId = params.data.RefTransactionID;
            const refType = params.data.RefTranType;
            const refTranNo = params.data.RefTransactionSerialNo;
            const dept = params.data.DepartmentName;
            const prInd = params.data.AnalysisCode;
            const placeholder = params.data.PlaceHolder;
            const preBy = params.data.PreparedBy;
            const predate = params.data.PreparedDate;
            const aprBy = params.data.ApprovedBy;
            const aprDate = params.data.ApprovedDate;
            return (
                '<div class="entity-parent">' +
                '<div class="entitie-detail">' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Counter Party Ref.' +
                '</div>' +
                '<div class="e-title-re">' + counterpartyRefNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Description' +
                '</div>' +
                '<div class="e-title-re">' + recptDesc +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran ID' +
                '</div>' +
                '<div class="e-title-re">' + refId +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tan Type' +
                '</div>' +
                '<div class="e-title-re">' + refType +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran Sl No' +
                '</div>' +
                '<div class="e-title-re">' + refTranNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Department Name' +
                '</div>' +
                '<div class="e-title-re">' + dept +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Project Indicator' +
                '</div>' +
                '<div class="e-title-re">' + prInd +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Place Holder' +
                '</div>' +
                '<div class="e-title-re">' + placeholder +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared Date' +
                '</div>' +
                '<div class="e-title-re">' + predate +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved Date' +
                '</div>' +
                '<div class="e-title-re">' + aprDate +
                '</div>' +
                '</div>' +


                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared By ' +
                '</div>' +
                '<div class="e-title-re">' + preBy +
                '</div>' +
                '</div>' +



                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved By ' +
                '</div>' +
                '<div class="e-title-re">' + aprBy +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        }

        if (vocherName == 'Credit Note') {
            console.log(params, 'params');
            const counterpartyRefNo = params.data.CounterPartyRef;
            const recptDesc = params.data.Description;
            const refId = params.data.RefTransactionID;
            const refType = params.data.RefTranType;
            const refTranNo = params.data.RefTransactionSerialNo;
            const dept = params.data.DepartmentName;
            const prInd = params.data.AnalysisCode;
            const placeholder = params.data.PlaceHolder;
            const preBy = params.data.PreparedBy;
            const predate = params.data.PreparedDate;
            const aprBy = params.data.ApprovedBy;
            const aprDate = params.data.ApprovedDate;
            return (
                '<div class="entity-parent">' +
                '<div class="entitie-detail">' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Counter Party Ref.' +
                '</div>' +
                '<div class="e-title-re">' + counterpartyRefNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Description' +
                '</div>' +
                '<div class="e-title-re">' + recptDesc +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran ID' +
                '</div>' +
                '<div class="e-title-re">' + refId +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tan Type' +
                '</div>' +
                '<div class="e-title-re">' + refType +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran Sl No' +
                '</div>' +
                '<div class="e-title-re">' + refTranNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Department Name' +
                '</div>' +
                '<div class="e-title-re">' + dept +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Project Indicator' +
                '</div>' +
                '<div class="e-title-re">' + prInd +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Place Holder' +
                '</div>' +
                '<div class="e-title-re">' + placeholder +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared Date' +
                '</div>' +
                '<div class="e-title-re">' + predate +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved Date' +
                '</div>' +
                '<div class="e-title-re">' + aprDate +
                '</div>' +
                '</div>' +


                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared By ' +
                '</div>' +
                '<div class="e-title-re">' + preBy +
                '</div>' +
                '</div>' +



                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved By ' +
                '</div>' +
                '<div class="e-title-re">' + aprBy +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        }

        if (vocherName == 'Receipts') {
            console.log(params, 'params');
            const counterpartyRefNo = params.data.CounterPartyRef;
            const recptDesc = params.data.Description;
            const refId = params.data.RefTransactionID;
            const refType = params.data.RefTranType;
            const refTranNo = params.data.RefTransactionSerialNo;
            const dept = params.data.DepartmentName;
            const prInd = params.data.AnalysisCode;
            const placeholder = params.data.PlaceHolder;
            const preBy = params.data.PreparedBy;
            const predate = params.data.PreparedDate;
            const aprBy = params.data.ApprovedBy;
            const aprDate = params.data.ApprovedDate;
            return (
                '<div class="entity-parent">' +
                '<div class="entitie-detail">' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Counter Party Ref.' +
                '</div>' +
                '<div class="e-title-re">' + counterpartyRefNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Description' +
                '</div>' +
                '<div class="e-title-re">' + recptDesc +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran ID' +
                '</div>' +
                '<div class="e-title-re">' + refId +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tan Type' +
                '</div>' +
                '<div class="e-title-re">' + refType +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran Sl No' +
                '</div>' +
                '<div class="e-title-re">' + refTranNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Department Name' +
                '</div>' +
                '<div class="e-title-re">' + dept +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Project Indicator' +
                '</div>' +
                '<div class="e-title-re">' + prInd +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Place Holder' +
                '</div>' +
                '<div class="e-title-re">' + placeholder +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared Date' +
                '</div>' +
                '<div class="e-title-re">' + predate +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved Date' +
                '</div>' +
                '<div class="e-title-re">' + aprDate +
                '</div>' +
                '</div>' +


                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared By ' +
                '</div>' +
                '<div class="e-title-re">' + preBy +
                '</div>' +
                '</div>' +



                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved By ' +
                '</div>' +
                '<div class="e-title-re">' + aprBy +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        }

        if (vocherName == 'Debit Note') {
            console.log(params, 'params');
            const counterpartyRefNo = params.data.CounterPartyRef;
            const recptDesc = params.data.Description;
            const refId = params.data.RefTransactionID;
            const refType = params.data.RefTranType;
            const refTranNo = params.data.RefTransactionSerialNo;
            const dept = params.data.DepartmentName;
            const prInd = params.data.AnalysisCode;
            const placeholder = params.data.PlaceHolder;
            const preBy = params.data.PreparedBy;
            const predate = params.data.PreparedDate;
            const aprBy = params.data.ApprovedBy;
            const aprDate = params.data.ApprovedDate;
            return (
                '<div class="entity-parent">' +
                '<div class="entitie-detail">' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Counter Party Ref.' +
                '</div>' +
                '<div class="e-title-re">' + counterpartyRefNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Description' +
                '</div>' +
                '<div class="e-title-re">' + recptDesc +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran ID' +
                '</div>' +
                '<div class="e-title-re">' + refId +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tan Type' +
                '</div>' +
                '<div class="e-title-re">' + refType +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +
                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Ref Tran Sl No' +
                '</div>' +
                '<div class="e-title-re">' + refTranNo +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Department Name' +
                '</div>' +
                '<div class="e-title-re">' + dept +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Project Indicator' +
                '</div>' +
                '<div class="e-title-re">' + prInd +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Place Holder' +
                '</div>' +
                '<div class="e-title-re">' + placeholder +
                '</div>' +
                '</div>' +
                '</div>' +

                '<div class="flex-inline row">' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared Date' +
                '</div>' +
                '<div class="e-title-re">' + predate +
                '</div>' +
                '</div>' +

                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved Date' +
                '</div>' +
                '<div class="e-title-re">' + aprDate +
                '</div>' +
                '</div>' +


                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Prepared By ' +
                '</div>' +
                '<div class="e-title-re">' + preBy +
                '</div>' +
                '</div>' +



                '<div class="block col-lg-3 ">' +
                '<div class="e-title">Approved By ' +
                '</div>' +
                '<div class="e-title-re">' + aprBy +
                '</div>' +
                '</div>' +
                '</div>' +
                '</div>'
            );

        }


    }






}

