import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { PendingApprovalsService } from '../services/pendingapprovals.service';
import { SharedService } from '../../services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-approved-reject-dailog',
  templateUrl: './approved-reject-dailog.component.html',
  styleUrls: ['./approved-reject-dailog.component.scss']
})
export class ApprovedRejectDailogComponent implements OnInit {
  isApproved: boolean;
  constructor(private fb: FormBuilder,
    private sharedService: SharedService,
    private modalService: BsModalService,
    private pendingApprovalsService: PendingApprovalsService) { }
  public onClose: Subject<any>;
  approvedform: FormGroup;
  rejectedform: FormGroup;
  dataresult: any;
  voucherNo: any;
  voucherName: string;
  public bsModalRef: BsModalRef;
  userName:string;
  PreparedByName:string;

  ngOnInit() {
    this.approvedform = this.fb.group({
      Comments: [],
      VoucherNo: [this.voucherNo],
      Status: ['Approved'],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
    });
    this.rejectedform = this.fb.group({
      Comments: [],
      VoucherNo: [this.voucherNo],
      Status: ['Rejected'],
      PreparedBy: [localStorage.getItem(RSAConstants.LoggedInUserId)],
    });

    console.log(this.voucherName, 'voucherName');
    console.log(this.PreparedByName, 'PreparedByName');

    this.userName = localStorage.getItem('userName');
    
  }

  closePendingOrRejected(ev) {
    const approved = ev;
    if (approved) {
      console.log(this.approvedform.value, 'this.approvedform.value');
      if (this.voucherName == 'Receipts') {
        this.pendingApprovalsService.pendingRejectApprovalReceipt(this.approvedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Debit Note') {
        this.pendingApprovalsService.pendingRejectApprovalDebitNote(this.approvedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Credit Note') {
        this.pendingApprovalsService.pendingRejectApprovalCreditNote(this.approvedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Payments') {
        this.pendingApprovalsService.pendingRejectApprovalPayment(this.approvedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'JV') {
        this.pendingApprovalsService.pendingRejectApprovalJv(this.approvedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
    } else {
      if (this.voucherName == 'Receipts') {
        this.pendingApprovalsService.pendingRejectApprovalReceipt(this.rejectedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Debit Note') {
        this.pendingApprovalsService.pendingRejectApprovalDebitNote(this.rejectedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Credit Note') {
        this.pendingApprovalsService.pendingRejectApprovalCreditNote(this.rejectedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'Payments') {
        this.pendingApprovalsService.pendingRejectApprovalPayment(this.rejectedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
      if (this.voucherName == 'JV') {
        this.pendingApprovalsService.pendingRejectApprovalJv(this.rejectedform.value).subscribe(val => {
          if (val) {
            this.sharedService.sendMessage({
              res: 'refreshgrid',
              voucherName: this.voucherName,
            });
          }
        });
      }
    }
    this.modalService.hide(1);
    this.sharedService.sendMessage('close-approve-rejected-window');
  }


}

