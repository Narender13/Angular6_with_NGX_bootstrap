import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { SharedService } from '../../services/shared.service';
import { PendingApprovalsService } from '../services/pendingapprovals.service';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';


@Component({
  selector: 'rsa-debitnote-pending-approvals',
  templateUrl: './debitnote-pending-approvals.component.html',
  styleUrls: ['./debitnote-pending-approvals.component.scss']
})
export class DebitnotePendingApprovalsComponent implements OnInit {

  @Input() debitnotePendingApprovalData: any = [];
  @Input() VName: string;
  constructor(private modalService: BsModalService,
    private sharedService: SharedService, private pendingApprovalService: PendingApprovalsService) { }

  ngOnInit() {
    console.log(this.debitnotePendingApprovalData, 'debitnotePendingApprovalData-cpomp');
  }

}

