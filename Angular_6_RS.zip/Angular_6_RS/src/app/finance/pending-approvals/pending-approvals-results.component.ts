import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PendingApprovalsService } from './services/pendingapprovals.service';
import { SharedService } from '../services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';


@Component({
  selector: 'rsa-pending-approvals-results',
  templateUrl: './pending-approvals-results.component.html',
  styleUrls: ['./pending-approvals-results.component.scss']
})
export class PendingApprovalsResultsComponent implements OnInit {

  voucherName;
  voucherCount;
  receiptPendingApprovalsData: any = [];
  debitnotePendingApprovalsData: any = [];
  creditnotePendingApprovalsData: any = [];
  paymentPendingApprovalsData: any = [];
  JournalPendingApprovalsData: any = [];

  constructor(private route: ActivatedRoute,
    private sharedService: SharedService, private pendingApprovalService: PendingApprovalsService) { }
  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      this.voucherName = params['voucherName'];
      this.voucherCount = params['voucherCount'];
      this.getPendingAprovalDetails(this.voucherName);
    });
    this.refreshGridOnFinalize();
  }

  refreshGridOnFinalize() {
    this.sharedService.getMessage().subscribe((data) => {
      console.log(data, 'datapendingapproval');
      const voucherName = data.voucherName;
      const message = data.res;
      console.log(voucherName, message, 'voucherName message');
      if (message === 'refreshgrid') {
        this.getPendingAprovalDetails(voucherName);
      }
    });
  }

  getPendingAprovalDetails(voucherName) {
    console.log(voucherName);
    if (voucherName == 'Receipts') {
      this.getPendingApprovalsReceipt();
    }
    if (voucherName == 'Debit Note') {
      this.getPendingApprovalsDebitnote();
    }
    if (voucherName == 'Credit Note') {
      this.getPendingApprovalsCreditnote();
    }
    if (voucherName == 'Payments') {
      this.getPendingApprovalsPayment();
    }
    if (voucherName == 'JV') {
      this.getPendingApprovalsJournal();
    }

  }

  getPendingApprovalsReceipt() {
    const param = 'type=Pending&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    console.log(param, "paramss...");
    this.pendingApprovalService.getPendingApprovalsReceipts(param).subscribe(data => {
      this.receiptPendingApprovalsData = data;
      console.log(this.receiptPendingApprovalsData, "ReceiptData");
    });
  }

  getPendingApprovalsDebitnote() {
    const param = 'type=Pending&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.pendingApprovalService.getPendingApprovalDebitnotes(param).subscribe(data => {
      this.debitnotePendingApprovalsData = data;
      console.log(data, 'Dndata');

    });
  }

  getPendingApprovalsCreditnote() {
    const param = 'type=Pending&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.pendingApprovalService.getPendingApprovalCreditnotes(param).subscribe(data => {
      this.creditnotePendingApprovalsData = data;
      console.log(data, 'Cndata...');
    });
  }

  getPendingApprovalsPayment() {
    const param = 'type=Pending&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.pendingApprovalService.getPendingApprovalPayments(param).subscribe(data => {
      this.paymentPendingApprovalsData = data;
      console.log(data, 'payment Data');
    });
  }


  getPendingApprovalsJournal() {
    const param = 'type=Pending&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.pendingApprovalService.getPendingApprovalJournals(param).subscribe(data => {
      this.JournalPendingApprovalsData = data;
      console.log(data, 'jvdata');
    });
  }


}




