import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { PendingApprovalsService } from '../services/pendingapprovals.service';
import { SharedService } from '../../services/shared.service';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-payment-pending-approvals',
  templateUrl: './payment-pending-approvals.component.html',
  styleUrls: ['./payment-pending-approvals.component.scss']
})
export class PaymentPendingApprovalsComponent implements OnInit {

  @Input() paymentPendingApprovalData: any = [];
  @Input() VName: string;
  constructor(private modalService: BsModalService,
    private sharedService: SharedService, private pendingApprovalService: PendingApprovalsService) { }


  ngOnInit() {
    console.log(this.paymentPendingApprovalData, 'paymentPendingApprovalsData-cpomp');
  }



}

