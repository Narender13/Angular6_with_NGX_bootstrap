import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
import { DrfatService } from 'src/app/finance/drfats/drafts-results/services/drafts.service';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';
import { CreateDraftDebitnoteComponent } from '../../../drfats/drafts-results/create-draft-debitnote/create-draft-debitnote.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';
import { CreateDraftCreditnoteComponent } from '../../../drfats/drafts-results/create-draft-creditnote/create-draft-creditnote.component';
import { PaymentpreviewComponent } from 'src/app/finance/preview/uae/paymentpreview/paymentpreview.component';
import { CreateDraftPaymentComponent } from '../../../drfats/drafts-results/create-draft-payment/create-draft-payment.component';
import { JvpreviewComponent } from 'src/app/finance/preview/uae/jvpreview/jvpreview.component';
import { CreateDraftJournalComponent } from 'src/app/finance/drfats/drafts-results/create-draft-journal/create-draft-journal.component';
import { CreatejvComponent } from 'src/app/finance/createjv/createjv.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';




@Component({
  selector: 'rsa-draft-edit-view-button',
  templateUrl: './draft-edit-view-button.component.html',
  styleUrls: ['./draft-edit-view-button.component.scss']
})
export class DraftEditViewButtonComponent implements ICellRendererAngularComp {
  public params: any;
  bsModalRef: BsModalRef;
  receiptData: any;
  debitenoteData: any;
  creditnoteData: any;
  paymentData: any;
  jvData: any;

  receiptNo;
  debitNoteNo;
  creditNoteNo;
  paymentNo;
  VoucherNo;
  receiptDetailData: any = [];
  debitenoteDetailData: any = [];
  creditnoteDetailData: any = [];
  paymentDetailData: any = [];
  jvDetailData: any = [];

  viewreceipt:boolean;
  editreceipt:boolean;
  viewdn:boolean;
  editdn:boolean;
  viewcn:boolean;
  editcn:boolean;
  viewpayment:boolean;
  editpayment:boolean;
  viewjv:boolean;
  editjv:boolean;


  voucherName: string;
  constructor(private allowAccess: UserAutherizationService, private modalService: BsModalService, private drfatService: DrfatService) { }

  agInit(params: any): void {
    this.params = params;
    this.receiptNo = this.params.context.componentParent.methodFromParent(this.params.data.ReceiptNo);
    this.debitNoteNo = this.params.context.componentParent.methodFromParent(this.params.data.DebitNoteNo);
    this.creditNoteNo = this.params.context.componentParent.methodFromParent(this.params.data.CreditNoteNo);
    this.paymentNo = this.params.context.componentParent.methodFromParent(this.params.data.PaymentNo);
    this.VoucherNo = this.params.context.componentParent.methodFromParent(this.params.data.VoucherNo);

    this.voucherName = params.inActoionLink;

    this.viewreceipt = this.displayTaskItem(265);
    this.editreceipt = this.displayTaskItem(266);
    this.viewdn = this.displayTaskItem(265);
    this.editdn = this.displayTaskItem(266);
    this.viewcn = this.displayTaskItem(265);
    this.editcn = this.displayTaskItem(266);
    this.viewpayment = this.displayTaskItem(265);
    this.editpayment = this.displayTaskItem(266);
    this.viewjv = this.displayTaskItem(265);
    this.editjv =  this.displayTaskItem(266);


  }


  viewReceipt() {
    
    this.drfatService.getDraftReceipt(this.receiptNo).subscribe((data) => {
      this.receiptDetailData = data;
      this.receiptDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.receiptDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editReceipt() {
   // alert('anki');
    this.drfatService.getDraftReceipt(this.receiptNo).subscribe((data) => {
      this.receiptDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        receiptEditData: this.receiptDetailData,
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftReceiptComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });

  }

  viewDebitNote() {
    this.drfatService.getDrfatsDebitnote(this.debitNoteNo).subscribe((data) => {
      this.debitenoteDetailData = data;
      this.debitenoteDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.debitenoteDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editDebitNote() {
    this.drfatService.getDrfatsDebitnote(this.debitNoteNo).subscribe((data) => {
      this.debitenoteDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        debitnoteEditData: this.debitenoteDetailData,
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftDebitnoteComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });

  }


  viewCreditNote() {

    this.drfatService.getDrfatsCreditnote(this.creditNoteNo).subscribe((data) => {
      this.creditnoteDetailData = data;

      this.creditnoteDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.creditnoteDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editCreditNote() {
    this.drfatService.getDrfatsCreditnote(this.creditNoteNo).subscribe((data) => {
      this.creditnoteDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        creditnoteEditData: this.creditnoteDetailData,
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftCreditnoteComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });
  }

  viewPayment() {
    this.drfatService.getDrfatsPayment(this.paymentNo).subscribe((data) => {
      this.paymentDetailData = data;
      this.paymentDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.paymentDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }
  //Claim Payment 
  viewClmPayment() {
    this.drfatService.getClmPayment(this.paymentNo).subscribe((data) => {
      this.paymentDetailData = data;
      this.paymentDetailData['fromDraftView'] = 'true';
      this.bsModalRef = this.modalService.show(PaymentpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.paymentDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.claimPayment = true;
      this.bsModalRef.content.isView = true;
      this.bsModalRef.content.isDraft =true;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editPayment() {
    this.drfatService.getDrfatsPayment(this.paymentNo).subscribe((data) => {
      this.paymentDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        paymentEditData: this.paymentDetailData,
        claimPayment: false
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreateDraftPaymentComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });
  }
  editClmPayment() {
    this.drfatService.getClmPayment(this.paymentNo).subscribe((data) => {
      this.paymentDetailData = data;
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        paymentEditData: this.paymentDetailData,
        claimPayment: true
      };
      this.bsModalRef = this.modalService.show(CreateDraftPaymentComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });
  }

  viewJv() {
    this.drfatService.getDrfatsJournal(this.VoucherNo).subscribe((data) => {
      this.paymentDetailData = data;
      this.paymentDetailData['fromDraftView'] = 'true';
      console.log(data, 'detaildata');
      this.bsModalRef = this.modalService.show(JvpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
      this.bsModalRef.content.data = this.paymentDetailData;
      this.bsModalRef.content.totalAmount = this.params.data.TotalAmount;
      this.bsModalRef.content.backdrop = true;
    });
  }

  editJv() {
    this.drfatService.getDrfatsJournal(this.VoucherNo).subscribe((data) => {
      this.jvDetailData = data;
      console.log('this.jvDetailData', this.jvDetailData);
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: true,
        jvEditData: this.jvDetailData,
        fromDraft: true
      };
      console.log('initialState:', initialState);
      this.bsModalRef = this.modalService.show(CreatejvComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: true });
    });
  }

  refresh(): boolean {
    return false;
  }
  displayTaskItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }
}
