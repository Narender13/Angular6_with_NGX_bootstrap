import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { CreateDraftJournalComponent } from 'src/app/finance/drfats/drafts-results/create-draft-journal/create-draft-journal.component';
import { JvpreviewComponent } from 'src/app/finance/preview/uae/jvpreview/jvpreview.component';

@Component({
  selector: 'rsa-journal-drafts',
  templateUrl: './journal-drafts.component.html',
  styleUrls: ['./journal-drafts.component.scss']
})
export class JournalDraftsComponent implements OnInit {

  @Input() JournalDraftData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }

  ngOnInit() {
   console.log(this.JournalDraftData, 'JournalDraftData-cpomp');
  }
}
