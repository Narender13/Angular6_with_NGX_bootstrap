import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DraftEditViewButtonComponent } from 'src/app/finance/drfats/drafts-results/draft-edit-view-button/draft-edit-view-button.component';


@Injectable({
    providedIn: 'root'
})
export class DrfatAgridService {
    constructor(public datepipe: DatePipe) { }

    // getEntityColumnHeaderPropertyNames() {
    //     return [
    //         {
    //             headerName: 'Receipt No',
    //             field: 'ReceiptNo',
    //             type: 'numberColumn',
    //             filter: 'agTextColumnFilter',
    //             filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
    //             headerTooltip: 'Receipt No',
    //         },
    //         {
    //             headerName: 'Description',
    //             field: 'EnglishDescription',
    //             filter: 'agTextColumnFilter',
    //             headerTooltip: 'Description',
    //         },
    //         {
    //             headerName: 'Transaction Date (dd/mm/yyyy)',
    //             field: 'TransactionDate',
    //             filter: 'agDateColumnFilter',
    //             filterParams: {
    //                 comparator: function (filterLocalDateAtMidnight, cellValue) {
    //                     const dateAsString = cellValue;
    //                     if (dateAsString == null) {
    //                         return -1;
    //                     }
    //                     const dateParts = dateAsString.split('/');
    //                     const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
    //                     if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
    //                         return 0;
    //                     }
    //                     if (cellDate < filterLocalDateAtMidnight) {
    //                         return -1;
    //                     }
    //                     if (cellDate > filterLocalDateAtMidnight) {
    //                         return 1;
    //                     }
    //                 },
    //                 browserDatePicker: true
    //             },
    //             headerTooltip: 'Transaction Date',

    //         },
    //         {
    //             headerName: 'Status',
    //             field: 'Status',
    //             filter: 'agSetColumnFilter',
    //             headerTooltip: 'Status',
    //         },
    //         {
    //             headerName: 'Prepared By',
    //             field: 'PreparedByName',
    //             filter: 'agTextColumnFilter',
    //             headerTooltip: 'Prepared By',
    //         },
    //         {
    //             headerName: 'Amount',
    //             field: 'AmountStr',
    //             filter: 'agTextColumnFilter',
    //             headerTooltip: 'Amount',
    //         },
    //         {
    //             headerName: 'Action',
    //             field: 'value',
    //             cellRendererFramework: DraftEditViewButtonComponent,
    //             colId: 'params',
    //             filter: 'none',
    //             headerClass: 'hidefilter'
    //         }
    //     ];
    // }

    getEntityColumnHeaderPropertyNames(vvname) {
        if(vvname == 'Receipts'){
            return [
            {
                headerName: 'Receipt No',
                field: 'ReceiptNo',
                type: 'numberColumn',
                filter: 'agTextColumnFilter',
                filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                headerTooltip: 'Receipt No',
            },
            {
                headerName: 'Description',
                field: 'EnglishDescription',
                filter: 'agTextColumnFilter',
                headerTooltip: 'Description',
            },
            {
                headerName: 'Transaction Date (dd/mm/yyyy)',
                field: 'TransactionDate',
                filter: 'agDateColumnFilter',
                filterParams: {
                    comparator: function (filterLocalDateAtMidnight, cellValue) {
                        const dateAsString = cellValue;
                        if (dateAsString == null) {
                            return -1;
                        }
                        const dateParts = dateAsString.split('/');
                        const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                        if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                            return 0;
                        }
                        if (cellDate < filterLocalDateAtMidnight) {
                            return -1;
                        }
                        if (cellDate > filterLocalDateAtMidnight) {
                            return 1;
                        }
                    },
                    browserDatePicker: true
                },
                headerTooltip: 'Transaction Date',

            },
            {
                headerName: 'Status',
                field: 'Status',
                filter: 'agSetColumnFilter',
                headerTooltip: 'Status',
            },
            {
                headerName: 'Prepared By',
                field: 'PreparedByName',
                filter: 'agTextColumnFilter',
                headerTooltip: 'Prepared By',
            },
            {
                headerName: 'Amount',
                type: 'numericColumn',
                field: 'AmountStr',
                filter: 'agTextColumnFilter',
                cellStyle: { 'text-align': 'right' },
                headerTooltip: 'Amount',
            },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: DraftEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'Receipts'
                  },
                colId: 'params',
                filter: 'none',
                headerClass: 'hidefilter'
            }
        ];

        }

        if (vvname == 'Tax Invoice') {
            return [
                {
                    headerName: 'Tax Invoice No',
                    field: 'DebitNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Debit No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'DebitNoteDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',
    
                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Tax Invoice'
                      },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

          if(vvname == 'Credit Note'){
            return [
                {
                    headerName: 'Credit No',
                    field: 'CreditNoteNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Debit No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'CreditNoteDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',
    
                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByname',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'Credit Note'
                      },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if(vvname == 'Payments' || vvname == 'Claim Payments' ){
            return [
                {
                    headerName: 'Payment No',
                    field: 'PaymentNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'Payment No',
                },
                {
                    headerName: 'Description',
                    field: 'EnglishDescription',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',
    
                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Amount',
                    type: 'numericColumn',
                    field: 'AmountStr',
                    filter: 'agTextColumnFilter',
                    cellStyle: { 'text-align': 'right' },
                    headerTooltip: 'Amount',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                       // inActoionLink: 'Claim Payments'
                        inActoionLink: vvname === 'Claim Payments' ? 'Claim Payments' : 'Payments'
                      },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        if(vvname == 'JV'){
            return [
                {
                    headerName: 'JV No',
                    field: 'VoucherNo',
                    type: 'numberColumn',
                    filter: 'agTextColumnFilter',
                    filterParams: { selectAllOnMiniFilter: true, cellHeight: 30, },
                    headerTooltip: 'JV No',
                },
                {
                    headerName: 'Description',
                    field: 'Description',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Description',
                },
                {
                    headerName: 'Transaction Date (dd/mm/yyyy)',
                    field: 'TransactionDate',
                    filter: 'agDateColumnFilter',
                    filterParams: {
                        comparator: function (filterLocalDateAtMidnight, cellValue) {
                            const dateAsString = cellValue;
                            if (dateAsString == null) {
                                return -1;
                            }
                            const dateParts = dateAsString.split('/');
                            const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
                            if (filterLocalDateAtMidnight.getTime() == cellDate.getTime()) {
                                return 0;
                            }
                            if (cellDate < filterLocalDateAtMidnight) {
                                return -1;
                            }
                            if (cellDate > filterLocalDateAtMidnight) {
                                return 1;
                            }
                        },
                        browserDatePicker: true
                    },
                    headerTooltip: 'Transaction Date',
    
                },
                {
                    headerName: 'Status',
                    field: 'Status',
                    filter: 'agSetColumnFilter',
                    headerTooltip: 'Status',
                },
                {
                    headerName: 'Prepared By',
                    field: 'PreparedByName',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Prepared By',
                },
                {
                    headerName: 'Debit',
                    type: 'numericColumn',
                    field: 'AmountDrStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Debit',
                },
                {
                    headerName: 'Credit',
                    type: 'numericColumn',
                    field: 'AmountCrStr',
                    filter: 'agTextColumnFilter',
                    headerTooltip: 'Credit',
                },
                {
                    headerName: 'Action',
                    field: 'value',
                    cellRendererFramework: DraftEditViewButtonComponent,
                    cellRendererParams: {
                        inActoionLink: 'JV'
                      },
                    colId: 'params',
                    filter: 'none',
                    headerClass: 'hidefilter'
                }
            ];

        }

        
      
       
    }//fun name


    



}
