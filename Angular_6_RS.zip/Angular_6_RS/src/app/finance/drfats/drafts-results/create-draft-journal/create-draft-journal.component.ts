import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-draft-journal',
  templateUrl: './create-draft-journal.component.html',
  styleUrls: ['./create-draft-journal.component.scss']
})
export class CreateDraftJournalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
