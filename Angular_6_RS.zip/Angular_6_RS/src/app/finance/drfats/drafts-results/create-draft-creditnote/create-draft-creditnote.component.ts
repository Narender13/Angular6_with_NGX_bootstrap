import { Component, OnInit, ViewChild } from '@angular/core';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { TabsetComponent } from 'ngx-bootstrap/tabs';
import { CreateReceipt } from 'src/app/finance/search/model/create-receipt';
import { UtilityClass } from 'src/app/shared/utilites/helper-class';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { CreateCreditNotes } from 'src/app/finance/creditnotes/create-creditnotes/model/create-cn';
import { BasevoucherComponent } from 'src/app/finance/basevoucher/basevoucher.component';
import { CreateCreditnotesService } from 'src/app/finance/creditnotes/create-creditnotes/service/create-creditnotes.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';
import { CnpreviewComponent } from 'src/app/finance/preview/uae/cnpreview/cnpreview.component';

@Component({
  selector: 'rsa-create-draft-creditnote',
  templateUrl: './create-draft-creditnote.component.html',
  styleUrls: ['./create-draft-creditnote.component.scss']
})
export class CreateDraftCreditnoteComponent extends BasevoucherComponent implements OnInit {
  title = 'Credit Note';
  currency = 'AED';
  errorpayee: boolean;
  errordetail: boolean;
  errorglCode: boolean;
  /* form error-feilds */
  errorbankcodeCheque: boolean;
  level: any = 2;
  errorbankcodeBanktransfer: boolean;
  errorpaayeebanknameCheque: boolean;
  errorpaayeebanknameBanktransfer: boolean;
  errorchequedateCheque: boolean;
  errorchequedateBankT: boolean;
  errorchequedateCreditCard: boolean;
  errorchequenoCheque: boolean;
  errorchequenoCreditCard: boolean;
  errorterminalID: boolean;
  errorexpirydate: boolean;
  matchedRecords = [];
  isUploadUnmatched;
  returnValue: any;
  usersReq;
  symbol;
  glAcountHeader: any = [];
  createCreditNotes: CreateCreditNotes;
  animatedClass = true;
  selectedRowItem: any = [];
  creditnoteEditData: any = [];
  customerName: string = "";
  ondemandFlag: boolean = false;
  ondemandFlagClaim = true;
  formArray: any;
  isCreditNote;
  unApproved;

  @ViewChild('tabset') tabset: TabsetComponent;

  constructor(
    protected sharedService: SharedService,
    private fb: FormBuilder,
    protected modalService: BsModalService,
    protected bsModalRef: BsModalRef,
    protected masterDataService: MasterDataService,
    protected utilityClass: UtilityClass,
    protected createPaymentService: CreateCreditnotesService,
    private alertService: AlertService,
  ) {
    super(masterDataService, sharedService, modalService, utilityClass, bsModalRef);
    super.setMinMaxDate();
  }
  ngOnInit() {
    /* super with method is calling from BasevoucherComponent */
    this.createVoucherForm(this.paymentMode);
    super.getAllBranchData();
    super.getAllCostCenterData({ ev: null, index: 0, flag: true });
    super.getAllTotallingData(true);
    super.getAllProjData();
    super.getAllDeptData();
    super.getAllMasterData2();
    this.fieldStatusChanges();
    super.getModelPreviousClose();
    super.closeModel();
    super.getAllTranData();
    this.symbol = (localStorage.getItem('symbol'));
    super.setMinMaxDate();
    this.getGlAccountHeader();
    this.getDetailsArrayFormGroup();
    super.getModelPreviousClose();
    super.getAllgetLookupBanksData();
    // console.log(this.selectedRowItem, 'selectedRowItem');
    super.getTotalingHeaderDataCnDn();
    const totcode = this.creditnoteEditData.TotallingAccCode;
    super.getGlAccountHeaderDataCnDn(totcode);
    this.getActualAmountSum('CN');
    this.setHeaderData();
    console.log(this.creditnoteEditData, 'creditnoteEditData');
  }

  /* create entiti form */
  createVoucherForm(param): void {
    this.mainVoucherForm = null;
    let tranDate = localStorage.getItem('tranAccntMnthStrtDate') ? new Date(localStorage.getItem('tranAccntMnthStrtDate')) : new Date();
    this.mainVoucherForm = this.fb.group({
      VoucherDate: [new DatePipe('en-US').transform(tranDate, 'dd/MM/yyyy')],
      ApprovedBy: [],
      ArabicDescription: [],
      Amount: [''],
      CountryCode: [1],
      CustomerID: [],
      CustCode: [],
      ModifiedBy: ['1'],
      ModifiedDate: [],
      PreparedBy: [1],
      PreparedDate: [],
      ReprintNo: [],
      PrintDate: [],
      RefreshDate: [],
      PostedDate: [],
      PreprintNo: [],
      Title: ['CREDIT NOTE'],
      RegionCode: [localStorage.getItem('regioncode')],
      Approvers: this.fb.array([]),
      detailInfo: this.fb.group({
        PayeeName: [this.customerName, Validators.required],
        EnglishDescription: ['', Validators.required],
      }),
      accountInfo: this.fb.group({
        LocationCode: [localStorage.getItem('locationcode')],
        CostCenterCode: [localStorage.getItem('costcentre')],
        TotallingAccCode: [1110],
        GLCode: [4, Validators.required],
        GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required]
      }),
      VoucherDetails: this.fb.array([])
    });
  }

  getGLdataCnDn(ev) {
    const totcode = ev.ev;
    console.log(totcode, 'totcode');
    super.getGlAccountHeaderDataCnDn(totcode);
  }
  setHeaderData() {
    this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue(this.creditnoteEditData.TotallingAccCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCode.setValue(this.creditnoteEditData.GLCode);
    this.mainVoucherForm.controls.accountInfo['controls'].GLCodeDesc.setValue(this.creditnoteEditData.GLCodeDesc);
    this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.setValue(this.creditnoteEditData.PayeeName);
    this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.setValue(this.creditnoteEditData.EnglishDescription);
  }
  getDetailsArrayFormGroup() {
    console.log('creditnoteEditData>>>', this.creditnoteEditData.CreditNoteDetail);
    this.selectedRowItem = this.creditnoteEditData.CreditNoteDetail;

    let control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    if (!this.ondemandFlag) {
      this.mainVoucherForm.controls['CustomerID'].setValue(this.creditnoteEditData.CustomerID);
      this.mainVoucherForm.controls['CustCode'].setValue(this.creditnoteEditData.CustCode);

      console.log(this.selectedRowItem, 'this.selectedRowItem');
      this.selectedRowItem.map((item, index) => {
        super.getAllCostCenterData({ ev: null, index: index, flag: true });
        let group = this.createDetailsArrayGroup();
        group.patchValue(item);
        group.get("newAddedRow").setValue(false);
        group.get('IsDebitEntry').setValue((parseFloat(group.get("Amount").value) < 0) ? false : true);
        control.push(group);
      });
    }
    // if (!this.ondemandFlagClaim) {
    //   console.log(this.selectedRowItem, 'this.selectedRowItem');
    //   this.selectedRowItem.map(item => {
    //     let group = this.createDetailsArrayGroup();
    //     group.patchValue(item);
    //     group.get("newAddedRow").setValue(false);
    //     control.push(group);
    //   });
    // } 
    else {
      control.push(this.createDetailsArrayGroup());
    }
  }

  /* form array for recept details */
  createDetailsArrayGroup(): FormGroup {
    return this.fb.group({
      Amount: ['', Validators.required],
      AnalysisCode: [],
      CostCenterCode: [localStorage.getItem('costcentre')],
      ClaimID: [],
      ClassCode: [],
      CauseOfLossCode: [],
      CounterPartyRef: [],
      CountryCode: [1],
      Description: [],
      DocumentCode: [],
      EntityID: [],
      GLCode: [4, Validators.required],
      GLCodeDesc: ['4-HSBC BANK MIDDLE EAST - Deira', Validators.required],
      LocationCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      ModifiedBy: ['1'],
      ModifiedDate: [],
      NatureOfLossCode: [],
      PolicyID: [],
      PolicyYear: [],
      PreparedBy: [],
      PreparedDate: [],
      RefTransactionID: [],
      RefTransactionSerialNo: [],
      RefTransactionType: [10],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [1110],
      PolicyType: [],
      newAddedRow: true,
      VoucherNo: [],
      IsDebitEntry: [true],
      SerialNo: [],
      Department: [],
      DepartmentCode: [],
      CNVATAmount: []
    });
  }

  /* set receipt mode and set default values   */
  setReceiptMode(val, paymentname) {
    this.mainVoucherForm.controls['PaymentMode'].setValue(val);
    this.paymentMode = val;
    this.paymentname = paymentname;
    this.createVoucherForm(this.paymentMode);
    this.receiverdataBankName = this.cachedReceiverBankData;
    this.totallingacc = this.cachedTotAcc;
    this.payeedataBankName = this.cachedPayeeBankData;
    if (this.paymentMode == 1) {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1210');
    } else {
      this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.setValue('1110');
      // this.mainVoucherForm.controls.accountInfo['controls'].RecevierBankCode.setValue('14');
    }
    this.setdefaultHeaderData();
    this.fieldStatusChanges();
  }


  /* using req fields and update status  */
  fieldStatusChanges() {
    this.clearerrors();
    this.cshpayeename.statusChanges.subscribe(
      status => {
        this.errorpayee = (status === 'INVALID');
        console.log(this.errorpayee, 'his.errorpayee');
      }
    );
    this.cshdetails.statusChanges.subscribe(
      status => {
        this.errordetail = (status === 'INVALID');
      }
    );

    // this.glCodeValue.statusChanges.subscribe(
    //   status => {
    //     this.errorglCode = (status === 'INVALID');
    //   }
    // );

  }
  getActualAmountSum(processFlag) {
    let total = 0;
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        console.log('flagtoggle:' + flagtoggle + ',amt:' + amt + ',actualamt:' + actualamt);
        total = total + actualamt;
      }
    });
    this.totalAmount = total;
  }
  updateDetailsAmount(processFlag) {
    let amt = 0;
    let actualamt = 0;
    let flagtoggle = true;
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.forEach((element, index) => {

      if (this.getFromFormArrayControlVal('Amount', index) != undefined
        && this.getFromFormArrayControlVal('Amount', index) != null) {
        flagtoggle = this.getFromFormArrayControlVal('IsDebitEntry', index);
        amt = parseFloat(this.getFromFormArrayControlVal('Amount', index));
        amt = Math.abs(amt);
        if (processFlag == 'CN') {
          actualamt = (flagtoggle) ? amt : (amt * -1);
        }
        this.setFormArrayCTRLDefaultValue('Amount', index, actualamt);
      }
    });
  }
  setDebitEntry(ev) {
    console.log(ev, '<<<<key');
    const actualData = Number(ev.data.controls['Amount'].value);

    if (actualData === 0 || actualData === undefined) {
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.EMPTYAMOUNTCHECK,
        'btnaction': RSAMSGConstants.OKTEXT
      });
      ev.event.target.checked = false;

    }
    this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, ev.event.target.checked);
    this.getActualAmountSum('CN');
    if (this.totalAmount < 0) {
      ev.event.target.checked = true;
      this.setFormArrayCTRLDefaultValue(ev.isDebit, ev.index, true);
      this.displayAlertModal({
        'title': RSAMSGConstants.MODELTITLE,
        'txt': RSAMSGConstants.CREDITEXCEEDMSG,
        'btnaction': RSAMSGConstants.OKTEXT
      });
    }
    this.getActualAmountSum('CN');
  }

  /* clear all errors after reset   */
  clearerrors() {
    this.errorpayee = false;
    this.errordetail = false;
    // this.errorglCode = false;
  }

  /* get the controls of each fields   */
  get cshpayeename() { return this.mainVoucherForm.controls.detailInfo['controls'].PayeeName; }
  get cshdetails() { return this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription; }
  //get glCodeValue() { return this.mainVoucherForm.controls.detailInfo['controls'].GLCode; }


  /* set Description in receptdetails desc   */
  setDescription() {
    (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[0].get('Description').setValue(this.cshdetails.value);
  }


  /* add receipt in review screen */
  addReceipt(len, newRow) {
    console.log(newRow);
    const control = <FormArray>this.mainVoucherForm.controls['VoucherDetails'];
    const CurrentAmount = (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls[len - 1].get('Amount').value;
    if (newRow) {
      if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined) {
        control.push(this.createDetailsArrayGroup());
        this.setFormArrayCTRLDefaultValue('GLCode', len, 4);
        this.setFormArrayCTRLDefaultValue('GLCodeDesc', len, '4-HSBC BANK MIDDLE EAST - Deira');
        this.dtltotallingacc[len] = this.cachedDtlTot;
        this.glaccount[len] = this.cachedGL;
      } else {
        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md' });
        this.bsModalRef.content.modelTitle = RSAMSGConstants.MODELTITLE;
        this.bsModalRef.content.modelBodyContent = RSAMSGConstants.AMOUNTVALIDATIONMSG;
        this.bsModalRef.content.cancelBtn = RSAMSGConstants.OKTEXT;
        return false;
      }
    }

    // if (newRow){
    //   if (CurrentAmount != null && CurrentAmount != 0 && CurrentAmount != undefined){}
    // }
  }



  reSetForm(params) {
    const param = params.defaultParam;
    /*set default value here and reset */
    if (param == 1) {
      super.validateAllFormFields(this.mainVoucherForm);
      this.mainVoucherForm.controls.VoucherDate.setValue([new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy')]);
      this.mainVoucherForm.controls.GLCode.setValue(4);
      this.mainVoucherForm.controls.GLCodeDesc.setValue('4-HSBC BANK MIDDLE EAST - Deira');
      this.clearerrors();
    } else if (param == 2) {
      this.mainVoucherForm.controls['VoucherDetails'].reset();
      (<FormArray>this.mainVoucherForm.controls['VoucherDetails']).controls.map(item => {
        item.get('LocationCode').setValue([localStorage.getItem('locationcode')]);
        item.get('CostCenterCode').setValue([localStorage.getItem('costcentre')]);
        item.get('RefTransactionType').setValue(3);
        item.get('TotallingAccCode').setValue(1110);
        item.get('GLCode').setValue(4);
        item.get('GLCodeDesc').setValue('4-HSBC BANK MIDDLE EAST - Deira');
      });
      this.getActualAmountSum('CN');
    }
  }

  /* update  form values to create-receipt objects*/
  createCNFormValues() {
    this.createCreditNotes = new CreateCreditNotes();
    const mainFormFieldArray = ['VoucherDate', 'ApprovedBy', 'ArabicDescription',
      'CountryCode', 'CustomerID', 'CustCode', 'ModifiedDate', 'ModifiedBy', 'PostedDate',
      'PreparedBy', 'PreparedDate', 'PreprintNo', 'PrintDate', 'RefreshDate', 'RegionCode', 'Title',
      'Approvers'];
    mainFormFieldArray.forEach(item => {
      console.log('this.item****', item);
      this.createCreditNotes[item] = this.mainVoucherForm.controls[item].value;

    });
    this.createCreditNotes.LocationCode = this.mainVoucherForm.controls.accountInfo['controls'].LocationCode.value;
    this.createCreditNotes.CostCenterCode = this.mainVoucherForm.controls.accountInfo['controls'].CostCenterCode.value;
    this.createCreditNotes.TotallingAccCode = this.mainVoucherForm.controls.accountInfo['controls'].TotallingAccCode.value;
    this.createCreditNotes.GLCode = this.mainVoucherForm.controls.accountInfo['controls'].GLCode.value;
    this.createCreditNotes.PayeeName = this.mainVoucherForm.controls.detailInfo['controls'].PayeeName.value;
    this.createCreditNotes.EnglishDescription = this.mainVoucherForm.controls.detailInfo['controls'].EnglishDescription.value;
    this.createCreditNotes.CreditNoteDetail = this.mainVoucherForm.controls['VoucherDetails'].value;
    console.log('this.createCreditNotes****', this.createCreditNotes);
  }

  /* create-receipt form*/
  submitForm() {
    super.validateDetailInfo();
    this.errorpayee = this.cshpayeename.invalid;
    this.errordetail = this.cshdetails.invalid;
    //  this.errorglCode = this.glCodeValue.invalid;
    if (!(!this.errorpayee && !this.errordetail && !this.errorglCode)) {
      return false;
    }

    //zero amount warning
    if (this.amountZeroCheck > 0) {
      this.alertService.warn(RSAMSGConstants.AMOUNTZEROCHECK);
      return false;
    }
    if (this.glerrorcount > 0) {
      return false;
    }
    this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
      this.approverusers.length > 0);
    if (this.totalAmount > 0) {
      if (!(localStorage.getItem('country') == '3')) {
        if (this.totalAmount > 99999 && !this.usersReq) {
          return false;
        }
      }
      this.createCNFormValues();
      console.log(this.createCreditNotes, ' this.createCreditNotes');
      if (this.prevPreviewID == null || this.prevPreviewID == undefined) {
        this.prevPreviewID = 0;
        this.createCreditNotes["CreditNoteNo"] = this.prevPreviewID;
      }
      this.createCreditNotes["CreditNoteNo"] = this.creditnoteEditData.CreditNoteNo;
      this.updateDetailsAmount('CN');
      this.createPaymentService.createCreditNote(JSON.stringify(this.createCreditNotes)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.returnValue['approverlist'] = this.approverusers;
          this.returnValue['ondemand'] = true;
          this.previewFlag = true;
          this.bsModalRef = this.modalService.show(CnpreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
          this.bsModalRef.content.data = this.returnValue;
          this.bsModalRef.content.totalAmount = this.totalAmount;
          this.bsModalRef.content.backdrop = true;
          this.bsModalRef.content.unApproved = this.unApproved;
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    if (this.totalAmount <= 0) {
      this.alertService.warn(RSAMSGConstants.DEBITEXCEEDMSG);
    }
  }


  getGlAccountHeader() {
    const param = 'totAccCode=1110' +
      '&ccCode=' + localStorage.getItem('costcentre');
    this.masterDataService.getDetailGlAccount(param).subscribe(data => {
      this.glAcountHeader = data;
      console.log('gldata', data);
    })
  }

  setGLHdrHiddenValue(ev) {
    console.log(ev);
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue(ev.item.Code);
  }
  clearHdrGLCode(ev) {
    this.mainVoucherForm.controls.detailInfo['controls'].GLCode.setValue('');
    this.mainVoucherForm.controls.detailInfo['controls'].GLCodeDesc.setValue('');
  }
}

