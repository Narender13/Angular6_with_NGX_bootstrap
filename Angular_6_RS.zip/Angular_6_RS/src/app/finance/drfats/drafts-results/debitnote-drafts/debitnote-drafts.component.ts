import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { CreateDraftDebitnoteComponent } from '../../../drfats/drafts-results/create-draft-debitnote/create-draft-debitnote.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component';

@Component({
  selector: 'rsa-debitnote-drafts',
  templateUrl: './debitnote-drafts.component.html',
  styleUrls: ['./debitnote-drafts.component.scss']
})
export class DebitnoteDraftsComponent implements OnInit {

  @Input() debitnoteDraftData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }

  ngOnInit() {
    console.log(this.debitnoteDraftData, 'debitnoteDraftData-cpomp');
  }


}
