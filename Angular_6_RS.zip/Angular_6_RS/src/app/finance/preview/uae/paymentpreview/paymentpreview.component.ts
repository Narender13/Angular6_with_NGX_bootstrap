import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { validateEmail, multipleEmailValidation } from 'src/app/shared/utilites/helper';
import { CreatePaymentService } from 'src/app/finance/payments/create-payment/service/create-payment.service';
import { PreviewpdfService } from '../service/previewpdf.service';
import printJS from 'print-js';
import { Router, NavigationEnd } from '@angular/router';
@Component({
  selector: 'rsa-paymentpreview',
  templateUrl: './paymentpreview.component.html',
  styleUrls: ['./paymentpreview.component.scss']
})
export class PaymentpreviewComponent implements OnInit {

  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private createPaymentService: CreatePaymentService,
    private route: ActivatedRoute, private alertService: AlertService, private sharedService: SharedService, private previewpdfService: PreviewpdfService, private router: Router) { }
  data: any;
  symbol: string;
  returnValue: any;
  errorMsg: string;
  previewScreenFlag = true;
  approval = false;
  approverlist = '';
  emailVoucher = false;
  emailAddress;
  logourl;
  isUAE;
  isKSA;
  isOman;
  isBahrain;
  successmsg;
  invalidEmailAddress = true;
  checkcorrectEmail = true;
  totalAmount;
  fromCategory: any = null;
  isBatch = false;
  totalReceiptAmount: number;
  isSingleReceipient: boolean;
  sendPaymentByEmail;
  voucherNo;
  LocationCode;
  Paymentpdfsrc;
  claimPayment;
  isLoadingPdf = true;
  params;
  isView;
  isDraft;
  totalCount;
  unApproved = false;

  ngOnInit() {
    this.getPyamentDataToPreview();
    this.symbol = (localStorage.getItem('symbol'));
    this.logourl = localStorage.getItem('logourl') || 'assets/images/logo_rsa.svg';
    this.isUAE = (localStorage.getItem('regioncode') == '2');
    this.isKSA = (localStorage.getItem('regioncode') == '1');
    this.isOman = (localStorage.getItem('regioncode') == '3');
    this.isBahrain = (localStorage.getItem('regioncode') == '5');
    console.log(this.isBatch);
    console.log(this.totalReceiptAmount);
    this.isBatch = this.isBatch || false;
    this.totalReceiptAmount = this.totalReceiptAmount || 0;
    console.log(this.totalReceiptAmount, '>>>>>>>> Amount from Review')
    this.totalCount = this.route.snapshot.paramMap.get("totalCount");

  }

  // print() {
  //   window.print();
  // }

  print(VoucherNo, claimPayment, isdraft) {

    if (!claimPayment) {
      this.Paymentpdfsrc = this.previewpdfService.getPaymentPdfViewr(VoucherNo, isdraft);
    }
    if (claimPayment) {
      this.Paymentpdfsrc = this.previewpdfService.getClaimPaymentPdfViewr(VoucherNo, isdraft);
    }
    printJS({
      type: 'pdf',
      printable: this.Paymentpdfsrc,
      showModal: true,
      modalMessage: 'retrieving...',
    });
  }

  getPyamentDataToPreview() {
    setTimeout(() => {
      this.data = this.bsModalRef.content.data || this.data;
      this.unApproved = this.bsModalRef.content.unApproved || false;
      this.data['TotalAmount'] = Math.abs(this.data.TotalAmount);
      this.totalAmount = this.bsModalRef.content.totalAmount;
      console.log(this.data, 'data');
      console.log(this.totalAmount, 'Total Amount');
      this.getPaymentPdfViewr(this.data, this.claimPayment);
    }, 100);
  }


  savePayment(vocherId) {
    this.previewScreenFlag = false;
    if (!this.unApproved) {
      this.createPaymentService.savePayment(vocherId, this.claimPayment).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          this.sharedService.sendMessage({
            voucherName: 'Payments',
            message: 'save-voucher'
          });
          console.log(this.approval, 'approval');
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    } else {
      this.createPaymentService.savePaymentUnapproved(vocherId, this.claimPayment).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          console.log(this.approval, 'approval');
          this.sharedService.sendMessage({
            voucherName: 'Payments',
            message: 'save-voucher'
          });
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
  }

  previous() {
    this.bsModalRef.hide();
    this.sharedService.sendMessage("previous");
    this.sharedService.sendMessage({
      id: this.data.VoucherNo,
      data: this.data.PmtDetails
    });
  }

  close() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage('close');
    this.sharedService.sendMessage('close-preview');
    if (this.isDraft) {
      const params = {
        'totalCount': this.totalCount,
        'voucherName': this.claimPayment ? 'Claim Payments' : 'Payments',
      };
      this.router.navigate(['home/search/draft'], {
        queryParams: params
      });
    }
  }

  sendEmail(vocherNumber, claimPayment) {

    if (this.checkCommaSpeartedString() && !this.emailVoucher) {
      this.isSingleReceipient = true;
      return false;
    }
    this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    this.sendPaymentByEmail = this.emailVoucher;
    if (this.invalidEmailAddress) {
      this.checkcorrectEmail = multipleEmailValidation(this.emailAddress);
    }
    if (this.invalidEmailAddress && this.checkcorrectEmail && this.sendPaymentByEmail) {
      // const param = {
      //   ToEmailID: this.emailAddress,
      //   LoggedInUserID: 181,
      //   IsApproved: true,
      //   ReceiptNo: vocherNumber
      // };

      if (!claimPayment) {
        this.params = {
          ToEmailID: this.emailAddress,
          LoggedInUserID: 181,
          VoucherType: 1,
          VoucherNo: vocherNumber
        };
      }
      if (claimPayment) {
        this.params = {
          ToEmailID: this.emailAddress,
          LoggedInUserID: 181,
          VoucherType: 5,
          VoucherNo: vocherNumber
        };
      }

      this.createPaymentService.sendEmail(this.params).subscribe((data) => {
        // this.bsModalRef.hide();
        this.successmsg = data;
        this.alertService.success(data);
        console.log(data, 'data sucessfully');
      },
        errorRturn => {
          this.errorMsg = errorRturn;
        });



    }

  }


  onProgress(event) {
    console.log(event);
    const total = event.total;
    if (total !== undefined || total !== '') {
      setTimeout(() => {
        this.isLoadingPdf = false;
      }, 2000);
    }
  }
  getPaymentPdfViewr(res, claimPayment) {
    if (!claimPayment) {
      console.log("payment only ");
      this.voucherNo = res.VoucherNo;
      this.Paymentpdfsrc = this.previewpdfService.getPaymentPdfViewr(this.voucherNo, 0);

      console.log(this.Paymentpdfsrc, "this is pdf-viewer claim payment url");
    }
    if (claimPayment) {
      console.log("calim only ");
      this.voucherNo = res.VoucherNo;
      this.Paymentpdfsrc = this.previewpdfService.getClaimPaymentPdfViewr(this.voucherNo, 0);
      console.log(this.Paymentpdfsrc, "this is pdf-viewer payment url");
    }

  }

  checkCommaSpeartedString(): boolean {
    const str = this.emailAddress;
    if (str.indexOf(',') > -1) {
      return true;
    } else {
      return false;
    }
  }
}
