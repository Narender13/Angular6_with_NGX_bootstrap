import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { validateEmail, multipleEmailValidation } from 'src/app/shared/utilites/helper';
import { PreviewpdfService } from '../service/previewpdf.service';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { CreateJvService } from 'src/app/finance/createjv/service/create-jv.service';

import printJS from 'print-js';
@Component({
  selector: 'rsa-jvpreview',
  templateUrl: './jvpreview.component.html',
  styleUrls: ['./jvpreview.component.scss']
})
export class JvpreviewComponent implements OnInit {

  constructor(private modalService: BsModalService, public bsModalRef: BsModalRef, private createservice: CreateService,
    private route: ActivatedRoute, private alertService: AlertService, private sharedService: SharedService, private previewpdfService: PreviewpdfService,
    protected masterDataService: MasterDataService, private fb: FormBuilder, protected createJvService: CreateJvService) { }
  data: any;
  symbol: string;
  returnValue: any;
  errorMsg: string;
  previewScreenFlag = true;
  approval = false;
  approverlist = '';
  emailVoucher = false;
  emailAddress;
  logourl;
  isUAE;
  isKSA;
  isOman;
  isBahrain;
  successmsg;
  invalidEmailAddress = true;
  checkcorrectEmail = true;
  totalAmount;
  total;
  isBatch = false;
  src: string;
  zoom_to;
  VoucherNo;
  LocationCode;
  Jvpdfsrc: string;
  res;
  isSingleReceipient: boolean;
  sendPaymentByEmail;
  isLoadingPdf = true;
  totalAmountDr;
  totalAmountCr;
  fromCategory: any = null;
  unApproved = false;
  displayApprover = false;
  users: any = [];
  arrUser: any = [];
  approverusers: string;
  mainUserForm: FormGroup;
  clonedJV;
  createJvModel;
  userIdsArray: any = [];
  approvererror: boolean = false;
  usersReq;
  params;

  unApprovedHideFinalizeButton = false;



  ngOnInit() {
    setTimeout(() => {
      this.data = this.bsModalRef.content.data || this.data;
      // this.totalAmount = this.bsModalRef.content.totalAmount;
      // this.total = this.bsModalRef.content.total;
      this.totalAmountCr = this.bsModalRef.content.totalamountcr;
      this.totalAmountDr = this.bsModalRef.content.totalamountdr;
      this.unApproved = this.bsModalRef.content.unApproved || false;
      this.unApprovedHideFinalizeButton = this.bsModalRef.content.unApprovedHideFinalizeButton || false;
      console.log(this.unApprovedHideFinalizeButton, "initialize....");
      //this.clonedJV = this.bsModalRef.content.clonedJV;

      console.log(this.isBatch);
      this.isBatch = this.isBatch || false;

      console.log(this.data, 'data222---');
      console.log(this.totalAmountCr, 'TotalAmountCrr.....');
      console.log(this.totalAmountDr, 'TotalAmountDrr......');
      this.getJvPdfViewr(this.data);

      console.log(this.data, "approvalllll");




    }, 100);

    this.symbol = (localStorage.getItem('symbol'));
    this.logourl = localStorage.getItem('logourl') || 'src/assets/images/logo_rsa.svg';
    this.isUAE = (localStorage.getItem('regioncode') == '2');
    this.isKSA = (localStorage.getItem('regioncode') == '1');
    this.isOman = (localStorage.getItem('regioncode') == '3');
    this.isBahrain = (localStorage.getItem('regioncode') == '5');

    this.createMainUserForm();
    this.getJVMasterData();
  }
  //  print() {
  //   window.print();
  // }

  print(VoucherNo, LocationCode, isdraft) {
    this.Jvpdfsrc = this.previewpdfService.getJvPdfViewr(VoucherNo, LocationCode, isdraft);
    //  console.log(this.pdfsrc,"pdfViewurl");
    printJS({
      type: 'pdf',
      printable: this.Jvpdfsrc,
      showModal: true,
      modalMessage: 'retrieving...',
    })
  }


  /*get All users data from masterservice to approvers */
  getJVMasterData(): void {
    this.masterDataService.getJVMasterData().subscribe(
      dataReturn => {
        this.users = dataReturn;
        //console.log(this.users2,"userList");
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }



  /* for approvals change results */
  createMainUserForm() {
    //this.jvUserInfoDetails = this.createDetailsArrayGroup();
    console.log("previous call....");
    this.mainUserForm = this.fb.group({
      Approvers: this.fb.array([])
    });
  }

  /* for approvals change results */
  onUserChange(parmas) {
    console.log(parmas, 'params');
    const isCheked = parmas.event.target.checked;
    const userid = parmas.item.UserID;
    const username = parmas.item.UserEngName;

    const userFormArray = <FormArray>this.mainUserForm.controls.Approvers;
    if (isCheked) {
      userFormArray.push(new FormControl(userid));
      this.arrUser.push(username);
      this.userIdsArray.push(userid);
      //console.log("checked ids"+this.userIdsArray);
    } else {
      const index = userFormArray.controls.findIndex(x => x.value == userid);
      userFormArray.removeAt(index);
      this.arrUser = this.arrUser.filter(v => v !== username);
      this.userIdsArray.splice(index, 1);
      //console.log("unchecked second"+this.userIdsArray);
    }
    this.approverusers = this.arrUser.join();

    console.log(this.approverusers, 'approvals');
  }



  // saveJv() {

  //   if (this.userIdsArray.length == 0) {
  //     this.approvererror = true;
  //     return false;
  //   } else {
  //     this.approvererror = false;
  //   }
  //   this.createJvModel.IsRejectandEdit = false;
  //   let arrayConvert: any = [];
  //   // arrayConvert=this.approverusers.split(',');   
  //   this.createJvModel.Approvers = this.userIdsArray;
  //   console.log(this.createJvModel, "users");
  //   this.previewScreenFlag = false;

  //   // this.usersReq = (this.approverusers !== undefined && this.approverusers !== '' &&
  //   //     this.approverusers.length > 0);
  //   //   this.approverror = false;
  //   //   if (!this.usersReq) {
  //   //     this.approverror = true;
  //   //     return false;
  //   // }

  //   if (!this.unApproved) {
  //     this.createJvService.createJv(JSON.stringify(this.createJvModel)).subscribe(
  //       dataReturn => {
  //         this.returnValue = dataReturn;
  //         //   debugger;
  //         console.log(this.returnValue, 'saveJV - - this.returnValue');
  //         this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
  //         this.sharedService.sendMessage({
  //           voucherName: 'JV',
  //           message: 'save-voucher'
  //         });

  //       },
  //       errorRturn => {
  //         this.errorMsg = errorRturn;
  //       }
  //     );
  //   } else {
  //     this.createJvService.createJv(JSON.stringify(this.createJvModel)).subscribe(
  //       dataReturn => {
  //         this.returnValue = dataReturn;
  //         //   debugger;
  //         console.log(this.returnValue, 'saveJV - - this.returnValue');
  //         this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
  //         this.sharedService.sendMessage({
  //           voucherName: 'JV',
  //           message: 'save-voucher'
  //         });

  //       },
  //       errorRturn => {
  //         this.errorMsg = errorRturn;
  //       }
  //     );

  //   }


  // }




  saveJv(VoucherNo) {

    if (this.userIdsArray.length == 0) {
      this.approvererror = true;
      return false;
    } else {
      this.approvererror = false;
    }

    this.previewScreenFlag = false;
    this.params = { "VoucherNo": VoucherNo, "Approvers": this.userIdsArray }
    //console.log(this.params,"sss");

    if (!this.unApproved) {
      this.createservice.saveJv(JSON.stringify(this.params)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          //   debugger;
          console.log(this.returnValue + '/' + this.data, 'saveJV - - this.returnValue');
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);

        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }
    else {
      this.createservice.saveJvUnapproved(JSON.stringify(this.params)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          //   debugger;
          console.log(this.returnValue + '/' + this.data, 'saveJV - - this.returnValue');
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

  }


  previous(voucherno, bmhId, obj) {
    console.log('voucherno:', voucherno);
    console.log('obj:', this.data);
    this.bsModalRef.hide();
    this.sharedService.sendMessage("previous");
    this.sharedService.sendMessage({
      id: voucherno,
      bmhId: bmhId,
      data: obj
    });
  }
  close() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
    this.sharedService.sendMessage('close-preview');
  }

  sendEmail(receiptnumber) {

    // this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    // this.checkcorrectEmail = multipleEmailValidation(this.emailAddress);
    // if (this.checkCommaSpeartedString() && !this.emailVoucher) {
    //   this.isSingleReceipient = true;
    //   return false;
    // }


    this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    this.sendPaymentByEmail = this.emailVoucher;
    if (this.invalidEmailAddress) {
      this.checkcorrectEmail = multipleEmailValidation(this.emailAddress);
    }

    if (this.checkCommaSpeartedString() && !this.emailVoucher) {
      this.isSingleReceipient = true;
      return false;
    }

    if (this.invalidEmailAddress && this.checkcorrectEmail && this.sendPaymentByEmail) {
      // const param = {
      //   ToEmailID: this.emailAddress,
      //   LoggedInUserID: 181,
      //   IsApproved: true,
      //   ReceiptNo: receiptnumber
      // };
      const param = {
        ToEmailID: this.emailAddress,
        LoggedInUserID: 181,
        VoucherType: 4,
        VoucherNo: receiptnumber
      };
      this.createservice.sendEmail(param).subscribe((data) => {
        // this.bsModalRef.hide();
        this.successmsg = data;
        this.alertService.success(data);
        console.log(data, 'data sucessfully');
      },
        errorRturn => {
          this.errorMsg = errorRturn;
        });
    }

  }
  checkCommaSpeartedString(): boolean {
    const str = this.emailAddress;
    if (str.indexOf(',') > -1) {
      return true;
    } else {
      return false;
    }
  }

  onProgress(event) {
    console.log(event);
    const total = event.total;
    if (total !== undefined || total !== '') {
      setTimeout(() => {
        this.isLoadingPdf = false;
      }, 2000);
    }
  }


  getJvPdfViewr(res) {
    this.VoucherNo = res.VoucherNo;
    this.LocationCode = res.LocationCode;
    this.Jvpdfsrc = this.previewpdfService.getJvPdfViewr(this.VoucherNo, this.LocationCode, 0);
  }

  zoom_in() {
    this.zoom_to = this.zoom_to + 0.25;
  }

  zoom_out() {
    if (this.zoom_to > 1) {
      this.zoom_to = this.zoom_to - 0.25;
    }
  }


}

