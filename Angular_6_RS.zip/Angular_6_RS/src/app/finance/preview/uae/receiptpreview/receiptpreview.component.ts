import { Component, OnInit, Injectable, Inject, Renderer2 } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SharedService } from 'src/app/finance/services/shared.service';
import { validateEmail, multipleEmailValidation, numberToWordswithDecimal } from 'src/app/shared/utilites/helper';
import { DOCUMENT } from '@angular/common';
import { PreviewpdfService } from '../service/previewpdf.service';
import printJS from 'print-js';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'rsa-receiptpreview',
  templateUrl: './receiptpreview.component.html',
  styleUrls: ['./receiptpreview.component.scss']
})
export class ReceiptpreviewComponent implements OnInit {

  constructor(@Inject(DOCUMENT) private document: Document, private modalService: BsModalService,
    public bsModalRef: BsModalRef, private createservice: CreateService,
    private route: ActivatedRoute, private alertService: AlertService,
    private sharedService: SharedService, private renderer: Renderer2,
    private previewpdfService: PreviewpdfService, private router: Router) { }
  data: any;
  symbol: string;
  returnValue: any;
  errorMsg: string;
  previewScreenFlag = true;
  approval = false;
  approverlist = '';
  emailVoucher = false;
  emailAddress;
  isSingleReceipient: boolean;
  sendReceiptByEmail;
  logourl;
  isUAE;
  isKSA;
  isOman;
  isBahrain;
  successmsg;
  isLoadingPdf = true;
  invalidEmailAddress = true;
  checkcorrectEmail = true;
  totalAmount;
  fromCategory: any = null;
  brokerCustomerAmount: any;
  isBatch = false;

  isFinalize: boolean;

  totalReceiptAmount: number;
  totalReceiptAmountInWords: any;
  ReceiptNo;
  LocationCode;
  Receiptpdfsrc;
  isDraft;
  unApproved = false;

  ngOnInit() {
    setTimeout(() => {
      this.data = this.bsModalRef.content.data || this.data;
      this.totalAmount = this.bsModalRef.content.totalAmount;
      this.unApproved = this.bsModalRef.content.unApproved || false;
      console.log(this.brokerCustomerAmount);
      console.log(this.isBatch);
      console.log(this.totalReceiptAmount);
      this.isBatch = this.isBatch || false;
      this.totalReceiptAmount = this.totalReceiptAmount || 0;
      console.log(this.data, 'data');
      this.getReceiptPdfViewr(this.data);
      /* Fix for defect 437 - if the ampunt is more than 100000 Finalize should not appear as it needs apprival before */
      if (this.data.PrintDate == '' || this.data.PrintDate == null) { // if it is not finalized already
        if (this.data.TotalAmount < 100000) {
          this.isFinalize = true;
        } else {
          this.isFinalize = false;
        }
      } else {
        this.isFinalize = false;
      }
      this.totalReceiptAmountInWords = numberToWordswithDecimal(Number(this.totalReceiptAmount).toFixed(2));
    }, 100);

    this.symbol = (localStorage.getItem('symbol'));
    this.logourl = localStorage.getItem('logourl') || 'assets/images/logo_rsa.svg';
    this.isUAE = (localStorage.getItem('regioncode') == '2');
    this.isKSA = (localStorage.getItem('regioncode') == '1');
    this.isOman = (localStorage.getItem('regioncode') == '3');
    this.isBahrain = (localStorage.getItem('regioncode') == '5');
  }
  // print() {
  //   window.print();
  // }

  print(ReceiptNo, isdraft) {
    //this.Receiptpdfsrc = this.previewpdfService.getJvPdfViewr(VoucherNo);
    this.Receiptpdfsrc = this.previewpdfService.getReceiptPdfViewr(ReceiptNo, isdraft);

    //  console.log(this.pdfsrc,"pdfViewurl");
    printJS({
      type: 'pdf',
      printable: this.Receiptpdfsrc,
      showModal: true,
      modalMessage: 'retrieving...',

    });
  }
  onProgress(event) {
    console.log(event);
    const total = event.total;
    if (total !== undefined || total !== '') {
      setTimeout(() => {
        this.isLoadingPdf = false;
      }, 2000);
    }
  }

  saveReceipt(receiptID) {
    this.previewScreenFlag = false;
    if (!this.unApproved) {
      this.createservice.saveReceipt(receiptID).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          this.sharedService.sendMessage({
            voucherName: 'Receipts',
            message: 'save-voucher'
          });
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    } else {
      this.createservice.saveReceiptUnApproved(receiptID).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          this.approval = (this.data.approverlist != null && this.data.approverlist != NaN);
          this.sharedService.sendMessage({
            voucherName: 'Receipts',
            message: 'save-voucher'
          });
        },
        errorRturn => {
          this.errorMsg = errorRturn;
        }
      );
    }

  }

  previous(receptno, bmhId, obj) {
    this.bsModalRef.hide();
    this.sharedService.sendMessage("previous");
    this.sharedService.sendMessage({
      id: receptno,
      bmhId: bmhId,
      data: obj
    });

  }
  close() {
    this.bsModalRef.hide();
    this.modalService.hide(1);
    this.sharedService.sendMessage("close");
    this.sharedService.sendMessage('close-preview');
    this.renderer.removeClass(this.document.body, 'modal-open');
    if (this.isDraft) {
      const params = {
        'voucherName': 'Receipts',
      };
      this.router.navigate(['home/search/draft'], { queryParams: params });
    }
  }

  sendEmail(receiptnumber) {
    if (this.checkCommaSpeartedString() && !this.emailVoucher) {
      this.isSingleReceipient = true;
      return false;
    }
    this.invalidEmailAddress = (this.emailAddress !== undefined && this.emailAddress !== '' && this.emailAddress.length > 0);
    this.checkcorrectEmail = multipleEmailValidation(this.emailAddress);
    this.sendReceiptByEmail = this.emailVoucher;
    if (this.invalidEmailAddress && this.checkcorrectEmail && this.sendReceiptByEmail) {
      // const param = {
      //   ToEmailID: this.emailAddress,
      //   LoggedInUserID: 181,
      //   IsApproved: true,
      //   ReceiptNo: receiptnumber
      // };
      const param = {
        ToEmailID: this.emailAddress,
        LoggedInUserID: 181,
        VoucherType: 0,
        VoucherNo: receiptnumber
      };
      this.createservice.sendEmail(param).subscribe((data) => {
        // this.bsModalRef.hide();
        this.successmsg = data;
        this.alertService.success(data);
        console.log(data, 'data sucessfully');
      },
        errorRturn => {
          this.errorMsg = errorRturn;
        });
    }

  }
  getReceiptPdfViewr(res) {
    this.ReceiptNo = res.ReceiptNo;
    this.Receiptpdfsrc = this.previewpdfService.getReceiptPdfViewr(this.ReceiptNo, 0);
    console.log(this.Receiptpdfsrc, "this is pdf-viewer url");
  }

  checkCommaSpeartedString(): boolean {
    const str = this.emailAddress;
    if (str.indexOf(',') > -1) {
      return true;
    } else {
      return false;
    }
  }

}
