import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceiptCancelComponent } from './receipt-cancel.component';

describe('ReceiptCancelComponent', () => {
  let component: ReceiptCancelComponent;
  let fixture: ComponentFixture<ReceiptCancelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceiptCancelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceiptCancelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
