import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { Subject } from 'rxjs';
import { MessageService } from 'src/app/core/message/service/message.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'rsa-receipt-cancel',
  templateUrl: './receipt-cancel.component.html',
  styleUrls: ['./receipt-cancel.component.scss']
})
export class ReceiptCancelComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    public bsModalRef: BsModalRef,
    private createService: CreateService, private messageService: MessageService) { }
  public onClose: Subject<any>;
  cancelreceiptform: FormGroup;
  dataresult: any;
  ev: any;
  ReceiptID: any;
  enableFlag: boolean = false;
  viewscreen: boolean = false;
  PaymentNo: any;
  errorMsg: string;
  Defaulttext;
  currentDate;
  

  ngOnInit() {
    this.currentDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    this.Defaulttext = `Receipt No: ${this.ReceiptID} is reversed on ${this.currentDate}`;
    this.cancelreceiptform = this.fb.group({
      comments: [],
      ReceiptNo: []
    });
  }
  changeComments() {
    let ctrl = this.cancelreceiptform.get("comments");
    this.enableFlag = ctrl.pristine || ctrl.value.length > 0;
    console.log(this.enableFlag, 'this.enableFlag');
  }
  closeModal(ev) {
    this.bsModalRef.hide();
    ev.checked = false;
  }
  cancelReceipt(recptid, commentsText, ev) {
      this.cancelreceiptform.controls["ReceiptNo"].setValue(parseInt(recptid));
      if (this.cancelreceiptform.get("comments").value != null)
          this.cancelreceiptform.controls["comments"].setValue(this.cancelreceiptform.get("comments").value);
      else
          this.cancelreceiptform.controls["comments"].setValue(commentsText)
    console.log(this.cancelreceiptform.value, 'this.cancelreceiptform.value');
    this.viewscreen = true;
    this.createService.cancelReceipt(this.cancelreceiptform.value).subscribe(
      (data) => {
        this.dataresult = data;
        this.PaymentNo = data.PaymentNo;
        this.viewscreen = true;
        //this.bsModalRef.hide();
        ev.disabled = true;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  viewReceipt() {
    //this.messageService.sendMessage(true);
    this.messageService.sendMessage({'isAuthorized':true});
    this.bsModalRef.hide();
  }
}
