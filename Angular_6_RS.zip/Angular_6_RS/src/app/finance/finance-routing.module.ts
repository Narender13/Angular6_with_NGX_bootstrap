import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { DialogComponent } from './dialog/dialog.component';
import { EntitiesComponent } from './entities/entities.component';
import { ChequePrintComponent } from './payments/cheque-print/cheque-print.component';
import { DraftsResultsComponent } from 'src/app/finance/drfats/drafts-results/drafts-results.component';
import { PendingApprovalsResultsComponent } from 'src/app/finance/pending-approvals/pending-approvals-results.component';
import { UnApprovalsResultsComponent } from 'src/app/finance/un-approved/un-approvals-results/un-approvals-results.component';
import { EntityViewComponent } from './entities/view-entity/entityview.component';
import { MonthendComponent } from './monthend/monthend.component';
const routes: Routes = [


    {
        path: '',
        children: [
            {
                path: 'receipt/new',
                component: DialogComponent
            },
            { path: 'payment/new', component: DialogComponent },
            { path: 'receipt/preview', component: DialogComponent },
            { path: 'receipt/cancel', component: DialogComponent },
            { path: 'creditnotes/new', component: DialogComponent },
            { path: 'debitnotes/new', component: DialogComponent },
            { path: 'receipt/new/entiti', component: DialogComponent },
            { path: 'receipt/rowselection/entiti', component: DialogComponent },
            { path: 'receipt/claim', component: DialogComponent },
            { path: 'entiti/preview', component: DialogComponent },
            {
                path: 'entitie/new', component: EntitiesComponent, 
                data: { breadcrumb: 'home', path: 'Entity New' }
            },
            {
                path: 'entity/view', component: EntityViewComponent,
                data: { breadcrumb: 'home', path: 'Entity View ' }
            },           
            {
                path: 'result', loadChildren: 'src/app/finance/search/search.module#SearchModule'
            },
            {
                path: 'draft', component: DraftsResultsComponent,
                data: { breadcrumb: 'home', path: 'Drafts ' }
            },

            {
                path: 'pendingapproval', component: PendingApprovalsResultsComponent,
                data: { breadcrumb: 'home', path: 'My Approvals ' }
            },
            {
                path: 'unapproved', component: UnApprovalsResultsComponent,
                data: { breadcrumb: 'home', path: 'Not Aproved ' }
            },

            {
                path: 'payments/cheque print', component: ChequePrintComponent,
                data: { breadcrumb: 'home', path: 'payments > cheque print ' }
            },

            { path: 'Journal', component: DialogComponent },
            {
                path: 'finance/Reports', loadChildren: 'src/app/finance/reports/reports.module#ReportsModule'
            },
            {
                path: 'finance/monthend', component: MonthendComponent
            },
          
            
          

        ]
    }



];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FinanceRoutingModule { }

