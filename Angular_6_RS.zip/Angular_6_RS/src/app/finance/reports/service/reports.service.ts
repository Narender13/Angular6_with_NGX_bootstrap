import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { ExpenseAnalysis } from '../report-account/report-account-results/report-expense-analysis/model/expense-analysis'

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { }


  getReportsList(): Observable<any> {
    return this.http.get(RSAENDPOINTConstants.REPORTS).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportsList')));
  }

  getEntitySearchListData(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITENAMES + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntitySearchListData')));
  }

  saveConfiguratorReports(params): Observable<any> {
    return this.http.post<any>(RSAENDPOINTConstants.REPORTSCONFIGURATORSOAAPPLY, params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveConfiguratorReoprts')));
  }


  getReportHeaders(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETREPORTHEADERSSOA).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportHeaders')));
  }

  getReportHeadersTb(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETREPORTHEADERSTB).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportHeaders')));
  }

  // soa services start

  generateSoaReport(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GENERATESOAREPORT + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSoaReport')));
  }


  // tb services
  generateTbReport(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GENERATETBREPORT + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateTbReport')));
  }

  // generateSavedTemplateSoa(): Observable<any> {
  //   return this.http.get<any>(RSAENDPOINTConstants.GETSAVEDTEMPLATESOA).pipe(
  getSavedTemplate(queryString: string, reportType: string): Observable<any> {
    let queryParam;
    if (reportType === 'soa') {
      queryParam = '?reportId=5&reportType=2' + queryString;
    } else if (reportType === 'tb') {
      queryParam = '?reportId=8&reportType=2' + queryString;
    }
    return this.http.get<any>(RSAENDPOINTConstants.GETTEMPLATEBASEDDATA + queryParam).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSoaReport')));
  }


  generateSavedTemplateSoa(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETSAVEDTEMPLATESOA + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSavedTemplateSoa')));
  }
  generateSavedTemplateTb(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETSAVEDTEMPLATETB).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSavedTemplateSoa')));
  }

  sendEmail(params): Observable<any> {
    return this.http.post<any>(RSAENDPOINTConstants.SENDEMAIL, params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('sendEmail')));
  }

  exportExcel(queryString: string, voucherType: string): Observable<Blob> {
    let url;
    if (voucherType == 'soa') {
      url = RSAENDPOINTConstants.EXPORTEXCEL;
    } else if (voucherType == 'tb') {
      url = RSAENDPOINTConstants.EXPORTEXCELTB;
    }
    return this.http.get(url + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportExcel')));
  }

  exportText(queryString: string, voucherType: string): Observable<any> {
    let url;
    if (voucherType == 'soa') {
      url = RSAENDPOINTConstants.EXPORTTEXT;
    } else if (voucherType == 'tb') {
      url = RSAENDPOINTConstants.EXPORTTEXTTB;
    }
    return this.http.get(url + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportText')));
  }

  exportPdf(queryString: string, voucherType: string): Observable<any> {
    let url;
    if (voucherType == 'soa') {
      url = RSAENDPOINTConstants.EXPORTPDF;
    } else if (voucherType == 'tb') {
      url = RSAENDPOINTConstants.EXPORTPDFTB;
    }
    return this.http.get(url + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportPdf')));
  }
  // user report services start 

  getCob() {
    return this.http.get<any>(RSAENDPOINTConstants.GETCOB).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getCob')));
  }

  getPolicyType(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETPOLICEYTYPE + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getPolicyType')));
  }


  getBranches() {
    return this.http.get<any>(RSAENDPOINTConstants.GETBNANCH).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getBranches')));
  }

  getReportsName() {
    return this.http.get<any>(RSAENDPOINTConstants.GETREPORTNAMES).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportsName')));
  }

  getEntityType(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITYTYPE + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntityType')));
  }

  getEntityName(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITYNAME + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntityName')));
  }

  getUserReportTemplates(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETUSERTEMPLATENAMES + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getUserReportTemplates')));
  }

  getUserReportExtract() {
    return this.http.get<any>(RSAENDPOINTConstants.GETUSERREPORTEXTRACTDETAIL).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getUserReportExtract')));
  }

  getAgentOrPayeeName() {
    return this.http.get<any>(RSAENDPOINTConstants.GETAGENTORPAYEENAME).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getAgentOrPayeeName')));
  }

  // Expense Analysis services start

  getAllExpenseAnalysis(): Observable<Array<ExpenseAnalysis>> {
    return this.http.get(RSAENDPOINTConstants.EXPENSEANALYSIS + '/GetAllExpenseAnalysis').pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getExpenseAnalysis')));
  }
  addExpenseAnalysis(params): Observable<ExpenseAnalysis> {
    return this.http.post<ExpenseAnalysis>(RSAENDPOINTConstants.EXPENSEANALYSIS + '/Create', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('addExpenseAnalysis')));
  }
  updateExpenseAnalysis(params): Observable<ExpenseAnalysis> {
    return this.http.put<ExpenseAnalysis>(RSAENDPOINTConstants.EXPENSEANALYSIS + '/Update', params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('updateExpenseAnalysis')));
  }

  downloadExpenseAnalysis(): Observable<Array<ExpenseAnalysis>> {
    return this.http.get(RSAENDPOINTConstants.EXPENSEANALYSIS + '/ExportExcel?exportExcel=true', { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('downloadExpenseAnalysis')));
  }

  
  // userReportsView1() {
  //   return this.http.get<any>(RSAENDPOINTConstants.REPORTSUSER1).pipe(
  //     map(res => res),
  //     catchError(handleErrorObservable<any>('userReportsView')));
  // }

  get ageing() {
    return [
      { 'from': 0, 'to': 60 },
      { 'from': 0, 'to': 120 },
      { 'from': 120, 'to': 180 },
      { 'from': 180, 'to': 240 },
    ];
  }
}
