import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { RequestOptions, ResponseContentType } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http: HttpClient) { }


  getReportsList(): Observable<any> {
    return this.http.get(RSAENDPOINTConstants.REPORTS).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportsList')));
  }

  getEntitySearchListData(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITENAMES + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntitySearchListData')));
  }

  saveConfiguratorReports(params): Observable<any> {
    return this.http.post<any>(RSAENDPOINTConstants.REPORTSCONFIGURATORSOAAPPLY, params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('saveConfiguratorReoprts')));
  }


  getReportHeaders(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETREPORTHEADERSSOA).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportHeaders')));
  }

  // soa services start 

  generateSoaReport(queryString: string): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GENERATESOAREPORT + queryString).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSoaReport')));
  }

  generateSavedTemplateSoa(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.GETSAVEDTEMPLATESOA).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('generateSavedTemplateSoa')));
  }

  sendEmail(params): Observable<any> {
    return this.http.post<any>(RSAENDPOINTConstants.SENDEMAIL, params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('sendEmail')));
  }

  exportExcel(queryString: string): Observable<Blob> {
    return this.http.get(RSAENDPOINTConstants.EXPORTEXCEL + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportExcel')));
  }

  exportText(queryString: string): Observable<any> {
    return this.http.get(RSAENDPOINTConstants.EXPORTTEXT + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportText')));
  }

  exportPdf(queryString: string): Observable<any> {
    return this.http.get(RSAENDPOINTConstants.EXPORTPDF + queryString, { observe: 'response', responseType: 'blob' }).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('exportPdf')));
  }

  // user report services start 

  getCob() {
    return this.http.get<any>(RSAENDPOINTConstants.GETCOB).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getCob')));
  }

  getPolicyType(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETPOLICEYTYPE + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getPolicyType')));
  }


  getBranches() {
    return this.http.get<any>(RSAENDPOINTConstants.GETBNANCH).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getBranches')));
  }

  getReportsName() {
    return this.http.get<any>(RSAENDPOINTConstants.GETREPORTNAMES).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getReportsName')));
  }

  getEntityType() {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITYTYPE).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntityType')));
  }

  getEntityName(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETENTITYNAME + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getEntityName')));
  }

  getUserReportTemplates(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.GETUSERTEMPLATENAMES + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getUserReportTemplates')));
  }

  getUserReportExtract() {
    return this.http.get<any>(RSAENDPOINTConstants.GETUSERREPORTEXTRACTDETAIL).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getUserReportExtract')));
  }

  userReportsView(querystring: string) {
    return this.http.get<any>(RSAENDPOINTConstants.REPORTSUSER + querystring).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('userReportsView')));
  }

  get ageing() {
    return [
      { 'from': 0, 'to': 60 },
      { 'from': 0, 'to': 120 },
      { 'from': 120, 'to': 180 },
      { 'from': 180, 'to': 240 },
    ];
  }
}
