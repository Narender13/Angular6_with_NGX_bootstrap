import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportAccountComponent } from '../reports/report-account/report-account.component';
import { ReportsHomeComponent } from './reports-home.component';
import { ReportAccountResultsComponent } from './report-account/report-account-results/report-account-results.component';


const routes: Routes = [
  {
    path: '', component: ReportsHomeComponent, data: { breadcrumb: 'home', path: 'reports' }
  },
  { path: ':reportName', component: ReportAccountResultsComponent, data: { breadcrumb: 'home', path: 'reports' } },
  // { path: 'tb', component: ReportTbComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
