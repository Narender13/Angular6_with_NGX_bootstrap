import { Component, Input, OnInit, Output, TemplateRef, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';


@Component({
    selector: 'rsa-report-header',
    templateUrl: './report-header-component.html',
    styleUrls: ['./report-header-component.scss']
})
export class ReportHeaderComponent implements OnInit {
    toggleFilter = true;
    reportType: string;
    reportList: Observable<any[]>;
    headerList: any;
    currentState = 'down';
    ageingList: Array<any>;
    reportListType = [];
    selectedReport: any;
    @Output() isAllorUnmatchedO = new EventEmitter<any>();
    @Output() toggleFilterO = new EventEmitter<any>();
    @Output() reportChangeO = new EventEmitter<any>();
    @Input() isAllorUnmatched;
    constructor(private fb: FormBuilder,
        private route: ActivatedRoute,
        private _service: ReportService,
        private router: Router,
    ) { }

    ngOnInit() {
        this.route.params.subscribe(params => {
            this.reportType = params['reportName'];
            console.log(this.reportType, 'reporttype');
        });
        this.getReportList();
        this.getReportsName();
        this.ageingList = this._service.ageing;
    }
    switchTemplate(): void {
        this.toggleFilterO.emit();

    }
    getReportsName() {
        this._service.getReportsName().subscribe((data) => {
            this.reportListType = data;
            console.log(this.reportListType, 'getReportsName');
        });
    }
    isAllorUnmatchedF(ev) {
        this.isAllorUnmatched = !this.isAllorUnmatched;
        console.log(this.isAllorUnmatched, 'isAllorUnmatched');
        this.isAllorUnmatchedO.emit(this.isAllorUnmatched);
    }

    getReportList() {
        this._service.getReportsList().subscribe((data) => {
            this.reportList = data;
        });
    }

    loadReport(e: any) {
        if (e.target.value) {
            const reportName = e.target.value;
            this.router.navigate(['/finance/Reports', reportName]);
            this.ngOnInit();
        }
    }

    reportChange() {
        console.log(this.selectedReport, 'selectedLevel');
        this.reportChangeO.emit({
            reportCode: this.selectedReport.RepCode, reportDesc: this.selectedReport.ReportEnglishDesc,
            reportType: this.selectedReport.RepType,
        });

    }
    getReport($event) {
        console.log($event);
    }
    getfilterHeaders(filterHeaders) {
        console.warn(filterHeaders);
    }
}
