import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ReportService } from '../../../service/reports.service';
import { saveAs as importedSaveAs } from 'file-saver';
import { DownloadFile } from 'src/app/shared/utilites/helper';


@Component({
  selector: 'rsa-download-account-deatils',
  templateUrl: './download-account-deatils.component.html',
  styleUrls: ['./download-account-deatils.component.scss']
})
export class DownloadAccountDeatilsComponent implements OnInit {
  modalRef: BsModalRef;
  downloadForm: FormGroup;
  paramsForDownload;
  customerName;
  reportName;
  constructor(private fb: FormBuilder, private modalService: BsModalService,
    private reportService: ReportService, private alertService: AlertService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.downloadForm = this.fb.group({
      downloadFormat: [null, Validators.required],
    });
    console.log(this.paramsForDownload, 'paramsForDownload');
    console.log(this.reportName, 'reportName');
  }

  close() {
    this.bsModalRef.hide();
  }

  downloadAccount() {
    // this.setdownloadFileName();
    console.log(this.downloadForm.value, 'this.downloadForm');
    const downlaodFromat = +(this.downloadForm.controls['downloadFormat'].value);
    console.log(downlaodFromat, 'downlaodFromat');
    if (downlaodFromat == 1) {
      this.reportService.exportExcel(this.paramsForDownload, this.reportName).subscribe((res) => {
        DownloadFile(res['body'], this.customerName, '.csv');
        console.log(res, 'blob');

      });
    }
    if (downlaodFromat == 2) {
      this.reportService.exportPdf(this.paramsForDownload, this.reportName).subscribe((res) => {
        DownloadFile(res['body'], this.customerName, '.pdf');
        console.log(res, 'blob');
      });
    }

    if (downlaodFromat == 3) {
      this.reportService.exportText(this.paramsForDownload, this.reportName).subscribe((res) => {
        DownloadFile(res['body'], this.customerName, '.txt');
        console.log(res, 'blob');
      });
    }

  }
  // setdownloadFileName() {
  //   if (this.reportType == 'tb') {
  //     this.customerName = 'trialBalance';
  //   }

  // }
}
