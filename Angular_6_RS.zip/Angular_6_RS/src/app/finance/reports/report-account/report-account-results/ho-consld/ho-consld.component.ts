import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-ho-consld',
  templateUrl: './ho-consld.component.html',
  styleUrls: ['./ho-consld.component.scss']
})
export class HoConsldComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
