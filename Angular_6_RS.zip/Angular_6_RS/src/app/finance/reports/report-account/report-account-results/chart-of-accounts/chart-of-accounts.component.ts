import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-chart-of-accounts',
  templateUrl: './chart-of-accounts.component.html',
  styleUrls: ['./chart-of-accounts.component.scss']
})
export class ChartOfAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
