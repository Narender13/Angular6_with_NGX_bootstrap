import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-cash-book',
  templateUrl: './cash-book.component.html',
  styleUrls: ['./cash-book.component.scss']
})
export class CashBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
