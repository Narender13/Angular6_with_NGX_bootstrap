import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SendEmailComponent } from '../send-email/send-email.component';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';
import printJS from 'print-js';


@Component({
  selector: 'rsa-report-tb',
  templateUrl: './report-tb.component.html',
  styleUrls: ['./report-tb.component.scss']
})
export class ReportTbComponent implements OnInit {
  trialBalForm: FormGroup;
  @Input() branchdata;
  @Input() totallingacc;
  locationcode: string;
  headerList: any;
  toggleFilter = false;
  frommonth = new Date();
  tomonth = new Date();
  fromyear = new Date();
  toyear = new Date();
  templateList = [];
  selectedTemplateId: number;
  tbReortsData: any;
  paramsForTb;
  fromMonth: string;
  toMonth: string;
  fromYear: string;
  toYear: string;
  categary: number;
  paramsForTbDownload;
  levelList: any[] = ['Level4', 'Level4_acs', 'Level4_rsa'];
  level: any = 'Level4';
  totallingAccCode;
  maxDate: any;
  constructor(private reportService: ReportService, private fb: FormBuilder,
    private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.locationcode = localStorage.getItem('locationcode');
    console.log(this.locationcode, 'locationcode');
    this.createTbForm();
    this.getHeadersForReports();
    this.getSavedTemplate();
    this.setMaxDate();
  }

  createTbForm(): void {
    this.trialBalForm = this.fb.group({
      Branch: [this.locationcode, Validators.required],
      TotallingAccount: [1110, Validators.required],
      FromMonth: [null, Validators.required],
      ToMonth: [null, Validators.required],
      FromYear: [null, Validators.required],
      ToYear: [null, Validators.required],
      Level: [null, Validators.required],
      Template: [null, Validators.required]
    });
  }

  setMaxDate() {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 1);
  }
  getHeadersForReports() {
    this.reportService.getReportHeadersTb().subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }
  getParams() {
    console.log(this.trialBalForm.controls['Branch'].value, 'formvalue');
    const formatMonth = 'MM';
    const formatYear = 'yyyy';
    const locale = 'en-US';
    this.fromMonth = formatDate(this.trialBalForm.controls['FromMonth'].value, formatMonth, locale);
    this.toMonth = formatDate(this.trialBalForm.controls['ToMonth'].value, formatMonth, locale);
    this.fromYear = formatDate(this.trialBalForm.controls['FromYear'].value, formatYear, locale);
    this.toYear = formatDate(this.trialBalForm.controls['ToYear'].value, formatYear, locale);
    this.level = this.trialBalForm.controls['Level'].value;
    this.totallingAccCode = this.trialBalForm.controls['TotallingAccount'].value;
    // this.selectedTemplateId = this.trialBalForm.controls['Template'].value || 0;
    const userId = localStorage.getItem('userId');
    /* sending userid 181 as per discussion with jaguruti wil remove that later*/
    this.paramsForTb = 'userId=' + '181' + '&level=' + this.level
      + '&totallingAccCode=' + this.totallingAccCode + '&templateId=' + this.selectedTemplateId +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth;
    console.log(this.paramsForTb, 'params');

  }

  getSavedTemplate() {
    this.reportService.generateSavedTemplateTb().subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }


  downloadTbReport() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: 'tb',
      paramsForDownload: this.paramsForTb,
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }


  sendEmail() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: 10,
      reportName: 'tb',
      //  totallingAccCode: this.totallingAccCode,
      customerName: this.totallingAccCode,
      paramsForEmail: this.paramsForTb,
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }


  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    console.log(this.selectedTemplateId, 'item');
  }
  onSubmit() {
    this.getParams();
    this.reportService.generateTbReport(this.paramsForTb).subscribe((data) => {
      console.log(data, 'data');
      // this.paramsForTb = data;
      if (data !== null) {
        const initialState = {
          backdrop: true,
          ignoreBackdropClick: false,
          reportsdata: data,
          reportType: 10,
          reportName: 'tb',
          paramsForDownload: this.paramsForTb,
          customerName: this.totallingAccCode,
          // totallingAccCode: this.totallingAccCode,
        };
        this.bsModalRef = this.modalService.show(ViewAccountComponent,
          { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });
      } else {
        this.alertService.info('No data found for curerent search');
      }

    });
  }

  onOpenCalendarForMonth(container) {
    container.monthSelectHandler = (event: any): void => {
      console.log(event);
      if (!event.isDisabled) {
        container._store.dispatch(container._actions.select(event.date));
      }
    };
    container.setViewMode('month');
  }

  onOpenCalendarForYear(container) {

    container.yearSelectHandler = (event: any): void => {
      if (!event.isDisabled) {
        container._store.dispatch(container._actions.select(event.date));
      }
    };

    container.setViewMode('year');
    // container.setMaxDate(this.maxDate);
  }
  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
  }

  printTb() {
    console.log('print clicked');
    printJS({
      type: 'pdf',
      printable: 'https://media.readthedocs.org/pdf/apiguide/latest/apiguide.pdf',
      showModal: true,
      modalMessage: 'retrieving...',

    });

  }

}
