import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { ActivatedRoute } from '@angular/router';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { validateEmail, multipleEmailValidation, DownloadFile } from 'src/app/shared/utilites/helper';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ReportService } from '../../../service/reports.service';
@Component({
    selector: 'rsa-send-email',
    templateUrl: './send-email.component.html',
    styleUrls: ['./send-email.component.scss']
})
export class SendEmailComponent implements OnInit {
    emailform: FormGroup;
    modalRef: BsModalRef;
    reportType;
    reportName;
    invalidEmailAddress = true;
    checkcorrectEmail = true;
    customerName;
    paramsForEmail;
    // totallingAccCode;
    constructor(private fb: FormBuilder, private modalService: BsModalService,
        public bsModalRef: BsModalRef, private reportService: ReportService, private alertService: AlertService) { }

    ngOnInit() {
        this.emailform = this.fb.group({
            emailFormat: [null, Validators.required],
            email: [null, Validators.required]
        });
        console.log(this.reportType, 'reportype');
        // console.log(this.totallingAccCode, 'totallingAccCode');
        console.log(this.reportName, 'reportname');
    }
    close() {
        this.bsModalRef.hide();
    }

    downloadFormat(value) {
        console.log(value);
        const downlaodFromat = value;
        if (downlaodFromat == 1) {
            this.reportService.exportExcel(this.paramsForEmail, this.reportName).subscribe((res) => {
                DownloadFile(res['body'], this.customerName, '.csv');
                console.log(res, 'blob');

            });
        }
        if (downlaodFromat == 2) {
            this.reportService.exportPdf(this.paramsForEmail, this.reportName).subscribe((res) => {
                DownloadFile(res['body'], this.customerName, '.pdf');
                console.log(res, 'blob');
            });
        }

        if (downlaodFromat == 3) {
            this.reportService.exportText(this.paramsForEmail, this.reportName).subscribe((res) => {
                DownloadFile(res['body'], this.customerName, '.txt');
                console.log(res, 'blob');
            });
        }
    }



    sendEmail() {
        console.log(this.emailform.value);
        const emailAddress = this.emailform.controls['email'].value;
        const emailFormat = +(this.emailform.controls['emailFormat'].value);
        console.log(emailAddress, emailFormat);
        this.checkcorrectEmail = multipleEmailValidation(emailAddress);
        if (this.checkcorrectEmail) {
            const param = {
                ToEmailID: emailAddress,
                LoggedInUserID: 181,
                VoucherType: this.reportType,
                DownloadType: emailFormat,
                ReportId: this.customerName
            };
            if (this.reportName == 'tb') {
                param['ReportId'] = String(this.customerName);
            }
            console.log(param, 'param');
            this.reportService.sendEmail(param).subscribe((data) => {
                console.log(data, 'data');
                this.alertService.success(data);
                this.emailform.reset();
                // console.log(data, 'data sucessfully');
            });
        }
    }

    
}
