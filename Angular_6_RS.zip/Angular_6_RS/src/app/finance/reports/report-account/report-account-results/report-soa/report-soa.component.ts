import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ReportService } from '../../../service/reports.service';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { ViewAccountComponent } from '../view-account/view-account.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { SendEmailComponent } from '../send-email/send-email.component';
import { DownloadAccountDeatilsComponent } from '../download-account-deatils/download-account-deatils.component';

@Component({
  selector: 'rsa-report-soa',
  templateUrl: './report-soa.component.html',
  styleUrls: ['./report-soa.component.scss']
})
export class ReportSoaComponent implements OnInit {
  @Input() branchdata;
  soaForm: FormGroup;
  locationcode: string;
  entitysearchlist: any[] = [];
  searchval;
  entitySerachItem: any;
  entitySerachType: any;
  entitySerachGLCode: any;
  noentiti = true;
  headerList: any;
  ageingList: Array<any>;
  toggleFilter = false;
  frommonth = new Date();
  tomonth = new Date();
  fromyear = new Date();
  toyear = new Date();
  templateList = [];
  selectedTemplateId: number;
  isAllorUnmatched = true;
  invalidsearch;
  soaReortsData: any;
  paramsForSoa;
  fromMonth: string;
  toMonth: string;
  fromYear: string;
  toYear: string;
  categary: number;
  paramsForSoaDownload;
  constructor(private reportService: ReportService, private fb: FormBuilder,
    private alertService: AlertService, private modalService: BsModalService, public bsModalRef: BsModalRef) { }

  ngOnInit() {
    this.locationcode = localStorage.getItem('locationcode');
    console.log(this.locationcode, 'locationcode');
    this.getAsyncDataEntitysearchlist();
    this.ageingList = this.reportService.ageing;
    this.getHeadersForReports();
    this.createSoaForm();
    this.getSavedTemplate();
  }

  changeCostcenter() {

  }

  createSoaForm(): void {
    this.soaForm = this.fb.group({
      Branch: [this.locationcode, Validators.required],
      Entitiename: [null, Validators.required],
      FromMonth: [null, Validators.required],
      ToMonth: [null, Validators.required],
      FromYear: [null, Validators.required],
      ToYear: [null, Validators.required],
      Template: [null, Validators.required]
    });
  }

  onOpenCalendarForMonth(container) {
    container.monthSelectHandler = (event: any): void => {
      container._store.dispatch(container._actions.select(event.date));
    };
    container.setViewMode('month');
  }

  onOpenCalendarForYear(container) {
    container.yearSelectHandler = (event: any): void => {
      container._store.dispatch(container._actions.select(event.date));
    };
    container.setViewMode('year');
  }

  formControlClearValidator() {
    const fromMonth = this.soaForm.get('FromMonth');
    fromMonth.clearValidators();
    fromMonth.updateValueAndValidity();
    const toMonth = this.soaForm.get('ToMonth');
    toMonth.clearValidators();
    toMonth.updateValueAndValidity();
    const fromYear = this.soaForm.get('FromYear');
    fromYear.clearValidators();
    fromYear.updateValueAndValidity();
    const toYear = this.soaForm.get('ToYear');
    toYear.clearValidators();
    toYear.updateValueAndValidity();
  }

  formControlAddValidator() {
    const fromMonth = this.soaForm.get('FromMonth');
    fromMonth.setValidators([Validators.required]);
    fromMonth.updateValueAndValidity();
    const toMonth = this.soaForm.get('ToMonth');
    toMonth.setValidators([Validators.required]);
    toMonth.updateValueAndValidity();
    const fromYear = this.soaForm.get('FromYear');
    fromYear.setValidators([Validators.required]);
    fromYear.updateValueAndValidity();
    const toYear = this.soaForm.get('ToYear');
    toYear.setValidators([Validators.required]);
    toYear.updateValueAndValidity();
  }

  getHeadersForReports() {
    this.reportService.getReportHeaders().subscribe((data) => {
      this.headerList = data;
      console.log(data, 'headerList');
    });
  }

  getSavedTemplate() {
    this.categary = this.isAllorUnmatched === true ? 0 : 1;
    const param = '&category=' + this.categary;
    console.log(param, 'param');
    this.reportService.generateSavedTemplateSoa(param).subscribe((data) => {
      this.templateList = data;
      console.log(data, 'templateList');
    });
  }
  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachGLCode = typeheadobj.item.GLCode;
    this.entitySerachType = typeheadobj.item.EntityId;
    this.entitySerachItem = typeheadobj.item.EntityName;
    this.noentiti = true;
  }

  typeaheadNoResults(event: boolean): void {
    this.noentiti = event;
  }

  isAllorUnmatchedF(ev) {
    this.isAllorUnmatched = ev;
    this.getSavedTemplate();
    if (this.isAllorUnmatched === false) {
      this.formControlClearValidator();
    } else {
      this.formControlAddValidator();
    }
  }

  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    console.log(this.selectedTemplateId, 'item');
  }

  getParams() {
    console.log(this.soaForm.controls['Branch'].value, 'formvalue');
    const formatMonth = 'MM';
    const formatYear = 'yyyy';
    const locale = 'en-US';
    this.fromMonth = formatDate(this.soaForm.controls['FromMonth'].value, formatMonth, locale);
    this.toMonth = formatDate(this.soaForm.controls['ToMonth'].value, formatMonth, locale);
    this.fromYear = formatDate(this.soaForm.controls['FromYear'].value, formatYear, locale);
    this.toYear = formatDate(this.soaForm.controls['ToYear'].value, formatYear, locale);
    this.categary = this.isAllorUnmatched === true ? 0 : 1;

    this.paramsForSoa = 'category=' + this.categary + '&glCode=' + this.entitySerachGLCode
      + '&entityType=' + this.entitySerachType + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&reportId=5&reportType=2' + '&templateId=' + this.selectedTemplateId;
    console.log(this.paramsForSoa, 'params');

    this.paramsForSoaDownload = 'category=' + this.categary + '&locCode=' + this.locationcode + '&glCode=' + this.entitySerachGLCode
      + '&entityType=' + this.entitySerachType + '&fromMonth=' + this.fromMonth + '&toMonth=' + this.toMonth +
      '&fromYear=' + this.fromYear + '&toYear=' + this.toYear + '&templateId=' + this.selectedTemplateId;

    console.log(this.paramsForSoa, 'params');
  }
  onSubmit() {
    this.getParams();
    this.reportService.generateSoaReport(this.paramsForSoa).subscribe((data) => {
      console.log(data, 'data');
      this.soaReortsData = data;
      if (data !== null) {
        const initialState = {
          backdrop: true,
          ignoreBackdropClick: false,
          reportsdata: this.soaReortsData,
          reportName: 'soa',
          reportType: 8,
          paramsForDownload: this.paramsForSoaDownload,
          customerName: this.entitySerachItem,
          isUnmathed: this.isAllorUnmatched
        };
        this.bsModalRef = this.modalService.show(ViewAccountComponent,
          { class: 'user-reports-model', initialState, ignoreBackdropClick: true, keyboard: false });
      } else {
        this.alertService.info('No data found for curerent search');
      }

    });
  }

  toggleFilterF() {
    this.toggleFilter = !this.toggleFilter;
  }

  sendEmail() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportType: 8,
      reportName: 'soa',
      customerName: this.entitySerachItem,
      paramsForEmail: this.paramsForSoaDownload,
    };
    this.bsModalRef = this.modalService.show(SendEmailComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }
  downloadSoaReport() {
    this.getParams();
    const initialState = {
      backdrop: true,
      ignoreBackdropClick: false,
      reportName: 'soa',
      paramsForDownload: this.paramsForSoaDownload,
      customerName: this.entitySerachItem
    };
    this.bsModalRef = this.modalService.show(DownloadAccountDeatilsComponent,
      { class: 'preview-modal-dailog-send-email', initialState, backdrop: 'static', keyboard: false });
  }

  printSoa() {

  }

  getAsyncDataEntitysearchlist() {
    this.entitysearchlist = Observable.create((observer: any) => {
      // const userId = localStorage.getItem('userId')40518 ;
      const userId = '11';
      const locationcode = localStorage.getItem('locationcode');
      const params = 'userId=' + userId + '&serachName=' + this.searchval + '&locationCode=' + locationcode;
      this.reportService.getEntitySearchListData(params)
        .subscribe((searchlistdata) => {
          if (searchlistdata) {
            console.log(searchlistdata, 'serass-obser');
            const data = searchlistdata.sort((one, two) => (one.entityType < two.entityType ? -1 : 1));
            observer.next(data);
          }
        });
    });
  }

}
