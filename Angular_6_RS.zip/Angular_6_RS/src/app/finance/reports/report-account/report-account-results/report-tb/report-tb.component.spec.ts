import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportTbComponent } from './report-tb.component';

describe('ReportTbComponent', () => {
  let component: ReportTbComponent;
  let fixture: ComponentFixture<ReportTbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportTbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportTbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
