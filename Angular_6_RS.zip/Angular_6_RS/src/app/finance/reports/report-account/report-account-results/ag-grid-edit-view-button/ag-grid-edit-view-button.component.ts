import { Component, OnInit, ViewChild } from '@angular/core';
import { ICellRendererAngularComp, AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community';
@Component({
  selector: 'rsa-ag-grid-edit-view-button',
  templateUrl: './ag-grid-edit-view-button.component.html',
  styleUrls: ['./ag-grid-edit-view-button.component.scss']
})
export class AgGridEditViewButtonComponent implements ICellRendererAngularComp {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridConfiguration: GridOptions;
  public params: any;
  edit: boolean;
  view: boolean;
  showSave = false;
  showCancel = false;
  parentComponent;
  pageName: string;
  constructor() {
  }

  agInit(params: any): void {
    console.log(params, 'params');
    this.params = params;
    this.parentComponent = this.params.context.componentParent;
    this.pageName = params.inActoionLink;
    if (this.pageName === 'monthEndSetting') {
      if (this.params.data.isNewRow) {
        this.showSave = true;
        this.showCancel = true;
      }
    }
  }


  editCall(rowIndex) {
    this.showCancel = true;
    this.parentComponent.onParentEditClicked(rowIndex);
    this.showSave = true;
  }
  saveCall(id, rowIndex) {
    this.parentComponent.onParentSaveClicked(id, rowIndex);
    this.showSave = false;
    this.showCancel = false;
  }
  cancelCall(rowIndex) {
    this.parentComponent.onParentCancel(rowIndex);
    this.showCancel = false;
    this.showSave = false;
  }
  refresh(): boolean {
    return false;
  }

}
