import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-general-ledger',
  templateUrl: './general-ledger.component.html',
  styleUrls: ['./general-ledger.component.scss']
})
export class GeneralLedgerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
