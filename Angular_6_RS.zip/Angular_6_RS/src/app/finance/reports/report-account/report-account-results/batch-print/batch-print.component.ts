import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-batch-print',
  templateUrl: './batch-print.component.html',
  styleUrls: ['./batch-print.component.scss']
})
export class BatchPrintComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
