import { Component, OnInit, ViewChild, AfterViewInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DatePipe, formatDate } from '@angular/common';
import { ExpenseAnalysis } from './model/expense-analysis'
import { ReportService } from '../../../service/reports.service'
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { AgGridEditViewButtonComponent } from '../ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { DownloadFile } from 'src/app/shared/utilites/helper';

@Component({
  selector: 'rsa-report-expense-analysis',
  templateUrl: './report-expense-analysis.component.html',
  styleUrls: ['./report-expense-analysis.component.scss']
})
export class ReportExpenseAnalysisComponent implements OnInit, AfterViewInit {
  @ViewChild('agGrid') agGrid: AgGridNg2;
  gridApi;
  gridColumnApi;
  paginationOptions: TextValuePair[] = [];
  selectedData;
  expAnalysisForm: FormGroup;
  expAnalysis: ExpenseAnalysis = new ExpenseAnalysis();
  rowData: any[] = [];
  columnDefs: Array<object> = [];
  domLayout;
  detailRowHeight;
  detailCellRendererParams;
  gridConfiguration: GridOptions = {};
  components;
  viewExpAnalysis = true;
  updateExpAnalysis = true;
  editingRowIndex: number;
  suppressClickEdit;
  currentEditRow;
  constructor(private expAnalysisService: ReportService, private fb: FormBuilder,
    public datepipe: DatePipe, private alertService: AlertService) {
    this.domLayout = 'autoHeight';
  }

  ngOnInit() {
    this.createExpAnalysisForm();
    this.getAsyncAllExpenseAnalysis();
    this.columnDefs = [
      {
        headerName: 'Analysis Code', field: 'AnalysisCode', sortable: true, filter: 'agSetColumnFilter', editable: false, sort: "asc"
      },
      { headerName: 'Project Indicator', field: 'ACEngDesc', sortable: true, filter: 'agSetColumnFilter', editable: true },
      {
        headerName: 'Start Date', field: 'StartDate', sortable: true, filter: 'agSetColumnFilter', editable: true,
        valueFormatter: (data) => {
          return this.datepipe.transform(data.value, 'dd/MM/yyyy');
        }, cellEditor: "datePicker"
      },
      {
        headerName: 'End Date', field: 'EndDate', sortable: true, filter: 'agSetColumnFilter', editable: true,
        valueFormatter: (data) => {
          return this.datepipe.transform(data.value, 'dd/MM/yyyy');
        }, cellEditor: "datePicker"
      },
      {
        headerName: 'Action',
        field: 'value',
        cellRendererFramework: AgGridEditViewButtonComponent,
        cellRendererParams: {
          inActoionLink: 'expAnalysis'
        },
        colId: 'editSaveBtn',
        filter: 'none',
        headerClass: 'hidefilter'
      }
    ];
    this.components = { datePicker: getDatePicker() };
    this.GetcolumnDefs();
    this.suppressClickEdit = true;
  }

  GetcolumnDefs() {
    this.gridConfiguration = <GridOptions>{
      columnDefs: this.columnDefs,
      postProcessPopup: function (params) {
        const ePopup = params.ePopup;
        ePopup.style.top = '14.9838px';
      },
      rowData: this.rowData,
      rowHeight: 40,
      headerHeight: 40,
      pagination: true,
      floatingFiltersHeight: 40,
      paginationPageSize: 20,
      enableRangeSelection: true,
      rowSelection: 'single',
      rowMultiSelectWithClick: true,
      animateRows: true,
      enableColResize: true,
      enableFilter: true,
      suppressContextMenu: true,
      enableSorting: true,
      editType: 'cel',
      defaultColDef: {
        enableRowGroup: false,
        enableValue: true,
        suppressMovable: true,
        minWidth: 100,
        menuTabs: ['filterMenuTab', '', '']
      },
      context: {
        componentParent: this
      },
    };
  }

  createExpAnalysisForm(): void {
    this.expAnalysisForm = this.fb.group({
      AnalysisCode: [null, Validators.required],
      ACEngDesc: [null, Validators.required],
      StartDate: [null, Validators.required],
      EndDate: [null, Validators.required]
    });
  }


  onParentCancel(rowIndex) {
    this.gridApi.stopEditing();
    this.rowData[rowIndex] = this.currentEditRow;
    this.gridConfiguration.api.setRowData(this.rowData);
    this.suppressClickEdit = true;
  }

  getAsyncAllExpenseAnalysis(): any {
    this.expAnalysisService.getAllExpenseAnalysis().subscribe((data) => {
      this.rowData = data;
      console.log(data, this.rowData);
    });
  }

  validateData(currentData){
    if(currentData.AnalysisCode === ""){
      this.alertService.error('Analysis Code is empty');
      return 'AnalysisCode';
    }
    if(currentData.ACEngDesc === ""){
      this.alertService.error('Project Indicator is empty');
      return 'ACEngDesc';
    }
    if(currentData.EndDate === ""){
      this.alertService.error('End date is empty');
      return 'EndDate';
    }
    if(currentData.StartDate === ""){
      this.alertService.error('Start date is empty');
      return 'StartDate';
    }
    if (currentData.StartDate > currentData.EndDate) {
      this.alertService.info('End date should  be greater than Start date');
      return false;
    }
    return '';
  }

  saveExpAnalysis(): any {
    if (!this.expAnalysisForm.valid) {
      return false;
    }
    const startdate = Date.parse(this.expAnalysisForm.controls['StartDate'].value);
    const enddate = Date.parse(this.expAnalysisForm.controls['EndDate'].value);
    console.log(startdate, enddate);
    if (startdate > enddate) {
      this.alertService.info('End date should  be greater than Start date');
      return false;
    }
    this.expAnalysisService.addExpenseAnalysis(JSON.stringify(this.expAnalysisForm.value)).subscribe(
      dataReturn => {
        console.log(dataReturn);
        if (dataReturn.success) {
          console.log(this.expAnalysisForm.value, 'this.expAnalysisForm.value');
          this.rowData.push(this.expAnalysisForm.value);
          this.gridConfiguration.api.setRowData(this.rowData); // Refresh grid
          this.gridApi.paginationGoToPage(0);
          this.expAnalysisForm.reset();
        } else {
          this.alertService.warn(dataReturn.message);
        }
      },
      errorRturn => {
        this.alertService.error('something went wrong');
      }
    );
  }

  downloadExpAnalysis(){
    this.expAnalysisService.downloadExpenseAnalysis().subscribe(
      (dataReturn) => {
        console.log(dataReturn);
        DownloadFile(dataReturn['body'], 'ExpenseAnalysis', '.csv');
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }

  setAutoHeight() {
    setTimeout(() => {
      this.gridApi.setDomLayout('autoHeight');
    }, 200);

  }

  ngAfterViewInit() {
    this.fitToCoulmn();
    this.setAutoHeight();
  }

  fitToCoulmn() {
    setTimeout(() => {
      this.gridApi.sizeColumnsToFit();
    }, 200);
  }


  onGridReady(params) {
    console.log(params, 'params');
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridConfiguration.api.setRowData(this.rowData);
    params.api.paginationGoToPage(0);
    this.fitToCoulmn();
  }



  onParentEditClicked(rowIndex) {
    this.suppressClickEdit = false;
    this.editingRowIndex = rowIndex;
    this.currentEditRow = Object.assign({}, this.rowData[rowIndex]);
    this.gridApi.startEditingCell({
      rowIndex: rowIndex,
      colKey: 'ACEngDesc'
    });
  }

  onParentSaveClicked(id, rowIndex) {
    console.log(this.rowData);
    const updatedData = this.rowData.filter(data => data.AnalysisCode === id);
    console.log(updatedData, 'updatedata');
    console.log(updatedData);
    if (updatedData.length > 0) {
      let validate = this.validateData(updatedData[0]);
      if(validate === ''){
      this.expAnalysisService.updateExpenseAnalysis(JSON.stringify(updatedData[0])).subscribe(
        dataReturn => {
          this.suppressClickEdit = true;
          console.log(dataReturn);
          if (!dataReturn.success) {
            console.log('something wrong in saving expense analysis');
          }
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
      }
      else{
        this.rowData[rowIndex] = this.currentEditRow;
        this.gridApi.startEditingCell({
          rowIndex: rowIndex,
          colKey: validate
        });
      }
    }
  }
}

interface TextValuePair {
  id: number;
  value: string;
}

function getDatePicker() {
  function Datepicker() { }
  Datepicker.prototype.init = function (params) {
    var dateValue = formatGridDate(params.value);
    this.eInput = document.createElement("input");
    this.eInput.value = dateValue;
    this.eInput.setAttribute("type", "date");
    this.eInput.setAttribute("style", "width:100%");
  };
  Datepicker.prototype.getGui = function () {
    return this.eInput;
  };
  Datepicker.prototype.afterGuiAttached = function () {
    this.eInput.focus();
    this.eInput.select();
  };
  Datepicker.prototype.getValue = function () {
    return this.eInput.value;
  };
  Datepicker.prototype.destroy = function () { };
  Datepicker.prototype.isPopup = function () {
    return false;
  };
  return Datepicker;
}

function formatGridDate(date) {
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;
  return [year, month, day].join('-');
}