import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import {
  trigger, state, style, transition,
  animate, group, query, stagger, keyframes
} from '@angular/animations';
import { timingSafeEqual } from 'crypto';
import { ReportService } from '../../service/reports.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';

@Component({
  selector: 'rsa-report-filter',
  templateUrl: './report-filter.component.html',
  styleUrls: ['./report-filter.component.scss']
})
export class ReportFilterComponent implements OnInit {
  @Output()
  displayfilterReport: EventEmitter<any> = new EventEmitter<any>();
  @Input() toggleFilter = false;
  @Input() headersList: any[] = [];
  reportType: string;
  @Input() selectedHeadersList = [];
  @Input() isAllorUnmatched;
  @Input() sortByHeadersList = [];
  @Input() ageingList: any[] = [];
  selectedItems = [];
  resetHeadersList: any[] = [];
  selectedReceiptItems = [];
  selectedValue = 'ASC';
  selectedOrder = 'ASC';
  selectedTemplate;
  selectedTemplateId;
  templateDetailArray = [];
  templateList = [];
  sortByOptions: any[] = [
    { 'id': 'ASC', 'item': 'ASC' },
    { 'id': 'DESC', 'item': 'DESC' }];
  removeduplicte: boolean;
  categary: number;
  constructor(private fb: FormBuilder,
    private route: ActivatedRoute,
    private reportService: ReportService,
    private alertService: AlertService,
    private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.reportType = params['reportName'];
    });
    console.log(this.headersList);
    this.resetHeadersList = this.headersList.map(item => Object.assign({}, item));
    console.warn(this.resetHeadersList);
    this.templateList = [
      { 'id': 1, 'item': 'Template 1' },
      { 'id': 2, 'item': 'Template 2' },
      { 'id': 3, 'item': 'Template 3' },
      { 'id': 4, 'item': 'Template 4' },
      { 'id': 5, 'item': 'Template 5' },
    ];

  }


  // public removeItem(item: any, list: any[]): void {
  //   list.splice(list.indexOf(item), 1);
  //   console.log(this.selectedHeadersList);
  //   console.log(this.sortByHeadersList);
  // }

  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }

  removeDuplicates(arr, prop): any {
    const obj = {};
    for (let i = 0, len = arr.length; i < len; i++) {
      if (!obj[arr[i][prop]]) {
        obj[arr[i][prop]] = arr[i];
      }
    }
    const newArr = [];
    for (let key in obj) {
      newArr.push(obj[key]);
    };

    return newArr;
  }

  onDrag(item?: any) {
    let i: any;
    for (i = 0; i < this.selectedHeadersList.length; i++) {
      if (this.selectedHeadersList[i].Name == item.Name) {
        console.log("header exist");
      }
    }
  }
  onDrop() {
    if (this.selectedHeadersList.length !== 0) {
      this.selectedHeadersList = this.removeDuplicates(this.selectedHeadersList, 'Name');
    }
    if (this.sortByHeadersList.length !== 0) {
      this.sortByHeadersList = this.removeDuplicates(this.sortByHeadersList, 'Name');
      this.sortByHeadersList.sort((a, b) => (a.Name > b.Name) ? 1 : -1);
    }
    console.log(this.selectedHeadersList, 'selectedHeadersList');
    console.log(this.sortByHeadersList, 'sortByHeadersList');
  }

  getUniqueArray(arr, comp) {

    //store the comparison  values in array
    const unique = arr.map(e => e[comp]).
      // store the keys of the unique objects
      map((e, i, final) => final.indexOf(e) === i && i)
      // eliminate the dead keys & return unique objects
      .filter((e) => arr[e]).map(e => arr[e]);

    return unique;

  }

  resetHeaderList(type: string): void {
    if (type === 'selected') {
      if (this.selectedHeadersList) {
        this.selectedHeadersList = [];
        this.templateDetailArray = [];
        this.resetHeaders();
      }
    } else {
      if (this.sortByHeadersList) {
        this.sortByHeadersList = [];
        this.templateDetailArray = [];
      }
    }
  }
  get FilterHeaders(): any {
    const filterHeaders = {} as any;
    filterHeaders.sortByHeadersList = this.sortByHeadersList;
    filterHeaders.selectedHeadersList = this.selectedHeadersList;
    return filterHeaders;
  }
  resetHeaders() {
    this.headersList = [];
    this.headersList = this.resetHeadersList;
    this.templateDetailArray = [];
  }

  resetAllHeadersData() {
    this.selectedHeadersList = [];
    this.templateDetailArray = [];
    this.sortByHeadersList = [];
  }



  viewfilterReport() {
    const filterHeaders = this.FilterHeaders;
    this.displayfilterReport.emit(filterHeaders);
  }

  addAge(): void {
    const lastAge = this.ageingList[this.ageingList.length - 1];
    console.log(lastAge);
    this.ageingList.push({ 'from': lastAge.to, 'to': Number(lastAge.to) + 60 });
  }

  changeOrder(data) {
    console.log(data.item.id, 'data');
    const id = data.item.id;
    this.selectedOrder = id;
    console.log(this.selectedOrder, 'selectedorder');
    if (id == 'ASC') {
      this.sortByHeadersList.sort((a, b) => (a.Name > b.Name) ? 1 : -1);
    } else {
      this.sortByHeadersList.sort((a, b) => (a.Name < b.Name) ? 1 : -1);

    }
  }

  uselectedAge(i, ev) {
    this.selectedItems = [];
    this.ageingList.map((ele, index) => {
      if (this.selectedReceiptItems[index]) {
        this.selectedItems.push(ele);
      }
    });
    console.log(this.selectedItems, 'item');
  }

  changeTemplate(event) {
    console.log(event.srcElement.value, 'item');
    this.selectedTemplateId = Number(event.srcElement.value);
    this.categary = this.isAllorUnmatched === true ? 0 : 1;
    let param = '&templateId=' + this.selectedTemplateId + '&category=' + this.categary;
    if (this.reportType == 'tb') {
      param = '&templateId=' + this.selectedTemplateId;
    }
    const reportType = this.reportType;
    this.reportService.getSavedTemplate(param, reportType).subscribe((data) => {
      console.log(data, 'data');
      if (data.SelectedName != null) {
        this.selectedHeadersList = data.SelectedName;
        this.sortByHeadersList = data.SortingDetails;
        this.selectedValue = data.SortingDetails[0].SortType;
      } else {
        this.alertService.info(`no previous data found for Template ${this.selectedTemplateId}`);
      }

    });

    switch (this.selectedTemplateId) {
      case 1:
        this.selectedTemplate = 'Temp1';
        break;
      case 2:
        this.selectedTemplate = 'Temp2';
        break;
      case 3:
        this.selectedTemplate = 'Temp3';
        break;
      case 4:
        this.selectedTemplate = 'Temp4';
        break;
      case 5:
        this.selectedTemplate = 'Temp5';
        break;
    }
  }

  formatedTemplateDetail() {
    const selectheaderList = this.getUniqueArray(this.selectedHeadersList, 'Name');
    console.log(selectheaderList, 'selectheaderList');
    this.selectedHeadersList.map((ele) => {
      this.templateDetailArray.push({ 'ColumnID': ele.Id, 'SelectedColumn': ele.Id, 'SortedColumn': null });
    });

    this.sortByHeadersList.map((ele, index) => {
      if (this.templateDetailArray.length >= (index + 1)) {
        this.templateDetailArray[index].SortedColumn = ele.Id;
        this.templateDetailArray[index].SortType = this.selectedOrder;
      } else {
        this.templateDetailArray.push({ 'ColumnID': null, 'SelectedColumn': null, 'SortedColumn': ele.Id, 'SortType': this.selectedOrder });
      }
    });
    console.log(this.templateDetailArray, ' this.templateDetailArray');
    // this.getUniqueArray(this.templateDetailArray, 'Name');
    console.log(this.templateDetailArray, ' this.templateDetailArrayafter');
  }

  applyConfigurator() {
    const selectedHeaderArray = this.selectedHeadersList.length < 0;
    const selectedSortArray = this.sortByHeadersList.length < 0;
    const selectedTeamplate = this.selectedTemplate;
    if (!selectedHeaderArray && !selectedSortArray && (selectedTeamplate == null || undefined)) {
      this.alertService.warn('please select all the feilds');
      return false;
    }
    this.formatedTemplateDetail();
    const params = {
      'ReportId': 5,
      'ReportType': 2,
      'TemplateID': this.selectedTemplateId,
      'TemplateName': this.selectedTemplate,
      'UserId': 181,
      'TemplateDetail': this.templateDetailArray
    };
    if (this.reportType == 'tb') {
      params['ReportId'] = 8;
    }
    console.log(JSON.stringify(params), 'params');
    console.log(this.templateDetailArray, ' this.templateDetailArrayafter');
    this.reportService.saveConfiguratorReports(JSON.stringify(params)).subscribe((data) => {
      if (data) {
        this.alertService.success('Sucessfully Created template');
        this.resetAllHeadersData();
      } else {
        this.templateDetailArray = [];
      }
    });
  }

}

