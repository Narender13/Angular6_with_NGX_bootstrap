import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ReportService } from './service/reports.service';

@Component({
  selector: 'app-rsa-reports-home',
  templateUrl: './reports-home.component.html',
  styleUrls: ['./reports-home.component.scss']
})
export class ReportsHomeComponent implements OnInit {
  reportList = [];
  username: string
  welcomeInfo: any = { 'welcomeMsg': 'HELLO!', 'msg1': 'what do you want to analyse', 'msg2': 'today?' };
  constructor(private _service: ReportService) { }

  ngOnInit() {
    this.getReportList();
    this.username = localStorage.getItem('userName');
  }

  getReportList() {
    this._service.getReportsList().subscribe((data) => {
      this.reportList = data;
    });
  }

}
