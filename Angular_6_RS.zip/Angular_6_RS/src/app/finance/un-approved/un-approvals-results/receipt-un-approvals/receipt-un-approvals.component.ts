import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-receipt-un-approvals',
  templateUrl: './receipt-un-approvals.component.html',
  styleUrls: ['./receipt-un-approvals.component.scss']
})
export class ReceiptUnApprovalsComponent implements OnInit {

 
@Input() receiptUnApprovalData: any = [];
@Input() VName:string;
constructor(private modalService: BsModalService) { }

ngOnInit() {
  console.log(this.receiptUnApprovalData, 'receiptUnApprovalData-cpomp');

}

}

