import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'rsa-pending-unapproval-header',
  templateUrl: './un-approval-header.component.html',
  styleUrls: ['./un-approval-header.component.scss']
})
export class UnApprovalHeaderComponent implements OnInit {
  @Input() catid: number;
  constructor(private router: Router) {
  }

  ngOnInit() {
  }

  getVoucherType(vochername) {
    const params = {
      'voucherName': vochername,
    };
    //console.log(params);
    this.router.navigate(['home/search/unapproved'], {
      queryParams: params
    });
  }

}

