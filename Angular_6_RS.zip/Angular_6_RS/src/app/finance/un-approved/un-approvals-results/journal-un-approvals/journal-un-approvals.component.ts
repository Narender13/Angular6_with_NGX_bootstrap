import { Component, OnInit, Input } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
//import { CreateDraftReceiptComponent } from 'src/app/finance/drfats/drafts-results/create-draft-receipt/create-draft-receipt.component';
//import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-journal-un-approvals',
  templateUrl: './journal-un-approvals.component.html',
  styleUrls: ['./journal-un-approvals.component.scss']
})
export class JournalUnApprovalsComponent implements OnInit {

 
  @Input() JournalUnApprovalData: any = [];
  @Input() VName:string;
  constructor(private modalService: BsModalService) { }
  
  ngOnInit() {
    console.log(this.JournalUnApprovalData, 'JournalUnApprovalData-cpomp');
  
  }

}

