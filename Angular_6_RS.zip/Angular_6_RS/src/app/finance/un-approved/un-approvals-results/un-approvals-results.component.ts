import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UnApprovalsService } from './services/unapprovals.service';
import { SharedService } from '../../services/shared.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';

@Component({
  selector: 'rsa-un-approvals-results',
  templateUrl: './un-approvals-results.component.html',
  styleUrls: ['./un-approvals-results.component.scss']
})
export class UnApprovalsResultsComponent implements OnInit {

  voucherName;
  voucherCount;
  receiptUnApprovalsData: any = [];
  debitnoteUnApprovalsData: any = [];
  creditnoteUnApprovalsData: any = [];
  paymentUnApprovalsData: any = [];
  JournalUnApprovalsData: any = [];


  constructor(private route: ActivatedRoute, private unApprovalService: UnApprovalsService,
    private sharedService: SharedService, ) { }

  ngOnInit() {

    this.route.queryParams.subscribe(params => {
      // console.log(params, "pendingApprovals");
      this.voucherName = params['voucherName'];
      this.voucherCount = params['voucherCount'];
      this.getUnAprovalDetails(this.voucherName);
    });
    this.refreshGridOnFinalize();
  }

  refreshGridOnFinalize() {
    this.sharedService.getMessage().subscribe((data) => {
      console.log(data, 'data');
      const voucherName = data.voucherName;
      const message = data.message;
      console.log(voucherName, message, 'voucherName message');
      if (message === 'save-voucher') {
        this.getUnAprovalDetails(voucherName);
      }
    });
  }

  getUnAprovalDetails(voucherName) {
    console.log(voucherName);
    if (voucherName == 'Receipts') {
      this.getUnApprovalsReceipt();
    }
    if (voucherName == 'Debit Note') {
      this.getUnApprovalsDebitnote();
    }
    if (voucherName == 'Credit Note') {
      this.getUnApprovalsCreditnote();
    }
    if (voucherName == 'Payments') {
      this.getUnApprovalsPayment();
    }
    if (voucherName == 'JV') {
      this.getUnApprovalsJournal();
    }

  }

  getUnApprovalsReceipt() {
    const param = 'type=Unapproved&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    console.log(param, "paramss...");
    this.unApprovalService.getUnApprovalsReceipts(param).subscribe(data => {
      this.receiptUnApprovalsData = data;
      console.log(this.receiptUnApprovalsData, 'ReceiptData');
    });
  }
  getUnApprovalsDebitnote() {
    const param = 'type=Unapproved&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.unApprovalService.getUnApprovalDebitnotes(param).subscribe(data => {
      this.debitnoteUnApprovalsData = data;
      console.log(data, 'Dndata');

    });
  }
  getUnApprovalsCreditnote() {
    const param = 'type=Unapproved&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.unApprovalService.getUnApprovalCreditnotes(param).subscribe(data => {
      this.creditnoteUnApprovalsData = data;
      console.log(data, 'Cndata...');
    });
  }

  getUnApprovalsPayment() {
    const param = 'type=Unapproved&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.unApprovalService.getUnApprovalPayments(param).subscribe(data => {
      this.paymentUnApprovalsData = data;
      console.log(data, 'payment Data');
    });
  }


  getUnApprovalsJournal() {
    const param = 'type=Unapproved&loggedInUserId='+localStorage.getItem(RSAConstants.LoggedInUserId);
    this.unApprovalService.getUnApprovalJournals(param).subscribe(data => {
      this.JournalUnApprovalsData = data;
      console.log(data, 'jvdata');
    });
  }

}
