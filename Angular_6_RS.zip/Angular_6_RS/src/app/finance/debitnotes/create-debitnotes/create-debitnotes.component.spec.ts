import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDebitnotesComponent } from './create-debitnotes.component';

describe('CreateDebitnotesComponent', () => {
  let component: CreateDebitnotesComponent;
  let fixture: ComponentFixture<CreateDebitnotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateDebitnotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateDebitnotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
