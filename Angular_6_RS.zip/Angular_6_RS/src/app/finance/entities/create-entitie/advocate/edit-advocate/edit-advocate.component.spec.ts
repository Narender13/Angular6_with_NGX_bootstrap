import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAdvocateComponent } from './edit-advocate.component';

describe('EditAdvocateComponent', () => {
  let component: EditAdvocateComponent;
  let fixture: ComponentFixture<EditAdvocateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditAdvocateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditAdvocateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
