import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RepairerService {

    constructor(private http: HttpClient) { }
  
    createRepairer(param: any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATEREPAIRER,param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createRepairer')));
    }
    getPayeeBankNames() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankNames')));

    }
   
    getVatCode() {

        return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVatCode')));
    }
    getVatRegCountry() {

        return this.http.get<any>(RSAENDPOINTConstants.VATREGISTRATIONCOUNTRY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVatRegCountry')));
    }
    getStatus() {

        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
          map(res => res),
            catchError(handleErrorObservable<any>('getStatus')));
    }
    getRepairerDetails(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETREPAIRER+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getRepairerDetails')));
    }
    updateRepairerDetails(params:any){
        return this.http.put<any>(RSAENDPOINTConstants.UPDATEREPAIRER,params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateRepairerDetails')));
    }
}
