import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { PolicestationService } from './service/policestation.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';

@Component({
    selector: 'rsa-create-police-station',
    templateUrl: './create-police-station.component.html',
    styleUrls: ['./create-police-station.component.scss'],
    animations: [slideInOut]
})
export class CreatePoliceStationComponent implements OnInit {
    policeStationForm: FormGroup;
    isArabicField = false;
    address = false;
    address1 = false;
    address2 = false;
    submitted = false;
    errorDesc: boolean;
    errorEngAddress1: boolean;
    errorEngAddress2: boolean;
    errorEngAddress3: boolean;
    returnValue: any;
    errorDescExists:boolean;
    constructor(private fb: FormBuilder, protected policeStationService: PolicestationService,public bsModalRef: BsModalRef,
        private modalService: BsModalService) { }
    ngOnInit() {
        this.createEntiteForm();
        this.fieldStatusChanges();
    }
    createEntiteForm(): void {
        this.policeStationForm = this.fb.group({
            DescriptionEnglish: ['', Validators.required],
            DescriptionArabic:[''],
            EngAddress1: ['', Validators.required],
            EngAddress2: ['', Validators.required],
            EngAddress3: ['', Validators.required],
            ArabicAddress1: [''],
            ArabicAddress2: [''],
            ArabicAddress3: [''],
            Type: [''],
            PreparedByStr:[localStorage.getItem('userId')],
            IsValid:[0]
        });
    }
    clearerrors() {
        this.errorDesc = false;
        this.errorEngAddress1 = false;
        this.errorEngAddress2 = false;
        this.errorEngAddress3 = false;
        this.errorDescExists=false;
    }
    get policDesc() {
        return this.policeStationForm.get('DescriptionEnglish');
    }
    get policEngAddress1() {
        return this.policeStationForm.get('EngAddress1');
    }
    get policEngAddress2() {
        return this.policeStationForm.get('EngAddress2');
    }
    get policEngAddress3() {
        return this.policeStationForm.get('EngAddress3');
    }
    fieldStatusChanges() {

        this.clearerrors();

        this.policDesc.statusChanges.subscribe(
            status => {
                this.errorDesc = (status == 'INVALID');
            }
        );
        this.policEngAddress1.statusChanges.subscribe(
            status => {
                this.errorEngAddress1 = (status == 'INVALID');
            }
        );
        this.policEngAddress2.statusChanges.subscribe(
            status => {
                this.errorEngAddress2 = (status == 'INVALID');
            }
        );
        this.policEngAddress3.statusChanges.subscribe(
            status => {
                this.errorEngAddress3 = (status == 'INVALID');
            }
        );
    }
    setPoliceStationFormValues() {
        let clonedFormValues: any = {
            
                "DescriptionEnglish":this.policeStationForm.value.DescriptionEnglish,
                "DescriptionArabic":this.policeStationForm.value.DescriptionArabic,
                                "address":{
                "ArabicAddress1":this.policeStationForm.value.ArabicAddress1,
                "EngAddress1":this.policeStationForm.value.EngAddress1,
                "ArabicAddress2":this.policeStationForm.value.ArabicAddress2,
                "EngAddress2":this.policeStationForm.value.EngAddress2,
                "ArabicAddress3":this.policeStationForm.value.ArabicAddress3,
                "EngAddress3":this.policeStationForm.value.EngAddress3
                },
                "Type":this.policeStationForm.value.Type,
                "PreparedBy":this.policeStationForm.value.PreparedByStr 
            }
        return clonedFormValues;    
    } 
    submitForm() {
        this.errorDesc = this.policDesc.invalid;
        this.errorEngAddress1 = this.policEngAddress1.invalid;
        this.errorEngAddress2 = this.policEngAddress2.invalid;
        this.errorEngAddress3 = this.policEngAddress3.invalid; 
        if (this.policeStationForm.invalid) {
            return;
        }
        else { 
            let clonePoliceStationForm: any = this.setPoliceStationFormValues();
           // console.log(JSON.stringify(clonePoliceStationForm), 'second form');
            this.policeStationService.createPoliceStation(JSON.stringify(clonePoliceStationForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(this.returnValue, 'this.returnValue');
                    if(this.returnValue.IsValid==0){
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent ="Police Station successfully created.";
                        this.bsModalRef.content.smallMessage="ID: "+this.returnValue.Code;
                        this.bsModalRef.content.bigMessage ="Description: "+this.returnValue.EngName;
                        this.bsModalRef.content.actionBtn ="Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if(data=='Close'){
                                console.log("close btn clicked");
                            }else {
                                console.log(" else close");
                            }
                            this.resetForm();
                        });
                   }
                   else if(this.returnValue.IsValid==2){
                    this.errorDescExists=true;
                   } 
                });
            errorRturn => {
                console.log(errorRturn);
            }
      }
    }
    resetForm() {
        let arrayFormFields = ['DescriptionEnglish', 'DescriptionArabic', 'EngAddress1', 'EngAddress2', 'EngAddress3',
        'ArabicAddress1', 'ArabicAddress2', 'ArabicAddress3', 'Type'];     
     // this.policeStationForm.controls['PreparedByStr'].reset("test@ae.rsagroup.com");
      this.policeStationForm.controls['IsValid'].reset(0);
      arrayFormFields.forEach((val) => {
        if (this.policeStationForm.controls[val] != null && this.policeStationForm.controls[val] != undefined) {
          this.policeStationForm.controls[val].reset();
        }
      });
      this.clearerrors();
    }
} 
