import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PolicestationService {

  constructor(private http: HttpClient) { }
  createPoliceStation(params:any) {
      return this.http.post<any>(RSAENDPOINTConstants.CREATEPOLICESTATION, params).pipe(
          map(res => res),
          catchError(handleErrorObservable<any>('createPoliceStation')));
  }
getPoliceStationDetails(params:any) {
  return this.http.get<any>(RSAENDPOINTConstants.GETPOLICESTATION+params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('getPoliceStationDetails')));
  }
updatePoliceStation(params:any) {
  return this.http.put<any>(RSAENDPOINTConstants.UPDATEPOLICESTATION,params).pipe(
      map(res => res),
      catchError(handleErrorObservable<any>('updatePoliceStation')));
  }
}
