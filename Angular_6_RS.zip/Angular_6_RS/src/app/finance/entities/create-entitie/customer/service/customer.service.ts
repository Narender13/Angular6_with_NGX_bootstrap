import { Injectable } from '@angular/core';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { catchError, map, shareReplay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

    constructor(private http: HttpClient) { }
    createCustomer(params:any) {
        return this.http.post<any>(RSAENDPOINTConstants.CREATECUSTOMER, params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createCustomer')));
    }
    getPayeeBankNames() {
        return this.http.get<any>(RSAENDPOINTConstants.LOADPAYEEBANKNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getPayeeBankNames')));

    }
    getBranchNames(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETBranch+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getBranchNames')));
    }
    getCustomerType() {
       
        return this.http.get<any>(RSAENDPOINTConstants.CUSTOMERTYPE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCustomerType')));
    }
    getBrokerNames() {

        return this.http.get<any>(RSAENDPOINTConstants.BROKERNAMES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getBrokerNames')));
    }
    getTitle() {

        return this.http.get<any>(RSAENDPOINTConstants.TITLES).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getTitle')));
    }
    getVatCode() {

        return this.http.get<any>(RSAENDPOINTConstants.VATCODE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getVatCode')));
    }
    getNations() {

        return this.http.get<any>(RSAENDPOINTConstants.NATIONALITY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getNations')));
    }
    getCustomerGroup(params:any) {

        return this.http.get<any>(RSAENDPOINTConstants.CUSTOMERGROUP+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCustomerGroup')));
    }
    getStatus() {

        return this.http.get<any>(RSAENDPOINTConstants.STATUS).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getStatus')));
    }
    getAcExcecutive() {

        return this.http.get<any>(RSAENDPOINTConstants.ACCOUNTEXECUTIVE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAcExcecutive')));
    }
    getCustomerDetails(params:any) {
        return this.http.get<any>(RSAENDPOINTConstants.GETCUSTOMER+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCustomerDetails')));
    }
    updateCustomerDetails(params:any){
        return this.http.put<any>(RSAENDPOINTConstants.UPDATECUSTOMER,params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateCustomerDetails')));
    }
    updateCascade(params:any){
        return this.http.get<any>(RSAENDPOINTConstants.UPDATECASCADE+params).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('updateCascade')));
    }

}
