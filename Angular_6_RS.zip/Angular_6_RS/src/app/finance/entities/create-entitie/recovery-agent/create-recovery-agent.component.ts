import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';
import { RecoveryService } from './service/recovery.service';
import { catchError, map, shareReplay } from 'rxjs/operators'; 
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'rsa-create-recovery-agent',
  templateUrl: './create-recovery-agent.component.html',
  styleUrls: ['./create-recovery-agent.component.scss'],
  animations: [slideInOut]
})

export class CreateRecoveryAgentComponent implements OnInit {
    recoveryForm: FormGroup;
    //clonedCustomer: FormGroup;
    isArabicField = false;
    address = false;
    address1 = false;
    address2 = false;
    submitted = false;
    today = new Date();

    branchList: any[];
    vatcodeList: any[];
    VatRegCountryList: any[];
    typeList: any[];
    statusList: any[];  
    returnValue: any;

    errorName: boolean;
    errorNameExists: boolean;
    errorVATRegNumber: boolean;
    errorVATRegNumberExists: boolean;
    errorVATRegCountry: boolean;
    errorEmail: boolean;
    errorEmailExists: boolean;
    errorPhone: boolean;
    errorPhoneExists: boolean;
    errorMobile: boolean;
    errorMobileExists: boolean;
    errorBranch: boolean;
    errorEngAddress1: boolean;
    errorEngAddress2: boolean;
    errorEngAddress3: boolean;
    //errorPostalCode: boolean;
    errorSerialNumber: boolean;

    selectedTypeVal: any;
    errorTypeExists: boolean;
    @ViewChild('newTypename') private newTypename: ElementRef;
    isTypeAdded: boolean;
    //nativeElement: boolean;

    get recoveryName() { return this.recoveryForm.get('Name'); };
    get recoveryVATRegNumber() { return this.recoveryForm.get('VATRegNumber'); };
    get recoveryVATRegCountry() { return this.recoveryForm.get('VATRegCountry'); };
    get recoveryEmail() { return this.recoveryForm.get('Email'); };
    get recoveryPhone() {  return this.recoveryForm.get('Phone'); };
    get recoveryMobile() { return this.recoveryForm.get('Mobile'); };
    get recoveryBranch() { return this.recoveryForm.get('Branch'); };
    get recoveryEngAddress1() { return this.recoveryForm.get('EngAddress1'); };
    get recoveryEngAddress2() { return this.recoveryForm.get('EngAddress2'); };
    get recoveryEngAddress3() { return this.recoveryForm.get('EngAddress3'); };
    get recoverySerialNumber() { return this.recoveryForm.get('SerialNumber'); };

    fieldStatusChanges() {
        this.clearerrors();
        this.recoveryName.statusChanges.subscribe(
            status => { this.errorName = (status == 'INVALID'); }
        );
        this.recoveryVATRegNumber.statusChanges.subscribe(
            status => { this.errorVATRegNumber = (status == 'INVALID'); }
        );
        this.recoveryVATRegCountry.statusChanges.subscribe(
            status => { this.errorVATRegCountry = (status == 'INVALID'); }
        );
        this.recoveryEmail.statusChanges.subscribe(
            status => { this.errorEmail = (status == 'INVALID'); }
        );
        this.recoveryPhone.statusChanges.subscribe(
            status => { this.errorPhone = (status == 'INVALID'); }
        );
        this.recoveryMobile.statusChanges.subscribe(
            status => { this.errorMobile = (status == 'INVALID'); }
        );
        this.recoveryBranch.statusChanges.subscribe(
            status => { this.errorBranch = (status == 'INVALID'); }
        );
        this.recoveryEngAddress1.statusChanges.subscribe(
            status => { this.errorEngAddress1 = (status == 'INVALID'); }
        );
        this.recoveryEngAddress2.statusChanges.subscribe(
            status => { this.errorEngAddress2 = (status == 'INVALID'); }
        );
        this.recoveryEngAddress3.statusChanges.subscribe(
            status => { this.errorEngAddress3 = (status == 'INVALID'); }
        );
        this.recoverySerialNumber.statusChanges.subscribe(
            status => { this.errorSerialNumber = (status == 'INVALID'); }
        );
    }

    clearerrors() {
        this.errorName = false;
        this.errorNameExists = false;
        this.errorVATRegNumber = false;
        this.errorVATRegNumberExists = false;
        this.errorVATRegCountry = false;
        this.errorEmail = false;
        this.errorEmailExists = false;
        this.errorPhone = false;
        this.errorPhoneExists = false;
        this.errorMobile = false;
        this.errorMobileExists = false;
        this.errorBranch = false;
        this.errorEngAddress1 = false;
        this.errorEngAddress2 = false;
        this.errorEngAddress3 = false;
        this.errorSerialNumber = false;    
    }

    constructor(private fb: FormBuilder, protected recoveryService: RecoveryService, public bsModalRef: BsModalRef,private modalService: BsModalService) { }
    
    get f() { return this.recoveryForm.controls; }

    ngOnInit() {
        this.createEntityForm();  
        this.fieldStatusChanges();
        this.getBranchNames();
        this.getVATCode();
        this.getVATRegCountry();
        this.getType();
        this.getStatus();     
    }

    createEntityForm():void{ 
        this.recoveryForm = this.fb.group({   
                Code: [1],
                Name: ['', Validators.required],
                NameArabic: [''],
                VATCode: [''],
                VATRegNumber: ['', Validators.required],
                VATRate: [],
                Email: ['', [Validators.required, Validators.email]],
                Phone: ['', Validators.required],
                Mobile: ['', Validators.required],
                Fax: [''],
                Branch: [localStorage.getItem('locationcode'), Validators.required],
                VATRegCountry: ['', Validators.required],
                PreparedByStr: [localStorage.getItem('userId')],
                IsValid: [0],
                EngAddress1: ['', Validators.required],
                ArabicAddress1: [''],
                EngAddress2: ['', Validators.required],
                ArabicAddress2: [''],
                EngAddress3: ['', Validators.required],
                ArabicAddress3: [''],
                EngZIP: [''], 
                Rating: [''],
                Fee: [''],
                SerialNumber: ['', Validators.required],
                Type: [''],
                NonAgencyThresholdLimit: [''],
                AgencyThresholdLimit: [''],
                Status: [''],   
            });
    }

    setRecoveryFormValues() {
        let clonedFormValues: any = {
            "NameArabic": this.recoveryForm.value.NameArabic,
            "Name": this.recoveryForm.value.Name,
            "VATCode": this.recoveryForm.value.VATCode,
            "VATRegNumber": this.recoveryForm.value.VATRegNumber,
            "VATRegCountry": this.recoveryForm.value.VATRegCountry,
            "Email": this.recoveryForm.value.Email,
            "PreparedByStr": this.recoveryForm.value.PreparedByStr,
            "Phone": this.recoveryForm.value.Phone,
            "Mobile": this.recoveryForm.value.Mobile,
            "Branch": this.recoveryForm.value.Branch,
            "Status": this.recoveryForm.value.Status,
            "IsValid": this.recoveryForm.value.IsValid,
            "address": {
                "ArabicAddress1": this.recoveryForm.value.ArabicAddress1,
                "EngAddress1": this.recoveryForm.value.EngAddress1,
                "ArabicAddress2": this.recoveryForm.value.ArabicAddress2,
                "EngAddress2": this.recoveryForm.value.EngAddress2,
                "ArabicAddress3": this.recoveryForm.value.ArabicAddress3,
                "EngAddress3": this.recoveryForm.value.EngAddress3,
                "EngZIP": this.recoveryForm.value.EngZIP,
                "Fax": this.recoveryForm.value.Fax,
            },
            "additionalInfo": {
                "Rating": this.recoveryForm.value.Rating,
                "Fee": this.recoveryForm.value.Fee,
                "SerialNumber": this.recoveryForm.value.SerialNumber,
                "Type": this.recoveryForm.value.Type,
                "NonAgencyThresholdLimit": this.recoveryForm.value.NonAgencyThresholdLimit,
                "AgencyThresholdLimit": this.recoveryForm.value.AgencyThresholdLimit,
                
            },
            "RecTypeDetails":
            {
                "RecoveryADescription": this.isTypeAdded ? this.typeList[this.typeList.length - 1].E_desc : "",
                "RecoveryEDescription": this.isTypeAdded ? this.typeList[this.typeList.length - 1].E_desc : "",
                "IsNew": this.recoveryForm.controls['Type'].value === '0' ? true : false
            }
           

        }
        return clonedFormValues;
    }


    setErrorInvalid() {
        this.errorName = this.recoveryName.invalid;
        this.errorVATRegNumber = this.recoveryVATRegNumber.invalid;
        this.errorVATRegCountry = this.recoveryVATRegCountry.invalid;
        this.errorEmail = this.recoveryEmail.invalid;
        this.errorPhone = this.recoveryPhone.invalid;
        this.errorMobile = this.recoveryMobile.invalid;
        this.errorBranch = this.recoveryBranch.invalid;
        this.errorEngAddress1 = this.recoveryEngAddress1.invalid;
        this.errorEngAddress2 = this.recoveryEngAddress2.invalid;
        this.errorEngAddress3 = this.recoveryEngAddress3.invalid;
        this.errorSerialNumber = this.recoverySerialNumber.invalid;
    }

    onSubmit() {
        this.setErrorInvalid();
        // stop here if form is invalid
        if (this.recoveryForm.invalid) {
            return;
        }
        else {
            console.log(this.recoveryForm.value, 'this.sdf');
            let cloneRecoveryForm: any = this.setRecoveryFormValues();
            console.log(JSON.stringify(cloneRecoveryForm), 'second form');
            
           this.recoveryService.createRecovery(JSON.stringify(cloneRecoveryForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;
                    console.log(this.returnValue, 'this.returnValue');

                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = " Recovery Agent Successfully Created";
                        this.bsModalRef.content.smallMessage = "ID: " + this.returnValue.Code;
                        this.bsModalRef.content.bigMessage ="Name: "+ this.returnValue.EngName;
                        // this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.resetForm();
                        });
                    }
                    else if (this.returnValue.IsValid == 1) {
                        //alert modal
                        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Alert! Other  VAT Registeration Number remaining fields  already exists";
                        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Proceed";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log("datat" + data);
                            if (data = 'Proceed') {
                                console.log("proceed btn clicked");
                                this.recoveryForm.value.IsValid = 1;
                                this.onSubmit();
                            }
                            ////else if (data = 'PROCEED') {
                            ////    console.log("erer");
                            ////}
                            else {
                                console.log(" else close");
                            }
                            //  this.modalService.hide(1);
                        });
                        //end for alert modal
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.errorNameExists = true;
                        this.errorVATRegNumberExists = true;
                        this.errorEmailExists = true;
                        this.errorPhoneExists = true;
                        this.errorMobileExists = true;
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
    }

    resetForm() {
        let arrayFormFields = ['Name','NameArabic','VATCode','VATRegNumber','VATRate','Email','Phone','Mobile','Fax','VATRegCountry','EngAddress1',
            'ArabicAddress1','EngAddress2','ArabicAddress2','EngAddress3','ArabicAddress3','EngZIP','Rating','Fee','SerialNumber','Type','NonAgencyThresholdLimit',
            'AgencyThresholdLimit','Status'];
        this.recoveryForm.controls['Code'].reset(1);
       // this.recoveryForm.controls['PreparedByStr'].reset("test@ae.rsagroup.com");
        this.recoveryForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.recoveryForm.controls[val] != null && this.recoveryForm.controls[val] != undefined) {
                this.recoveryForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    
    getBranchNames() {
        const param = 'ctyCode=' + localStorage.getItem('countrycode') +
            '&regCode=' + localStorage.getItem('regioncode');
        this.recoveryService.getBranchNames(param).subscribe(
            dataReturn => {
                this.branchList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    } 
    getVATCode() {
        this.recoveryService.getVATCode().subscribe(
            dataReturn => {
                this.vatcodeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    } 
    getVATRegCountry() {
        this.recoveryService.getVATRegCountry().subscribe(
            dataReturn => {
                this.VatRegCountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }   
    getType() {
        this.recoveryService.getType().subscribe(
            dataReturn => {
                this.typeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    } 
    getStatus() {
        this.recoveryService.getStatus().subscribe(
            dataReturn => {
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    setVatRate(vatvalue: number) {
        this.vatcodeList.forEach(element => {
            if (element.Code == vatvalue) {
                this.recoveryForm.controls['VATRate'].setValue(element.VATRate);
            }
        });
    } 


    addNewType(catValue: any) {
        if (catValue === 'newType') {
            console.log(catValue + " new category " + this.recoveryForm.controls['Type'].value);
            this.selectedTypeVal = catValue;
            this.recoveryForm.controls['Type'].setValue("");
        }

    }
    addToTypeList() {
        if (this.newTypename.nativeElement.value) {
            if (this.checkDuplicatesInTypeList() == true) {
                console.log("gggg");
                this.errorTypeExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newTypename.nativeElement.value };
                this.isTypeAdded = true;
                this.typeList.push(newCategory);
                // this.agentForm.controls['Category'].setValue("");
                this.selectedTypeVal = "";
                this.errorTypeExists = false;
            }

        }
    }
    hideAddType() {
        this.recoveryForm.controls['Type'].setValue("");
        this.selectedTypeVal = "";
        this.errorTypeExists = false;
    }
    checkDuplicatesInTypeList() {
        let duplicateValueExists: boolean = false;
        this.typeList.forEach((item) => {
            if (this.newTypename.nativeElement.value.toLowerCase().toString() === item.E_desc.toLowerCase().toString()) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }

}


