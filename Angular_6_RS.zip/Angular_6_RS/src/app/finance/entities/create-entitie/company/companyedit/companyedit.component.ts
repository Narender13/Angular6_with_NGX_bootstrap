import { Component, TemplateRef, OnInit, Input } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../../shared/animation/slidein';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CompanyService } from 'src/app/finance/entities/create-entitie/company/service/company.service';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { catchError, map, shareReplay, debounce } from 'rxjs/operators';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'rsa-companyedit',
  templateUrl: './companyedit.component.html',
  styleUrls: ['./companyedit.component.scss'],
  animations: [slideInOut]
})
export class CompanyeditComponent implements OnInit {
  companyForm: FormGroup;
  clonedCompany: FormGroup;
  name = false;
  shortname = false;
  address = false;
  address1 = false;
  submitted = false;
  today = new Date();
  branchForm: FormGroup;
  collapsetoheader: boolean;
  branchname = false;
  branchshortname = false;
  branchaddress = false;
  branchaddress1 = false;
  addbranch = false;
  zip = false;
  companyTypeList: any = [];
  VATCodeList: any = [];
  CategoryList: any = [];
  StatusList: any = [];
  BranchStatusList: any = [];
  BranchList: any[] = [];
  modalRef: BsModalRef;
  Category: any = [];
  errorType: boolean;
  errorName: boolean;
  errorNameExists: boolean;
  errorShortName: boolean;
  errorRegistrationNo: boolean;
  errorRegNoExists: boolean;
  errorRegistrationExpiry: boolean;
  errorVATRegistrationNo: boolean;
  errorVatRegnoExists: boolean;
  errorEmail: boolean;
  errorEmailExists: boolean;
  errorPhoneNumber: boolean;
  errorPhonenoExists: boolean;
  errorMobileNumber: boolean;
  errorMobilenoExists: boolean;
  errorEngAddress1: boolean;
  errorBuildingNumber: boolean;
  errorEngZIP: boolean;
  errorBranchName: boolean;
  errorBranchShortName: boolean;
  errorBranchEmail: boolean;
  errorBranchPhoneNumber: boolean;
  errorBranchMobileNumber: boolean;
  errorBranchEngAddress1: boolean;
  errorBranchEngZIP: boolean;
  CompanyService: any;
  returnValue: any;
  @Input() entityCode: number;
  editFormOption: boolean;
  branchCodeValue: number = 0;
  branchViewEditMode: boolean;
  errorBranchNameExists: boolean;
  errorBranchPhoneExists: boolean;
  errorBranchMobileExists: boolean;
  errorBranchEmailExists: boolean;
  viewOnlyMode: boolean;
  closeInView:boolean;
  constructor(private fb: FormBuilder, private modalService: BsModalService,
    protected companyservice: CompanyService, public bsModalRef: BsModalRef) { }
  ngOnInit() {
    this.createEntiteForm();
    this.fieldStatusChanges();
    this.getCompanyType();
    this.getVatCode();
    this.getCategory();
    this.getStatus();
    this.getBranchStatus();
    this.companyForm.disable();
    this.getCompanyDetails();
  }
  createEntiteForm(): void {
    this.companyForm = this.fb.group({
      //companyInformation: this.fb.group({
      Code: [this.entityCode],
      Type: ['', Validators.required],
      EngName: ['', Validators.required],
      ArabicName: [''],
      EnShortName: ['', Validators.required],
      ArShortName: [''],
      RegistrationNo: ['', Validators.required],
      RegistrationExpiry: ['', Validators.required],
      VATCode: [''],
      VATRegistrationNo: ['', Validators.required],
      EngEmail: ['', [Validators.required, Validators.email]],
      PhoneNumber: ['', Validators.required],
      MobileNumber: ['', Validators.required],
      Fax: [''],
      EngAddress1: ['', Validators.required],
      ArabicAddress1: [''],
      EngAddress2: [''],
      ArabicAddress2: [''],
      EngZIP: ['', Validators.required],
      Incorporated: [''],
      Category: [''],
      FacAlert: [''],
      AddBranch: [''],
      Status: [''],
      ModifiedByStr: [localStorage.getItem('userId')],
      IsValid: [0],
      Branch: [localStorage.getItem('locationcode')]
    });
    this.branchForm = this.fb.group({
      BranchCode: [''],
      EngName: ['', Validators.required],
      ArabicName: [''],
      EnShortName: ['', Validators.required],
      ArShortName: [''],
      EngEmail: ['', [Validators.required, Validators.email]],
      PhoneNumber: ['', Validators.required],
      MobileNumber: ['', Validators.required],
      Fax: [''],
      EngAddress1: ['', Validators.required],
      ArabicAddress1: [''],
      EngAddress2: [''],
      ArabicAddress2: [''],
      EngZIP: ['', Validators.required],
      ArabicZIP: [''],
      Status: [''],
      IsValue:['']
    });
  }
  clearerrors() {
    this.errorType = false;
    this.errorName = false;
    this.errorNameExists = false;
    this.errorShortName = false;
    this.errorRegistrationNo = false;
    this.errorRegNoExists = false;
    this.errorRegistrationExpiry = false;
    this.errorVATRegistrationNo = false;
    this.errorVatRegnoExists = false;
    this.errorEmail = false;
    this.errorEmailExists = false;
    this.errorPhoneNumber = false;
    this.errorPhonenoExists = false;
    this.errorMobileNumber = false;
    this.errorMobilenoExists = false;
    this.errorEngAddress1 = false;
    this.errorEngZIP = false;
  }
  clearBranchErrors() {
    this.errorBranchName = false;
    this.errorBranchShortName = false;
    this.errorBranchEmail = false;
    this.errorBranchMobileNumber = false;
    this.errorBranchEngZIP = false;
    this.errorBranchPhoneNumber = false;
    this.errorBranchEngAddress1 = false;
    this.errorBranchNameExists = false;
    this.errorBranchPhoneExists = false;
    this.errorBranchMobileExists = false;
    this.errorBranchEmailExists = false;
  }
  get f() {
    return this.companyForm.controls;
  }
  get g() {
    return this.branchForm.controls;
  }
  get compType() {
    return this.companyForm.get('Type');
  }
  get compName() {
    return this.companyForm.get('EngName');
  }
  get compShortName() {
    return this.companyForm.get('EnShortName');
  }
  get compRegistrationNo() {
    return this.companyForm.get('RegistrationNo');
  }
  get compRegistrationExpiry() {
    return this.companyForm.get('RegistrationExpiry');
  }
  get compVATRegistrationNo() {
    return this.companyForm.get('VATRegistrationNo');
  }
  get compEmail() {
    return this.companyForm.get('EngEmail');
  }
  get compPhoneNumber() {
    return this.companyForm.get('PhoneNumber');
  }
  get compMobileNumber() {
    return this.companyForm.get('MobileNumber');
  }
  get compEngAddress1() {
    return this.companyForm.get('EngAddress1');
  }

  get compEngZIP() {
    return this.companyForm.get('EngZIP');
  }
  get compBranchName() {
    return this.branchForm.get('EngName');
  }
  get compBranchShortName() {
    return this.branchForm.get('EnShortName');
  }
  get compBranchEmail() {
    return this.branchForm.get('EngEmail');
  }
  get compBranchPhoneNumber() {
    return this.branchForm.get('PhoneNumber');
  }
  get compBranchMobileNumber() {
    return this.branchForm.get('MobileNumber');
  }
  get compBranchEngAddress1() {
    return this.branchForm.get('EngAddress1');
  }
  get compBranchEngZIP() {
    return this.branchForm.get('EngZIP');
  }
  changeRegistrationExpiryDate() {
    if (this.companyForm.controls['RegistrationExpiry'].value) {
      const RegistrationExpiry = new Date(this.companyForm.controls['RegistrationExpiry'].value);
      this.companyForm.controls['RegistrationExpiry'].setValue(new DatePipe('en-US').transform(RegistrationExpiry, 'dd/MM/yyyy'));
    }
  }
  fieldStatusChanges() {
    this.clearerrors();
    this.clearBranchErrors();
    this.compType.statusChanges.subscribe(
      status => {
        this.errorType = (status == 'INVALID');
      }
    );
    this.compName.statusChanges.subscribe(
      status => {
        this.errorName = (status == 'INVALID');
      }
    );
    this.compShortName.statusChanges.subscribe(
      status => {
        this.errorShortName = (status == 'INVALID');
      }
    );
    this.compRegistrationNo.statusChanges.subscribe(
      status => {
        this.errorRegistrationNo = (status == 'INVALID');
      }
    );
    this.compRegistrationExpiry.statusChanges.subscribe(
      status => {
        this.errorRegistrationExpiry = (status == 'INVALID');
      }
    );
    this.compVATRegistrationNo.statusChanges.subscribe(
      status => {
        this.errorVATRegistrationNo = (status == 'INVALID');
      }
    );
    this.compEmail.statusChanges.subscribe(
      status => {
        this.errorEmail = (status == 'INVALID');
      }
    );
    this.compPhoneNumber.statusChanges.subscribe(
      status => {
        this.errorPhoneNumber = (status == 'INVALID');
      }
    );
    this.compMobileNumber.statusChanges.subscribe(
      status => {
        this.errorMobileNumber = (status == 'INVALID');
      }
    );
    this.compEngAddress1.statusChanges.subscribe(
      status => {
        this.errorEngAddress1 = (status == 'INVALID');
      }
    );
    this.compEngZIP.statusChanges.subscribe(
      status => {
        this.errorEngZIP = (status == 'INVALID');
      }
    );
    this.compBranchName.statusChanges.subscribe(
      status => {
        this.errorBranchName = (status == 'INVALID');
      }
    );
    this.compBranchShortName.statusChanges.subscribe(
      status => {
        this.errorBranchShortName = (status == 'INVALID');
      }
    );
    this.compBranchEmail.statusChanges.subscribe(
      status => {
        this.errorBranchEmail = (status == 'INVALID');
      }
    );
    this.compBranchPhoneNumber.statusChanges.subscribe(
      status => {
        this.errorBranchPhoneNumber = (status == 'INVALID');
      }
    );
    this.compBranchMobileNumber.statusChanges.subscribe(
      status => {
        this.errorBranchMobileNumber = (status == 'INVALID');
      }
    );
    this.compBranchEngAddress1.statusChanges.subscribe(
      status => {
        this.errorBranchEngAddress1 = (status == 'INVALID');
      }
    );
    this.compBranchEngZIP.statusChanges.subscribe(
      status => {
        this.errorBranchEngZIP = (status == 'INVALID');
      }
    );
  }
  setCompanyFormValues() {
    let clonedFormValues: any = {
      "Type": this.companyForm.value.Type,
      "EngName": this.companyForm.value.EngName,
      "ArabicName": this.companyForm.value.ArabicName,
      "EnShortName": this.companyForm.value.EnShortName,
      "ArShortName": this.companyForm.value.ArShortName,
      "RegistartionNo": this.companyForm.value.RegistrationNo,
      "RegistartionExpiry": this.companyForm.value.RegistrationExpiry,
      "VATCode": this.companyForm.value.VATCode,
      "VATRegistartionNo": this.companyForm.value.VATRegistrationNo,
      "EngEmail": this.companyForm.value.EngEmail,
      "PhoneNumber": this.companyForm.value.PhoneNumber,
      "MobileNumber": this.companyForm.value.MobileNumber,
      "Fax": this.companyForm.value.Fax,
      "EngAddress1": this.companyForm.value.EngAddress1,
      "EngAddress2": this.companyForm.value.EngAddress2,
      "ArabicAddress1": this.companyForm.value.ArabicAddress1,
      "ArabicAddress2": this.companyForm.value.ArabicAddress2,
      "EngZIP": this.companyForm.value.EngZIP,
      "Incorporated": this.companyForm.value.Incorporated,
      "Category": this.companyForm.value.Category,
      "FacAlert": this.companyForm.value.FacAlert,
      "Status": this.companyForm.value.Status,
      "ModifiedByStr": this.companyForm.value.ModifiedByStr,
      "IsValid": this.companyForm.value.IsValid,
      "Branch": this.companyForm.value.Branch,
      "Code": this.companyForm.value.Code,
      "Branches": this.BranchList
    }
    return clonedFormValues;
  }
  submitForm() {

    this.errorType = this.compType.invalid;
    this.errorName = this.compName.invalid;
    this.errorShortName = this.compShortName.invalid;
    this.errorRegistrationNo = this.compRegistrationNo.invalid;
    this.errorRegistrationExpiry = this.compRegistrationExpiry.invalid;
    this.errorVATRegistrationNo = this.compVATRegistrationNo.invalid;
    this.errorEmail = this.compEmail.invalid;
    this.errorPhoneNumber = this.compPhoneNumber.invalid;
    this.errorMobileNumber = this.compMobileNumber.invalid;
    this.errorEngAddress1 = this.compEngAddress1.invalid;
    this.errorEngZIP = this.compEngZIP.invalid;
    //console.log(this.companyForm.value);
    if (this.companyForm.invalid) {
      return;
    }
    else {
      if (this.companyForm.value.FacAlert == true) {
        this.companyForm.value.FacAlert = "Y";
      }
  //    console.log(this.companyForm.value, 'this.sdf');
      /* alert('SUCCESS!! :-)\n\n'
         + JSON.stringify(this.companyForm.value))
       */
      let cloneCompanyForm: any = this.setCompanyFormValues();
   //   console.log(JSON.stringify(cloneCompanyForm), 'second form');
      this.companyservice.updateCompany(JSON.stringify(cloneCompanyForm)).subscribe(
        dataReturn => {
          this.returnValue = dataReturn;
          console.log(this.returnValue, 'this.returnValue')
          //success modal     
          if (this.returnValue.IsValid == 0) {
            this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
            this.bsModalRef.content.modelTitle = '';
            this.bsModalRef.content.modelBodyContent = "Company Successfully updated.";
            //this.bsModalRef.content.smallMessage="ID: "+this.returnValue.Code;
            // this.bsModalRef.content.bigMessage = this.returnValue.EngName;
            // this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
            this.bsModalRef.content.actionBtn = "Close";
            this.bsModalRef.content.valueChange.subscribe((data) => {
              console.log(" success datat" + data);
              if (data == 'Close') {
                //    console.log("close btn clicked");
              } else {
                console.log(" else close");
              }
              this.editFormOption = false;
              this.companyForm.disable();
              this.clearerrors();
              // this.clearerrors(); 
              // this.modalService.hide(1);
            });
          } else if (this.returnValue.IsValid == 1) {
            //alert modal
            this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
            this.bsModalRef.content.modelTitle = '';
            this.bsModalRef.content.modelBodyContent = "Alert! Other than VAT Registration Number and Registration Number remaining fields  already exists.";
            this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
            this.bsModalRef.content.actionBtn = "Proceed";
            this.bsModalRef.content.valueChange.subscribe((data) => {
              console.log("datat" + data);
              if (data = 'Proceed') {

                console.log("proceed btn clicked");
                this.companyForm.value.IsValid = 1;
                this.submitForm();
              }
              else if (data = 'PROCEED') {
                console.log("erer");
              }
              else {
                console.log(" else close");
              }
              //this.modalService.hide(1);
            });
            //end for alert modal
          }
          else if (this.returnValue.IsValid == 2) {
            this.errorEmailExists = true;
            this.errorMobilenoExists = true;
            this.errorNameExists = true;
            this.errorPhonenoExists = true;
            this.errorVatRegnoExists = true;
            this.errorRegNoExists = true;
          }
        },
        errorRturn => {
          console.log(errorRturn);
        }
      );
    }
  }
  BranchsubmitForm() {
    this.errorBranchName = this.compBranchName.invalid;
    this.errorBranchShortName = this.compBranchShortName.invalid;
    this.errorBranchEmail = this.compBranchEmail.invalid;
    this.errorBranchPhoneNumber = this.compBranchPhoneNumber.invalid;
    this.errorBranchMobileNumber = this.compBranchMobileNumber.invalid;
    this.errorBranchEngAddress1 = this.compBranchEngAddress1.invalid;
    this.errorBranchEngZIP = this.compBranchEngZIP.invalid;

    console.log(this.branchForm.value);
    if (this.branchForm.valid) {
      //check dupilcate exists or not
      console.log("duplicate or not - " + this.checkDuplicatesInBranchList());
      if (this.checkDuplicatesInBranchList() == true) {
        console.log("gggg");
        this.errorBranchNameExists = true;
        this.errorBranchPhoneExists = true;
        this.errorBranchMobileExists = true;
        this.errorBranchEmailExists = true;
        return;
      }
      let successMsg:any;
      //end for duplicate exists or not
      if (this.branchViewEditMode == false) {
        this.branchCodeValue = this.branchCodeValue + 1;
        this.branchForm.value.BranchCode = this.branchCodeValue;
        this.branchForm.value.IsValue=1;
        this.BranchList.push(this.branchForm.value);
        successMsg="Created.";
      } else {
        console.log("updatee" + JSON.stringify(this.branchForm.value));
        this.updateValuesInBranchList();
        successMsg="Updated.";
      }
      this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
      this.bsModalRef.content.modelTitle = '';
      this.bsModalRef.content.modelBodyContent = "Branch Successfully "+successMsg;
      this.bsModalRef.content.bigMessage = "Name: "+this.branchForm.value.EngName;
      this.bsModalRef.content.actionBtn = "Close";
      this.bsModalRef.content.valueChange.subscribe((data) => {
        if (data = 'Close') {
          this.resetBranchForm();
          this.modalService.hide(1);
          this.companyForm.controls['AddBranch'].setValue("");
          this.branchViewEditMode=false;
        }
      });


    }


    console.log("branchlist" + JSON.stringify(this.BranchList));

  }
  checkDuplicatesInBranchList() {
    let duplicateValueExists: boolean = false;
    console.log("ththth"+this.branchForm.controls['BranchCode'].value+" edit mode "+this.branchViewEditMode);
    this.BranchList.forEach((item) => {
      if (this.branchViewEditMode==true && this.branchForm.controls['BranchCode'].value && item.BranchCode != this.branchForm.controls['BranchCode'].value && item.EngName == this.branchForm.controls['EngName'].value && item.EngEmail == this.branchForm.controls['EngEmail'].value
        && item.PhoneNumber == this.branchForm.controls['PhoneNumber'].value && item.PhoneNumber == this.branchForm.controls['MobileNumber'].value) {
          console.log(" edit item ");
        duplicateValueExists = true;
      }
      if (this.branchViewEditMode==false && item.EngName == this.branchForm.controls['EngName'].value && item.EngEmail == this.branchForm.controls['EngEmail'].value
        && item.PhoneNumber == this.branchForm.controls['PhoneNumber'].value && item.PhoneNumber == this.branchForm.controls['MobileNumber'].value) {
          console.log("add item");
        duplicateValueExists = true;
      }

    });

    return duplicateValueExists;

  }
  updateValuesInBranchList() {
    // let clonedBranchList:any=[];
    for (var i = 0; i < this.BranchList.length; i++) {
  //    console.log("val" + JSON.stringify(this.BranchList[i]) + " branch code" + this.branchForm.value.BranchCode);
      if (Number(this.BranchList[i].BranchCode) === Number(this.branchForm.value.BranchCode)) {
        console.log("matched");
        //setting value
        let arrayFormFields = ['BranchCode', 'EngName', 'ArabicName', 'EnShortName', 'ArShortName', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngZIP', 'ArabicZIP', 'Status'];
        arrayFormFields.forEach((val) => {
          // this.branchForm.controls[val].setValue(item[val]);
          this.BranchList[i][val] = this.branchForm.controls[val].value;
        });
        //end for setting value 
      }
    }


  }

  viewBranch(template: TemplateRef<any>) {
    if (this.branchViewEditMode) {
      this.viewOnlyMode = true;
      this.closeInView= false; 
      this.modalRef = this.modalService.show(template, { class: 'create-modal-dailog' });
      this.branchForm.disable();
      this.clearBranchErrors();
    }

  }
  editBranch(template: TemplateRef<any>) {
    if (this.branchViewEditMode) {
      this.viewOnlyMode = false;
      this.closeInView= true;
      this.branchForm.enable();
      this.modalRef = this.modalService.show(template, { class: 'create-modal-dailog' });
    }
  }
  openModal(template: TemplateRef<any>) {
    this.viewOnlyMode = false;
    this.resetBranchForm();
    this.branchForm.enable();
    this.clearBranchErrors();
    this.closeInView= true; 
    this.modalRef = this.modalService.show(template, { class: 'create-modal-dailog' });
    this.companyForm.controls['AddBranch'].setValue("");
    this.branchViewEditMode = false; 
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
  }
  checkIsformDirty(template: any) {
    if (this.companyForm.dirty || this.companyForm.touched) {
      console.log('cmg here');
      this.modalRef = this.modalService.show(template, { class: 'confirmation-dailog-box modal-md' });
      this.modalRef.content.modelTitle = '';
      this.modalRef.content.modelBodyContent = RSAMSGConstants.DIRTYFLAGMSGRECIPT;
      this.modalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
      this.modalRef.content.actionBtn = RSAMSGConstants.BTNPROCEED;
      this.modalRef.content.valueChange.subscribe((data) => {
        if (data = 'Proceed') {
          this.modalService.hide(1);
        }
        this.modalService.hide(1);
      });
    } else {
      //this.modalService.hide();
    }
  }

  getCompanyType() {
    this.companyservice.getCompanyType().subscribe(
      dataReturn => {
        //console.log("data1" + JSON.stringify(dataReturn));
        this.companyTypeList = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getVatCode() {
    this.companyservice.getVatCode().subscribe(
      dataReturn => {
        //  console.log("data1" + JSON.stringify(dataReturn));
        this.VATCodeList = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getCategory() {
    this.companyservice.getCategory().subscribe(
      dataReturn => {
        // console.log("data1" + JSON.stringify(dataReturn));
        this.CategoryList = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getStatus() {

    this.companyservice.getStatus().subscribe(
      dataReturn => {
        // console.log("data1" + JSON.stringify(dataReturn));
        this.StatusList = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getBranchStatus() {
    this.companyservice.getBranchStatus().subscribe(
      dataReturn => {
        //  console.log("data1" + JSON.stringify(dataReturn));
        this.BranchStatusList = dataReturn;
      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  getCompanyDetails() {
    const param = 'Code=' + this.entityCode;
    this.companyservice.getCompanyDetails(param).subscribe(
      dataReturn => {
        console.log("Company data" + JSON.stringify(dataReturn));
        let arrayFormFields = ['Type', 'EngName', 'ArabicName', 'EnShortName', 'ArShortName',
          'VATCode', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'EngAddress1', 'EngAddress2', 'ArabicAddress1',
          'ArabicAddress2', 'EngZIP', 'Incorporated', 'Category', 'FacAlert', 'Status', 'ModifiedByStr', 'IsValid', 'Branch', 'Code'];
        arrayFormFields.forEach((val) => {
          if (dataReturn[val] != null && dataReturn[val] != undefined) {
            this.companyForm.controls[val].setValue(dataReturn[val]);
          }
        });

        this.companyForm.controls['RegistrationNo'].setValue(dataReturn['RegistartionNo']);
        this.companyForm.controls['RegistrationExpiry'].setValue(dataReturn["RegistartionExpiry"]);
        this.companyForm.controls['VATRegistrationNo'].setValue(dataReturn['VATRegistartionNo']);
        this.BranchList = dataReturn['Branches'];

      },
      errorRturn => {
        console.log(errorRturn);
      }
    );
  }
  companyEdit() {
    this.editFormOption = true;
    this.companyForm.enable();
  }
  resetBranchForm() {
    let arrayFormFields = ['EngName', 'ArabicName', 'EnShortName', 'ArShortName', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngZIP', 'ArabicZIP', 'Status'];
    arrayFormFields.forEach((val) => {
      if (this.branchForm.controls[val] != null && this.branchForm.controls[val] != undefined) {
        this.branchForm.controls[val].reset();
      }
    });
    this.clearBranchErrors();
  }
  onBranchSelect(branchCode: number) {
    console.log("if" + branchCode);
    if(branchCode) {
      console.log("if second" + branchCode);
      this.branchViewEditMode = true;

      this.BranchList.forEach((item) => {
        console.log("val" + JSON.stringify(item) + " branch code" + branchCode);
        if (Number(item.BranchCode) === Number(branchCode)) {
          console.log("matched");
          //setting value
          let arrayFormFields = ['BranchCode','EngName', 'ArabicName', 'EnShortName', 'ArShortName', 'EngEmail', 'PhoneNumber', 'MobileNumber', 'Fax', 'EngAddress1', 'ArabicAddress1', 'EngAddress2', 'ArabicAddress2', 'EngZIP', 'ArabicZIP', 'Status'];
          arrayFormFields.forEach((val) => {
            if (item[val] != null && item[val] != undefined) {
              this.branchForm.controls[val].setValue(item[val]);
            }
          });
          
          //end for setting value 
        }
      });

    } else {
      this.branchViewEditMode = false;
    }
  }


}
