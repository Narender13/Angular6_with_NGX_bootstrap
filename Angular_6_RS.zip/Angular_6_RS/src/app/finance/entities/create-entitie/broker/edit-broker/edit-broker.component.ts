import { Component, OnInit, Input, ViewChild, ElementRef} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../../shared/animation/slidein';
import { BrokerService } from '../service/broker.service';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { SuccessDialogComponent } from 'src/app/shared/custom-success-model/custom-success-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'rsa-edit-broker',
  templateUrl: './edit-broker.component.html',
  styleUrls: ['./edit-broker.component.scss'],
  animations: [slideInOut]
})
export class EditBrokerComponent implements OnInit {

    brokerForm: FormGroup;
    isArabicField = false;
    Address1 = false;
    Address2 = false;
    Address3 = false;
    submitted = false;
    errorname: boolean;
    errorlicensenumber: boolean;
    errorVATRegNo: boolean;
    erroremail: boolean;
    errorTelephone: boolean;
    errorMobileNo: boolean;
    erroraddress: boolean;
    errorpostalcode: boolean;
    errorBranch: boolean;
    errorNationality: boolean;
    errorOverallCreditAmt: boolean;
    errorLicenceExpiryDate: boolean;
    erroremailExists: boolean;
    errorMobileNoExists: boolean;
    errornameExists: boolean;
    errorTelephoneExists: boolean;
    errorVATRegNoExists: boolean;
    errorELicenceNoExists: boolean;
    bankNamesList: any[];
    branchList: any[];
    vatcodeList: any[];
    nationalityList: any[];
    vatregcountryList: any[];
    corrbanknameList: any[];
    categoryList: any[];
    statusList: any[];
    acexecList: any[];
    returnValue: any;
    isOman: any;
    today = new Date();
    @Input() entityCode: number;
   @Input() entityType: number;
    editFormOption: boolean;
    overCreditReadonly: boolean;
    selectedTypeVal: any;
    errorCategoryExists: boolean;
    @ViewChild('newCategoryname') private newCategoryname: ElementRef;
    isCategoryAdded: boolean;

    constructor(private fb: FormBuilder, protected brokerService: BrokerService,
        public bsModalRef: BsModalRef, private modalService: BsModalService) {

    }
    ngOnInit() {
      this.createEntityForm();
        this.getBrokerDetails();
        this.fieldStatusChanges();
        this.getPayeeBankNames();
        this.getBranchNames();
        this.getvatcode();
        this.getnationality();
        this.getvatregcountry();
        this.getcorrbankname();
        this.getcategory();
        this.getstatus();
        this.getacexecutive();
        this.brokerForm.disable();
        this.isOman = localStorage.getItem('defaultcity') == 'NLGIC' ? true : false;
    }
    get namedesc() {
        return this.brokerForm.get('EngName');
    };
    get licensenumberdesc() {
        return this.brokerForm.get('ELicenceNo');
    }
    get VATRegNodesc() {
        return this.brokerForm.get('VATRegNo');
    }
    get emaildesc() {
        return this.brokerForm.get('EEmail');
    }
    get Telephonedesc() {
        return this.brokerForm.get('Telephone');
    }
    get MobileNodesc() {
        return this.brokerForm.get('MobileNo');
    }
    get addressdesc() {
        return this.brokerForm.get('EAddress1');
    }
    get postalcodedesc() {
        return this.brokerForm.get('EPostalCode');
    }
    get Branchdesc() {
        return this.brokerForm.get('Branch');
    }
    get Nationalitydesc() {
        return this.brokerForm.get('Nationality');
    }
    get OverallCreditAmtdesc() {
        return this.brokerForm.get('OverallCreditAmt');
    }
    get LicenceExpiryDatedesc() {
        return this.brokerForm.get('LicenceExpiryDate');
    }
    changelicenseexpiryDate() {
        if (this.brokerForm.controls['LicenceExpiryDate'].value) {
            const LicenceExpiryDate = new Date(this.brokerForm.controls['LicenceExpiryDate'].value);
            this.brokerForm.controls['LicenceExpiryDate'].setValue(new DatePipe('en-US').transform(LicenceExpiryDate, 'dd/MM/yyyy'));
        }
    }
    ChangeappDate() {
        if (this.brokerForm.controls['AppDate'].value) {
            const AppDate = new Date(this.brokerForm.controls['AppDate'].value);
            this.brokerForm.controls['AppDate'].setValue(new DatePipe('en-US').transform(AppDate, 'dd/MM/yyyy'));
        }
    }
    fieldStatusChanges() {
        this.clearerrors();
        this.namedesc.statusChanges.subscribe(
            status => {
                this.errorname = (status == 'INVALID');
            }
        );
        this.licensenumberdesc.statusChanges.subscribe(
            status => {
                this.errorlicensenumber = (status == 'INVALID');
            }
        );
        this.VATRegNodesc.statusChanges.subscribe(
            status => {
                this.errorVATRegNo = (status == 'INVALID');
            }
        );
        this.emaildesc.statusChanges.subscribe(
            status => {
                this.erroremail = (status == 'INVALID');
            }
        );
        this.Telephonedesc.statusChanges.subscribe(
            status => {
                this.errorTelephone = (status == 'INVALID');
            }
        );
        this.MobileNodesc.statusChanges.subscribe(
            status => {
                this.errorMobileNo = (status == 'INVALID');
            }
        );
        this.addressdesc.statusChanges.subscribe(
            status => {
                this.erroraddress = (status == 'INVALID');
               
            }
        );
        this.postalcodedesc.statusChanges.subscribe(
            status => {
                this.errorpostalcode = (status == 'INVALID');
            }
        );
        this.Branchdesc.statusChanges.subscribe(
            status => {
                this.errorBranch = (status == 'INVALID');
            }
        );
        this.Nationalitydesc.statusChanges.subscribe(
            status => {
                this.errorNationality = (status == 'INVALID');
            }
        );
        this.OverallCreditAmtdesc.statusChanges.subscribe(
            status => {
                this.errorOverallCreditAmt = (status == 'INVALID');
            }
        );
        this.LicenceExpiryDatedesc.statusChanges.subscribe(
            status => {
                this.errorLicenceExpiryDate = (status == 'INVALID');
            }
        );
    }
    clearerrors() {
        this.errorname = false;
        this.errorlicensenumber = false;
        this.errorVATRegNo = false;
        this.erroremail = false;
        this.errorTelephone = false;
        this.errorMobileNo = false;
        this.errorBranch = false;
        this.erroraddress = false;
        this.errorpostalcode = false;
        this.errorNationality = false;
        this.errorOverallCreditAmt = false;
        this.errorLicenceExpiryDate = false;
        this.erroremailExists = false;
        this.errorMobileNoExists = false;
        this.errornameExists = false;
        this.errorTelephoneExists = false;
        this.errorVATRegNoExists = false;
        this.errorELicenceNoExists = false;

    };
    createEntityForm(): void {
        this.brokerForm = this.fb.group({
            Code: [this.entityCode],
            EngName: ['', Validators.required],
            ArabName: [''],
            ELicenceNo: ['', Validators.required],
            LicenceExpiryDate: ['', Validators.required],
            VATCode: [''],
            VATRegNo: ['', Validators.required],
            EEmail: ['', [Validators.required, Validators.email]],
            Telephone: ['', Validators.required],
            MobileNo: ['', Validators.required],
            FAXNo: [''],
            Branch: [localStorage.getItem('locationcode'), Validators.required],
            VATRate: [''],
            VATRegCountry: [''],
            EAddress1: ['', Validators.required],
            AAddress1: [''],
            EAddress2: [''],
            AAddress2: [''],
            EAddress3: [''],
            AAddress3: [''],
            EPostalCode: ['', Validators.required],
            Nationality: ['', Validators.required],
            BenfBank: [''],
            BenfAccNo: [''],
            IBANNo: [''],
            BenfBankAdd: [''],
            BenfSwiftCode: [''],
            BenfSortCode: [''],
            CorrBank: [''],
            CorrAccNo: [''],
            CorrBankSwiftCode: [''],
            CorrBankAddr: [''],
            CorrSortCode: [''],
            PLCreditAmount: [''],
            PLCreditDays: [''],
            CLCreditAmt: [''],
            CLCreditDays: [''],
            SME_SPLCreditAmount: [''],
            SME_SPL_CreditDays: [''],
            OverallCreditAmt: ['', Validators.required],
            OverallCreditDays: [''],
            AddlCreditAmt1: [''],
            AddlCrediDays1: [''],
            AddlCreditAmt2: [''],
            AddlCreditDays2: [''],
            BrokerGrp: [''],
            Remarks: [''],
            Qualification: [''],
            AddInfoCategory: [''],
            AppDate: [''],
            Area: [''],
            FACInd: [''],
            IntimationAlerts: [''],
            Status: [''],
            AccExec: [''],
            ModifiedByStr: [localStorage.getItem('userId')],
            IsValid: [0]
        })
    }
    setVatRate(vatvalue: number) {
        this.vatcodeList.forEach(element => {
            if (element.Code == vatvalue) {
                this.brokerForm.controls['VATRate'].setValue(element.VATRate);
               
            }
        });
    }
    get f() { return this.brokerForm.controls; }
    setErrorInvalid() {
        this.errorname = this.namedesc.invalid;
        this.errorlicensenumber = this.licensenumberdesc.invalid;
        this.errorVATRegNo = this.VATRegNodesc.invalid;
        this.erroremail = this.emaildesc.invalid;
        this.errorTelephone = this.Telephonedesc.invalid;
        this.errorMobileNo = this.MobileNodesc.invalid;
        this.errorBranch = this.Branchdesc.invalid;
        this.erroraddress = this.addressdesc.invalid;
        this.errorpostalcode = this.postalcodedesc.invalid;
        this.errorNationality = this.Nationalitydesc.invalid;
        this.errorOverallCreditAmt = this.OverallCreditAmtdesc.invalid;
        this.errorLicenceExpiryDate = this.LicenceExpiryDatedesc.invalid;
    }
    submitForm() {
        this.setErrorInvalid();
        if (this.brokerForm.invalid) {
            return;
        } else {
            if (this.brokerForm.value.FACInd == true) {
                this.brokerForm.value.FACInd = "Y";
            }
            if (this.brokerForm.value.IntimationAlerts == true) {
                this.brokerForm.value.IntimationAlerts = "Y";
            }

            console.log("\n second form values" + JSON.stringify(this.brokerForm.value) + "\n");
            let clonedBrokerForm: any = this.brokerForm.value;
            clonedBrokerForm.BrkCategory = { "EDesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "ADesc": this.isCategoryAdded ? this.categoryList[this.categoryList.length - 1].E_desc : "", "IsNew": this.brokerForm.controls['AddInfoCategory'].value === '0' ? true : false };
            console.log("cloned values\n" + JSON.stringify(clonedBrokerForm));
            this.brokerService.createBroker(JSON.stringify(clonedBrokerForm)).subscribe(
                dataReturn => {
                    this.returnValue = dataReturn;

                    console.log(this.returnValue, 'this.returnValue');

                    //success modal
                    if (this.returnValue.IsValid == 0) {
                        this.bsModalRef = this.modalService.show(SuccessDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Broker successfully updated.";
                        this.bsModalRef.content.actionBtn = "Close";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log(" success datat" + data);
                            if (data == 'Close') {
                                console.log("close btn clicked");
                            } else {
                                console.log(" else close");
                            }
                            this.brokerForm.disable();
                            this.editFormOption = false;
                            this.clearerrors();
                        });
                    }
                    else if (this.returnValue.IsValid == 1) {
                        //alert modal
                        this.bsModalRef = this.modalService.show(ConfirmationDialogComponent, { class: 'confirmation-dailog-box modal-md', ignoreBackdropClick: true });
                        this.bsModalRef.content.modelTitle = '';
                        this.bsModalRef.content.modelBodyContent = "Alert! Other than VAT Registration Number and Registration Number remaining fields  already exists.";
                        this.bsModalRef.content.cancelBtn = RSAMSGConstants.BTNCANCEL;
                        this.bsModalRef.content.actionBtn = "Proceed";
                        this.bsModalRef.content.valueChange.subscribe((data) => {
                            console.log("datat" + data);

                            if (data = 'Proceed') {
                                console.log("proceed btn clicked");
                                this.brokerForm.value.IsValid = 1;
                                this.submitForm();
                            }
                            else if (data = 'PROCEED') {
                                console.log("erer");
                            }
                            else {
                                console.log(" else close");
                            }
                        });
                        //end for alert modal
                    }
                    else if (this.returnValue.IsValid == 2) {
                        this.erroremailExists = true;
                        this.errorMobileNoExists = true;
                        this.errornameExists = true;
                        this.errorTelephoneExists = true;
                        this.errorVATRegNoExists = true;
                        this.errorELicenceNoExists = true;
                    }
                },
                errorRturn => {
                    console.log(errorRturn);
                }
            );
        }
    }
    getPayeeBankNames() {
        this.brokerService.getPayeeBankNames().subscribe(
            dataReturn => {
                this.bankNamesList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getBranchNames() {
        const param = 'ctyCode=' + localStorage.getItem('countrycode') +
            '&regCode=' + localStorage.getItem('regioncode');
        this.brokerService.getBranchNames(param).subscribe(
            dataReturn => {
                this.branchList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }

    getvatcode() {
        this.brokerService.getvatcode().subscribe(
            dataReturn => {
                this.vatcodeList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getnationality() {
        this.brokerService.getnationality().subscribe(
            dataReturn => {
                this.nationalityList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getvatregcountry() {
        this.brokerService.getvatregcountry().subscribe(
            dataReturn => {
                this.vatregcountryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getcorrbankname() {
        this.brokerService.getcorrbankname().subscribe(
            dataReturn => {
                this.corrbanknameList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getcategory() {
        const param = 'entityType=' + this.entityType;

        this.brokerService.getcategory(param).subscribe(
            dataReturn => {
                this.categoryList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getstatus() {
        this.brokerService.getstatus().subscribe(
            dataReturn => {
                this.statusList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getacexecutive() {
        this.brokerService.getacexecutive().subscribe(
            dataReturn => {
                this.acexecList = dataReturn;
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    getBrokerDetails() {
        const param = 'Code=' + this.entityCode;
            
        this.brokerService.getBrokerDetails(param).subscribe(
            dataReturn => {
                let arrayFormFields = ['EngName', 'ArabName', 'ELicenceNo', 'LicenceExpiryDate', 'VATCode', 'VATRegNo',
                    'EEmail', 'Telephone', 'MobileNo', 'FAXNo', 'Branch', 'VATRate', 'VATRegCountry',
                    'EAddress1', 'AAddress1', 'EAddress2', 'AAddress2', 'EAddress3', 'AAddress3', 'EPostalCode', 'Nationality',
                    'BenfBank', 'BenfAccNo', 'IBANNo', 'BenfBankAdd', 'BenfSwiftCode', 'BenfSortCode', 'CorrBank', 'CorrAccNo', 'CorrBankSwiftCode', 'CorrSortCode',
                    'CorrBankAddr', 'PLCreditAmount', 'PLCreditDays', 'CLCreditAmt', 'CLCreditDays', 'SME_SPLCreditAmount', 'SME_SPL_CreditDays',
                    'OverallCreditAmt', 'OverallCreditDays', 'AddlCreditAmt1', 'AddlCrediDays1', 'AddlCreditAmt2', 'AddlCreditDays2', 'BrokerGrp', 'Remarks',
                    'Qualification', 'AddInfoCategory', 'AppDate', 'Area', 'FACInd', 'IntimationAlerts', 'Status', 'AccExec'];

                arrayFormFields.forEach((val) => {
                    if (dataReturn[val] != null && dataReturn[val] != undefined) {
                        this.brokerForm.controls[val].setValue(dataReturn[val]);
                    }
                });
            },
            errorRturn => {
                console.log(errorRturn);
            }
        );
    }
    resetForm() {
        let arrayFormFields = ['EngName', 'ArabName', 'ELicenceNo', 'LicenceExpiryDate', 'VATCode', 'VATRegNo',
            'EEmail', 'Telephone', 'MobileNo', 'FAXNo', 'VATRate', 'VATRegCountry',
            'EAddress1', 'AAddress1', 'EAddress2', 'AAddress2', 'EAddress3', 'AAddress3', 'EPostalCode', 'Nationality',
            'BenfBank', 'BenfAccNo', 'IBANNo', 'BenfBankAdd', 'BenfSwiftCode', 'BenfSortCode', 'CorrBank', 'CorrAccNo', 'CorrBankSwiftCode', 'CorrSortCode',
            'CorrBankAddr', 'PLCreditAmount', 'PLCreditDays', 'CLCreditAmt', 'CLCreditDays', 'SME_SPLCreditAmount', 'SME_SPL_CreditDays',
            'OverallCreditAmt', 'OverallCreditDays', 'AddlCreditAmt1', 'AddlCrediDays1', 'AddlCreditAmt2', 'AddlCreditDays2', 'BrokerGrp', 'Remarks',
            'Qualification', 'AddInfoCategory', 'AppDate', 'Area', 'FACInd', 'IntimationAlerts', 'Status', 'AccExec'];
        this.brokerForm.controls['IsValid'].reset(0);
        arrayFormFields.forEach((val) => {
            if (this.brokerForm.controls[val] != null && this.brokerForm.controls[val] != undefined) {
                this.brokerForm.controls[val].reset();
            }
        });
        this.clearerrors();
    }
    brokerEdit() {
        this.editFormOption = true;
        this.brokerForm.enable();
    }
    addNewCategory(catValue: any) {
        if (catValue === 'newCategoryType') {
            console.log(catValue + " new category " + this.brokerForm.controls['AddInfoCategory'].value);
            this.selectedTypeVal = catValue;
            this.brokerForm.controls['AddInfoCategory'].setValue("");
        }

    }
    addToCateroryList() {
        if (this.newCategoryname.nativeElement.value) {
            if (this.checkDuplicatesInCategoryList() == true) {
                console.log("gggg");
                this.errorCategoryExists = true;
            } else {
                let newCategory: any = { "Code": 0, "E_desc": this.newCategoryname.nativeElement.value };
                this.isCategoryAdded = true;
                this.categoryList.push(newCategory);
                // this.agentForm.controls['Category'].setValue("");
                this.selectedTypeVal = "";
                this.errorCategoryExists = false;
            }

        }
    }
    hideAddCategory() {
        this.brokerForm.controls['AddInfoCategory'].setValue("");
        this.selectedTypeVal = "";
        this.errorCategoryExists = false;
    }
    checkDuplicatesInCategoryList() {
        let duplicateValueExists: boolean = false;
        this.categoryList.forEach((item) => {
            if (this.newCategoryname.nativeElement.value.toLowerCase().toString() === item.E_desc.toLowerCase().toString()) {
                duplicateValueExists = true;
            }
        });
        return duplicateValueExists;
    }
    setCreditValues(event: any) {
        if (this.brokerForm.controls['PLCreditAmount'].value && this.brokerForm.controls['CLCreditAmt'].value && this.brokerForm.controls['SME_SPLCreditAmount'].value) {
            let sum: any = Number(this.brokerForm.controls['PLCreditAmount'].value) + Number(this.brokerForm.controls['CLCreditAmt'].value) + Number(this.brokerForm.controls['SME_SPLCreditAmount'].value);
            this.brokerForm.controls['OverallCreditAmt'].setValue(parseFloat(sum));
            this.overCreditReadonly = true;
        } else {
            this.overCreditReadonly = false;
        }
    }

}
