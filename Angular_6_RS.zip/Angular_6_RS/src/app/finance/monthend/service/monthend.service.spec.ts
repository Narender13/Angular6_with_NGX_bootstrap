import { TestBed, inject } from '@angular/core/testing';

import { MonthendService } from './monthend.service';

describe('MonthendService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MonthendService]
    });
  });

  it('should be created', inject([MonthendService], (service: MonthendService) => {
    expect(service).toBeTruthy();
  }));
});
