export class MonthendSetting {
    StartDate: Date;
    EndDate:Date;
    EarlyAlert: number;
    EmailIds: string;
    DetailTranCode:number;
    Module:string;
    success: boolean;
    message: string;
}
