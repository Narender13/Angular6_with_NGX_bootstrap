import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { validateEmail, multipleEmailValidation, DownloadFile } from 'src/app/shared/utilites/helper';
import { MonthendService } from '../service/monthend.service';
@Component({
    selector: 'rsa-confirm-set-date',
    templateUrl: './confirm-set-date.component.html',
    styleUrls: ['./confirm-set-date.component.scss']
})
export class ConfirmSetDateComponent implements OnInit {
    emailform: FormGroup;
    modalRef: BsModalRef;
    invalidEmailAddress = true;
    checkcorrectEmail = true;
    constructor(private fb: FormBuilder, private modalService: BsModalService,
        public bsModalRef: BsModalRef, private alertService: AlertService,
        private monthendService: MonthendService) { }

    ngOnInit() {
        this.emailform = this.fb.group({
            emailFormat: [],
            email: [null, Validators.required]
        });
    }

    close() {
        this.bsModalRef.hide();
    }

    sendEmail() {
        console.log(this.emailform.value);
        const emailAddress = this.emailform.controls['email'].value;
        const emailFormat = +(this.emailform.controls['emailFormat'].value);
        console.log(emailAddress, emailFormat);
        this.checkcorrectEmail = multipleEmailValidation(emailAddress);
        if (this.checkcorrectEmail) {
            //console.log(param, 'param');
            this.monthendService.sendMonthEndMail({ emailIds: emailAddress }).subscribe((dataReturn) => {
                console.log(dataReturn);
                this.bsModalRef.hide();
                if (!dataReturn.success) {
                    this.alertService.error('something wrong in downloading expense analysis')
                }
                this.alertService.success('mail sent');
            },
                errorRturn => {
                    console.log(errorRturn);
                });
        }
    }

}
