import { Component, OnInit, ViewChild, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { TypeaheadMatch } from 'ngx-bootstrap';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { formatDate, DatePipe } from '@angular/common';
import { AgGridNg2 } from 'ag-grid-angular';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { Entitie } from 'src/app/shared/datatable/model/entitie';
import { AgGridEditViewButtonComponent } from '../reports/report-account/report-account-results/ag-grid-edit-view-button/ag-grid-edit-view-button.component';
import { MonthendSetting } from './model/monthend-setting'
import { MonthendService } from './service/monthend.service'
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { ConfirmSetDateComponent } from './confirm-set-date/confirm-set-date.component'


@Component({
    selector: 'rsa-monthend',
    templateUrl: './monthend.component.html',
    styleUrls: ['./monthend.component.scss']
})
export class MonthendComponent implements OnInit {

    @ViewChild('agGrid') agGrid: AgGridNg2;
    gridApi;
    gridColumnApi;
    paginationOptions: TextValuePair[] = [];
    selectedData;
    monthEndSettingForm: FormGroup;
    monthEndSetting: MonthendSetting;
    underWritingData: any[] = [];
    monthEndData: any[] = [];
    rowData: any[] = [];
    columnDefs: Array<object> = [];
    domLayout;
    detailRowHeight;
    detailCellRendererParams;
    gridConfiguration: GridOptions = {};
    components;
    viewMonthEndSetting: boolean = true;
    updateMonthEndSetting: boolean = true;
    earlyAlertData = [];
    currentModuleName: string;
    isNewRecord: boolean;
    currentEditRow: any;
    suppressClickEdit;
    @Output() selectedRowDetails = new EventEmitter();
    @Output() deSelectCheckbox = new EventEmitter();
    editingRowIndex: number;
    constructor(private monthendService: MonthendService, private fb: FormBuilder,
        private modalService: BsModalService, public bsModalRef: BsModalRef, public datepipe: DatePipe,
        private alertService: AlertService) {
        this.domLayout = 'autoHeight';
    }

    ngOnInit() {
        this.earlyAlertData = [{ value: '24', text: '24 Hours' }, { value: '48', text: '48 Hours' }, { value: '96', text: '96 Hours' }];
        this.createMonthEndSettingForm();
        this.defineColumnDefs();
        this.GetGridOptions();
        this.suppressClickEdit = true;
        this.getAsyncAllMonthEndSetting('Underwriting');
        this.components = { datePicker: getDatePicker(), selectPicker: getSelectPicker() };

    }
    defineColumnDefs() {
        this.columnDefs = [
            {
                headerName: 'Month', field: 'StartDate', sortable: true, filter: 'agSetColumnFilter', editable: false,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'MMMM yyyy');
                }
            },
            {
                headerName: 'Closing Date', field: 'EndDate', sortable: true, filter: 'agSetColumnFilter', editable: true, suppressNavigable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "datePicker"
            },
            {
                headerName: 'Opening Date', field: 'StartDate', sortable: true, filter: 'agSetColumnFilter', editable: true,
                valueFormatter: (data) => {
                    return this.datepipe.transform(data.value, 'dd/MM/yyyy');
                }, cellEditor: "datePicker"
            },
            {
                headerName: "Early Alert",
                field: "EarlyAlert",
                width: 100,
                cellEditor: 'selectPicker',
                editable: true
            },
            {
                headerName: 'Action',
                field: 'value',
                cellRendererFramework: AgGridEditViewButtonComponent,
                cellRendererParams: {
                    inActoionLink: 'monthEndSetting'
                },
                colId: 'editSaveBtn',
                filter: 'none',
                headerClass: 'hidefilter'
            }
        ];
    }
    createMonthEndSettingForm(): void {
        this.monthEndSettingForm = this.fb.group({
            StartDate: [null, Validators.required],
            EndDate: [null, Validators.required],
            FrmEarlyAlert: [null, Validators.required],
            EmailIds: [null]
        });
    }

    getAsyncAllMonthEndSetting(moduleName): any {
        this.monthendService.getAllMonthEndSetting().subscribe((data) => {
            this.monthEndData = data;
            this.getModuleData(moduleName);
        });
        //this.getDummyValues();

    }

    addNewRow(): any {
        //let dtlTranCode =  this.rowData.length + 1;
        this.rowData.push({ DetailTranCode: 0, Module: this.currentModuleName, EarlyAlert: '', StartDate: '', EndDate: '', isNewRow: true });
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.onParentEditClicked(this.rowData.length - 1);
    }

    updateAsyncMonthEndSetting(): any {

    }
    setAutoHeight() {
        setTimeout(() => {
            this.gridApi.setDomLayout('autoHeight');
        }, 200);
    }

    ngAfterViewInit() {
        this.fitToCoulmn();
        this.setAutoHeight();
    }

    fitToCoulmn() {
        setTimeout(() => {
            this.gridApi.sizeColumnsToFit();
        }, 200);
    }

    getDummyValues(): any {
        this.monthEndData.push({ DetailTranCode: 1, Module: 'Accounts', EarlyAlert: '24', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 2, Module: 'Accounts', EarlyAlert: '48', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 3, Module: 'Claims', EarlyAlert: '96', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 4, Module: 'Claims', EarlyAlert: '48', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 5, Module: 'Underwriting', EarlyAlert: '24', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 6, Module: 'Underwriting', EarlyAlert: '96', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 7, Module: 'Underwriting', EarlyAlert: '48', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 8, Module: 'Accounts', EarlyAlert: '96', StartDate: new Date(), EndDate: new Date() });
        this.monthEndData.push({ DetailTranCode: 9, Module: 'Accounts', EarlyAlert: '24', StartDate: new Date(), EndDate: new Date() });
    }

    onGridReady(params) {
        console.log(params, 'params');
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
        this.gridConfiguration.api.setRowData(this.rowData);
        params.api.paginationGoToPage(0);
        this.fitToCoulmn();
    }

    getModuleData(moduleName) {
        this.currentModuleName = moduleName;
        this.rowData = this.monthEndData.filter(data => data.Module === moduleName);
        if (this.gridConfiguration.api) {
            this.gridConfiguration.api.setRowData(this.rowData); // Refresh grid
            this.gridApi.paginationGoToPage(0);
        }
    }

    GetGridOptions() {
        this.gridConfiguration = <GridOptions>{
            columnDefs: this.columnDefs,
            postProcessPopup: function (params) {
                const ePopup = params.ePopup;
                ePopup.style.top = '14.9838px';
            },
            //rowData: rowData,
            rowHeight: 40,
            headerHeight: 40,
            pagination: true,
            floatingFiltersHeight: 40,
            paginationPageSize: 20,
            enableRangeSelection: true,
            rowSelection: 'single',
            rowMultiSelectWithClick: true,
            animateRows: true,
            enableColResize: true,
            enableFilter: true,
            suppressContextMenu: true,
            enableSorting: true,
            editType: 'cel',
            // masterDetail: true,
            defaultColDef: {
                enableRowGroup: false,
                enableValue: true,
                suppressMovable: true,
                minWidth: 100,
                menuTabs: ['filterMenuTab', '', '']
            },
            context: {
                componentParent: this
            },
        };
    }

    onCellClicked($event) {
        console.log($event);
    }

    onCellFocused($event) {
        console.log($event);
    }
    onCellValueChanged($event) {
        if ($event.column.colId === 'EndDate') {
            console.log(this.rowData[$event.rowIndex].EndDate);
        }
    }

    onParentEditClicked(rowIndex) {
        this.currentEditRow = Object.assign({}, this.rowData[rowIndex]);
        this.gridApi.startEditingCell({
            rowIndex: rowIndex,
            colKey: 'EndDate'
        });
        this.editingRowIndex = rowIndex;
    }

    onParentCancel(rowIndex) {
        this.gridApi.stopEditing();
        let selRowData = this.rowData[rowIndex];
        if (selRowData.isNewRow) {
            this.rowData.splice(rowIndex, 1);
        }
        else {
            this.rowData[rowIndex] = this.currentEditRow;
        }
        this.gridConfiguration.api.setRowData(this.rowData);
        this.gridApi.paginationGoToPage(0);
        this.suppressClickEdit = true;
    }

    validateData(currentData) {
        if (currentData.EndDate === "") {
            this.alertService.error('End date is empty');
            return 'EndDate';
        }
        if (currentData.StartDate === "") {
            this.alertService.error('Start date is empty');
            return 'StartDate';
        }
        if (currentData.EarlyAlert === "") {
            this.alertService.error('EarlyAlert is empty');
            return 'EarlyAlert';
        }
        if (currentData.StartDate > currentData.EndDate) {
            this.alertService.info('End date should  be greater than Start date');
            return false;
        }
        return '';
    }

    setDates() {
        this.monthendService.setMonthEndDates({}).subscribe((dataReturn) => {
            console.log(dataReturn);
            if (!dataReturn.success) {
                console.log('something wrong in saving expense analysis');
            }
            else {
                this.modalService.show(ConfirmSetDateComponent, { class: 'preview-modal-dailog-send-email', backdrop: 'static', keyboard: false });
            }
        },
            errorRturn => {
                console.log(errorRturn);
            });
    }

    onParentSaveClicked(id, rowIndex) {
        console.log(this.rowData);
        this.gridApi.stopEditing();
        let updatedData = this.rowData.filter(data => data.DetailTranCode === id);
        console.log(updatedData);
        if (updatedData.length > 0) {
            let validate = this.validateData(updatedData[0]);
            if (validate === '') {
                if (id === 0) {
                    this.monthendService.addMonthEndSetting(JSON.stringify(updatedData[0])).subscribe(
                        dataReturn => {
                            console.log(dataReturn);
                            if (!dataReturn.success) {
                                this.alertService.error(dataReturn.message);
                            }
                            else {
                                this.alertService.success('Data saved successfully.');
                            }
                            this.getAsyncAllMonthEndSetting(this.currentModuleName);
                        },
                        errorRturn => {
                            this.alertService.error('something went wrong');
                        }
                    );
                }
                else {
                    this.monthendService.updateMonthEndSetting(JSON.stringify(updatedData[0])).subscribe(
                        dataReturn => {
                            //console.log(dataReturn);
                            if (!dataReturn.success) {
                                //console.log('something wrong in saving expense analysis');
                                this.alertService.warn(dataReturn.message);
                            }
                        },
                        errorRturn => {
                            //console.log(errorRturn);
                            this.alertService.error('something went wrong');
                        }
                    );
                }
            }
            else {
                this.rowData[rowIndex] = this.currentEditRow;
                this.gridApi.startEditingCell({
                    rowIndex: rowIndex,
                    colKey: validate
                });
            }
        }
    }
}

interface TextValuePair {
    id: number;
    value: string;
}

function earlyAlertCellRenderer(params) {
    return params.value.code;
}

function earlyAlertCellEditor(params) {
    return params.value.name;
}

function getDatePicker() {
    function Datepicker() { }
    Datepicker.prototype.init = function (params) {
        var dateValue = formatGridDate(params.value);
        this.eInput = document.createElement("input");
        this.eInput.value = dateValue;
        this.eInput.setAttribute("type", "date");
        this.eInput.setAttribute("style", "width:100%");
        this.eInput.setAttribute("click", "callFromCalendar($event)");
    };
    Datepicker.prototype.getGui = function () {
        return this.eInput;
    };
    Datepicker.prototype.afterGuiAttached = function () {
        this.eInput.focus();
        //this.eInput.select();
    };
    Datepicker.prototype.getValue = function () {
        return this.eInput.value;
    };
    Datepicker.prototype.destroy = function () { };
    Datepicker.prototype.isPopup = function () {
        return false;
    };
    return Datepicker;
}

function getSelectPicker() {
    function SelectPicker() { }
    SelectPicker.prototype.init = function (params) {
        this.earlyAlertData = [{ value: '24', text: '24 Hours' }, { value: '48', text: '48 Hours' }, { value: '96', text: '96 Hours' }];
        this.eInput = document.createElement("select");
        this.eInput.setAttribute('style', 'width:100%;padding:0px');
        var eOption = document.createElement("option");
        eOption.text = "Select";
        eOption.value = "";
        this.eInput.appendChild(eOption);
        this.earlyAlertData.forEach(obj => {
            var eOption = document.createElement("option");
            eOption.text = obj.text;
            eOption.value = obj.value;
            this.eInput.appendChild(eOption);
        });
        this.eInput.value = params.value;
    };
    SelectPicker.prototype.getGui = function () {
        return this.eInput;
    };
    SelectPicker.prototype.afterGuiAttached = function () {
        this.eInput.focus();
        //this.eInput.select();
    };
    SelectPicker.prototype.getValue = function () {
        return this.eInput.value;
    };
    SelectPicker.prototype.destroy = function () { };
    SelectPicker.prototype.isPopup = function () {
        return false;
    };
    return SelectPicker;
}

function formatGridDate(date) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;
    return [year, month, day].join('-');
}
