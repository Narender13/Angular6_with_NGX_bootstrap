import { Router, NavigationExtras } from '@angular/router';
import { Component, OnInit, OnDestroy, Input, AfterViewInit, ViewChild } from '@angular/core';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { CreditDebit } from 'src/app/finance/search/model/credit-debit';
import { GridOptions } from 'ag-grid-community/dist/lib/entities/gridOptions';
import { GridApiService } from 'src/app/shared/datatable/services/grid-api-service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { CreateReceiptEntitiComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti/create-receipt-entiti.component';
import { CreateReceiptEntitiRowSelectionComponent } from 'src/app/finance/search/search-results/entity/create-receipt-entiti-row-selection/create-receipt-entiti-row-selection.component';
import { MatchUnMatchService } from 'src/app/finance/search/service/match-unmatch.service';
import { CreatePaymentEntityComponent } from './create-payment-entity/create-payment-entity.component';
import { CreatePaymentNewComponent } from 'src/app/finance/search/search-results/entity/create-payment-new/create-payment-new.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { ActivatedRoute } from '@angular/router';
import { CreatejvComponent } from 'src/app/finance/createjv/createjv.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.scss']
})
export class EntityComponent extends BaseSearchComponent implements OnInit, OnDestroy {
  @Input('resultdata') resultdata: any = [];
  @Input('entityNo') entityNo: any;
  @Input('category') category: any;
  @Input('filtercolumndata') filtercolumndata: any;
  @Input('propertyNames') propertyNames: any;
  @Input('userdata') userdata: any;
  @Input('searchedname') searchedname: string;
  @Input('glnumber') glnumber = [];
  @Input('entityType') entityType: any;
  rowopen = true;
  size = 90;
  innerRadius = 30;
  slices: NgXDonutChartSlice[] | any[];
  creditlimit: number;
  donutdropdata: any;
  idnumber: number;

  name: string;
  creditData: CreditDebit[] = [];
  creditLimitDetails: CreditDebit[] = [];
  selectedValue = 'All';
  debitlimit: number;
  total: number;
  showSnackbar = false;
  totalVoucherAmount: any = 0;
  totalVoucherCount = 0;
  gridOptions: GridOptions;
  isRecepit;
  selectedRowEntitiDataTable;
  newSelectedRowEntitiDataTable;
  bsModalRef: BsModalRef;
  isMatched;
  showCreateReceiptForm;
  entitydata: any;
  gridHasData: boolean;
  isRowPaymentEntity = false;
  unMatchFlag: boolean = true;
  public rowsSelected: string[] = [];
  isClicked: boolean = false;
  canReceipt: boolean;
  details: any;

  constructor(private allowAccess: UserAutherizationService, private sharedService: SharedService, private searchService: SearchService, 
    private router: Router, private gridApiService: GridApiService, private modalService: BsModalService,
    private matchUnMatchService: MatchUnMatchService, private alertService: AlertService, private route: ActivatedRoute, ) {
    super();
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.getCreditData();
      this.canReceipt = this.accessItem(203);
      this.idnumber = 201838683;
      this.name = this.searchedname;
      console.log(this.searchedname, 'name');
      const unique = (value, index, self) => {
        return self.indexOf(value) === index;
      };

      if (Array.isArray(this.resultdata[0]) && this.resultdata[0].length > 0) {
        this.gridHasData = true;
      } else {
        this.gridHasData = false;
      }
      this.donutdropdata = [
        { item: 'All' },
        { item: 'pl' },
        { item: 'cl' },
        { item: 'sme/spl' }
      ];
      if(params.isFromHome=='true'){
        this.clearSnackBar();
      }
      this.sharedService.getMessage().subscribe(val => {
        console.log(val);
        if (val) {
          this.formatedEntityData();
        } else {
        }
        if (val == 'close' || val == true || val == undefined) {
          this.clearSnackBar();
        }
      });
      this.getPreviousRows();
    });
    console.log(this.resultdata, 'this.resultdata[0]');
  }
  ngOnDestroy() {
    this.showSnackbar = false;
  }
  updateSelectedRows() {
    if (this.totalVoucherCount > 0) {
      localStorage.setItem('SnackbarAdded', 'true');
      let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
      localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
    else {
      localStorage.setItem('SnackbarAdded', 'false');
      localStorage.removeItem('VoucherDetail');
      this.selectedRowEntitiDataTable = [];
      this.buttonName = [];
      let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
      localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    }
  }
  getPreviousRows() {
    let SnackbarAdded = localStorage.getItem('SnackbarAdded');
    if (SnackbarAdded == 'true') {
      let voucherDetail = JSON.parse(localStorage.getItem('VoucherDetail'));
      this.buttonName = voucherDetail.ButtonNames;
      this.selectedRowEntitiDataTable = voucherDetail.SelectedRowEntitiDataTable;
      this.selectedRowEntitiDataTable.forEach(row => {
        if(row.SrNO){
          this.rowsSelected.push(row.SrNO);
        }
        else{
          this.rowsSelected.push(row.SerialNumber);
        }
      });
      this.updateVoucherAmount();
    }
  }
  updateVoucherAmount() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    this.showSnackbar = false;
    if (this.selectedRowEntitiDataTable.length > 0) {
      this.selectedRowEntitiDataTable.forEach(row => {
        this.totalVoucherCount++;
        this.totalVoucherAmount += row.Amount;
      });
      this.showSnackbar = true;
    }
  }

  fillSlicerData(debit, total) {
    this.slices = [
      {
        value: debit,
        color: '#00b5d5',
        message: ''
      },
      {
        value: total,
        color: '#ef5ba1',
        message: 'Payment Due(>90 Days)'
      },

    ];
  }


  getCreditData(): void {
    this.searchService.getCreditData().subscribe((data) => {
      this.creditData = data;
      if (this.selectedValue === 'All') {
        this.creditLimitDetails = this.creditData.filter(i => i.name === this.selectedValue);
        console.log(this.creditLimitDetails);
        this.debitlimit = this.creditLimitDetails[0].debitlimit;
        this.total = this.creditLimitDetails[0].total;
        this.fillSlicerData(this.debitlimit, this.total);
      }
    });
  }

  getDountDropdownData(e) {
    console.log(e);
    this.selectedValue = e.item.item;
    this.creditLimitDetails = this.creditData.filter(i => i.name === e.item.item);
    this.debitlimit = this.creditLimitDetails[0].debitlimit;
    this.total = this.creditLimitDetails[0].total;
    this.fillSlicerData(this.debitlimit, this.total);
  }

  createNewRecepit(obj) {
    this.entitydata = obj;
    this.totalVoucherAmount = null;
    this.totalVoucherCount = null;
    this.createButton([
      { id: '1', name: 'receipt', access: this.accessItem(205) },
      { id: '4', name: 'payment', access: this.accessItem(206) },
      { id: '15', name: 'Tax Invoice', access: this.accessItem(209) },
      { id: '16', name: 'Credit note', access: this.accessItem(210) },
    ]);
    this.unSelectCheckbox();
    setTimeout(() => {
      this.showSnackbar = true;
    }, 200);

  }

  buttonHandler(e) {
    let payeeName: String;
    if (this.resultdata !== null && this.resultdata[0].length > 0) {
      payeeName = this.resultdata[0][0].CustomerName;
    }
    else {
      payeeName = this.searchedname;
    }
    const config = {
      backdrop: true,
      ignoreBackdropClick: false,
      class: 'create-modal-dailog'
    };

    if (e == '15') {
      this.showSnackbar = false;
      const initialState = {
        customerName: payeeName,
        ondemandFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
    }

    if (e == '16') {
      this.showSnackbar = false;
      const initialState = {
        customerName: payeeName,
        ondemandFlag: true
      };
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
    }

    if (e == '1') {
      this.showSnackbar = false;

      const initialState = {
        'glnumber': this.glnumber,
        'idnumber': this.idnumber,
        'entitydata': this.entitydata,
        'CustomerName': payeeName
      };
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiComponent, {
        class: 'create-modal-dailog', initialState,
        backdrop: 'static',
        keyboard: false
      });
      this.bsModalRef.content.CustomerName = payeeName;
    }
    if (e == '4') {
      this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, { class: 'create-modal-dailog', ignoreBackdropClick: true, });
      this.bsModalRef.content.CustomerName = payeeName;
      this.bsModalRef.content.entitydata = this.entitydata[0];
      this.bsModalRef.content.isPaymentFromEntity = true;
    }
    if (e == '3' && (this.totalVoucherAmount < 0 || !this.unMatchFlag)) {
      this.formatedEntityData();
      if (this.selectedRowEntitiDataTable.filter(i => i.ClaimID == 0 || i.ClaimID == null).length != this.selectedRowEntitiDataTable.length 
        && (this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0) == this.selectedRowEntitiDataTable.length)) {
        this.alertService.warn(' Do not Select Both Claim and Generic Transactions.Select approriate transactions');
        return false;
      }
      console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTable');
      const IsclaimPayment = this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0).length > 0 ? true : false;
      if (IsclaimPayment) {
        this.setDetails();
      }
      const initialState = {
        selectedRowEntitiDataTable: this.newSelectedRowEntitiDataTable,
        totalAmount: this.totalVoucherAmount,
        ondemandFlag: false,
        customerName: payeeName,
        paymentClaimDetails: this.details,
        isRowPaymentEntity: true,
        title: this.selectedRowEntitiDataTable.filter(i => i.ClaimID > 0).length > 0 ? 'Claim Payment' : 'Payment',
        claimPayment: IsclaimPayment,
      };
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        initialState,
        backdrop: true,
        ignoreBackdropClick: false,
        class: 'create-modal-dailog'
      });
    }
    if (e === '22') {
      //this.showSnackbar = false;
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        totalAmount: this.totalVoucherAmount,
        customerName: payeeName,
        ondemandFlagClaim: false
      };
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
      this.bsModalRef.content.title = 'Credit Note';

    }

    if (e === '99') {
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        totalAmount: this.totalVoucherAmount,
        customerName: this.name,
        ondemandFlagClaim: false,
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
      this.bsModalRef.content.title = 'Tax Invoice';

    }
    if (e === '32') {
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        //totalAmount: this.totalVoucherAmount,
        customerName: this.name,
        ondemandFlagClaim: false,
        isRowPaymentEntity: true
      };
      this.bsModalRef = this.modalService.show(CreatejvComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
      this.bsModalRef.content.title = 'JV';
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }

    if (e === '21') {
      this.showSnackbar = false;
      const initialState = {
        selectedRowItem: this.selectedRowEntitiDataTable,
        totalAmount: this.totalVoucherAmount,
        customerName: payeeName,
        ondemandFlagClaim: false
      };
      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
      this.bsModalRef.content.title = 'Tax Invoice';

    }

    if(this.unMatchFlag){
      if ((e==='3' && this.totalVoucherAmount>0)) {
        this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
      }
    }
   
    if (this.totalVoucherAmount > 0 && e === '2') {
      //this.showSnackbar = false;
      this.bsModalRef = this.modalService.show(CreateReceiptEntitiRowSelectionComponent, config);
      this.bsModalRef.content.totalamount = this.totalVoucherAmount;
      this.bsModalRef.content.totalcount = this.totalVoucherCount;
      this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable;
    }
    if (this.totalVoucherAmount < 0 && e === '2') {
      this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
    }
  }

  formatedEntityData() {
    this.newSelectedRowEntitiDataTable = [];
    const selectedItems = this.selectedRowEntitiDataTable.map(item => Object.assign({}, item));
    for (let i = 0, l = selectedItems.length; i < l; i++) {
      const item = selectedItems[i];
      item.Amount = -(item.Amount);
      item.amt = (item.Amount);
      this.newSelectedRowEntitiDataTable[i] = item;
    }
    console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTablefunct');
  }
  // fixed with above function-defect 5705
  // formatedEntityData() {
  //   this.newSelectedRowEntitiDataTable = [];
  //   for (let i = 0, l = this.selectedRowEntitiDataTable.length; i < l; i++) {
  //     const item = this.selectedRowEntitiDataTable[i];
  //     item.Amount = -(item.Amount);
  //     this.newSelectedRowEntitiDataTable[i] = item;
  //     console.log(this.newSelectedRowEntitiDataTable, 'newSelectedRowEntitiDataTablefunct');
  //   }

  // }
  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  setDetails() {
    if (this.newSelectedRowEntitiDataTable.length > 0) {
      console.log(this.newSelectedRowEntitiDataTable[0] + 'setEntityDetails');
      const topRecord = this.newSelectedRowEntitiDataTable[0];
      // TransactionType: "Expenses"
      const typecode = topRecord.TypeCode;
      let selectedIDs: any;
      if (typecode === 1) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ PolicyNumber }) => PolicyNumber);
        this.details = "POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 2) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ PolicyNumber }) => PolicyNumber);
        this.details = "SAL POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 3) {
        selectedIDs = this.newSelectedRowEntitiDataTable.map(({ ClaimNumber }) => ClaimNumber);
        this.details = "Exp CL No's " + selectedIDs.filter(this.onlyUnique);
      }

    }
  }
  setErorrMsgForTotalAmount() {
    this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
  }
  selectedRowDetails(event) {
    const e = event.vocherEmitedDetails;
    console.log(event, 'e.isMatched');
    const isUnmatched = e.ifUnMatched;
    this.unMatchFlag = isUnmatched;
    if (e.count) {
      if (isUnmatched) {
        this.createButton([
          { id: '2', name: 'receipt', access: this.accessItem(205) },
          { id: '3', name: 'payment', access: this.accessItem(206) },
          { id: '32', name: 'Journal', access: this.accessItem(207) },
        ]);
      }

      if (!isUnmatched) {
        this.createButton([
          { id: '2', name: 'receipt', access: this.accessItem(205) },
          { id: '3', name: 'Claim Payment', access: this.accessItem(206) },
          { id: '32', name: 'Journal', access: this.accessItem(207) },
          { id: '99', name: 'Tax Invoice', access: this.accessItem(209) },
          { id: '22', name: 'credit note', access: this.accessItem(208) }
        ]);
      }
      if (e.transactionType === 'DEBIT') {
        this.createButton([
          { id: '2', name: 'receipt', access: this.accessItem(205) },
          { id: '32', name: 'Journal', access: this.accessItem(207) }
        ]);
      } else if (e.transactionType === 'CREDIT') {
        this.createButton([
          { id: '3', name: 'payment', access: this.accessItem(206) },
          { id: '32', name: 'Journal', access: this.accessItem(207) }
        ]);
      }
    } else {
      // alert('amount should ne gretaherthan zero');
      // this.showSnackbar = false;
    }
    let rowsSelected = e.currentRowData;
    // If already rows selected add row or remove row depending on check box value.
    if (this.selectedRowEntitiDataTable) {
      if (isUnmatched) {
        //If row does not exist means check box is checked then add the row to list.if exists check box is unchecked then remove the row from list.
        if ((this.selectedRowEntitiDataTable.filter(x => x.SrNO == rowsSelected.SrNO).length == 0) && e.isChecked) {
          this.selectedRowEntitiDataTable.push(rowsSelected);
          this.rowsSelected.push(rowsSelected.SrNO);
        }
        else {
          if (!e.isChecked) {
            this.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable.filter(x => x.SrNO != rowsSelected.SrNO);
            this.rowsSelected = this.rowsSelected.filter(x => x != rowsSelected.SrNO);
          }
        }
      }
      //For claims
      else{
        //If row does not exist means check box is checked then add the row to list.if exists check box is unchecked then remove the row from list.
        let rowId=rowsSelected.ClaimID + '-' + rowsSelected.TypeCode +'-'+rowsSelected.SerialNumber;
        if ((this.selectedRowEntitiDataTable.filter(x =>
          (x.ClaimID == rowsSelected.ClaimID &&x.TypeCode == rowsSelected.TypeCode && x.SerialNumber == rowsSelected.SerialNumber)).length == 0) && e.isChecked) {
          this.selectedRowEntitiDataTable.push(rowsSelected);
          this.rowsSelected.push(rowId);
        }
        else {
          if (!e.isChecked) {
            this.selectedRowEntitiDataTable = this.selectedRowEntitiDataTable.filter(x => !(x.ClaimID == rowsSelected.ClaimID && x.TypeCode == rowsSelected.TypeCode && x.SerialNumber == rowsSelected.SerialNumber));
            this.rowsSelected = this.rowsSelected.filter(x => x != rowId);
          }
        }
      }

    }
    else {
      if (e.isChecked) {
        this.selectedRowEntitiDataTable = e.selectedrow;
        if (isUnmatched){
          this.rowsSelected.push(rowsSelected.SrNO);
        }
        else{
          let rowId=rowsSelected.ClaimID + '-' + rowsSelected.TypeCode +'-'+rowsSelected.SerialNumber;
          this.rowsSelected.push(rowId);
        }
      }
    }
    this.updateVoucherAmount();
    this.updateSelectedRows();
  }

  hideSnackBar(e) {
    this.clearSnackBar();
  }
  clearSnackBar() {
    this.totalVoucherCount = 0;
    this.totalVoucherAmount = 0;
    localStorage.setItem('SnackbarAdded', 'false');
    this.selectedRowEntitiDataTable = [];
    this.buttonName = [];
    this.rowsSelected=[];
    let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedRowEntitiDataTable };
    localStorage.setItem('VoucherDetail', JSON.stringify(voucherDetail));
    this.unSelectCheckbox();
    this.showSnackbar = false;
    this.sharedService.sendMessage("ClearState");
    if (localStorage.getItem('ERStateExists') != null) {
      localStorage.setItem('ERStateExists', 'false');
    }
  }
  hideSnackBarDataT(ev) {
    if (ev === 1) {
      console.log(ev);
      this.showSnackbar = false;
    }
  }

  unSelectCheckbox() {
    this.gridApiService.unCheck();
  }
  accessItem(functionid) {
    return this.allowAccess.isAllowed(functionid)
  }
}

