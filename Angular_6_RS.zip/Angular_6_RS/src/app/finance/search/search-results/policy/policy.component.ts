import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit, QueryList } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { NoresultsmsgComponent } from '../noresultsmsg/noresultsmsg.component'
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { CreatePolicyReceiptComponent } from 'src/app/finance/search/search-results/policy/receipt/create-receipt.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { ActivatedRoute } from '@angular/router';
@Component({
    selector: 'rsa-policy',
    templateUrl: './policy.component.html',
    styleUrls: ['./policy.component.scss']
})
export class PolicyComponent extends BaseSearchComponent implements OnInit {
    @Input() category: string;
    @Input('resultdata') resultdata: any = [];
    @Input('policynumber') policynumber: any;
    @Input() lobtitle;


  glnumber: string;
  idnumber: number;
  name: string;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = false;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  selectedReceiptItems = [];
  isPolicy: boolean;
  newSelectedRowPaymentDataTable = [];
  policyDetails: any;
    constructor(private allowAccess: UserAutherizationService,private modalService: BsModalService, private sharedService: SharedService, private alertService: AlertService,private route: ActivatedRoute) { super() }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
        if(params.isFromHome=='true'){
            this.clearSnackBar();
          }
    });
    this.customerName = this.resultdata[0].CustomerName;
    this.isPolicy = this.accessItem(241);
    super.ngOnInit();
    this.createButton([
      { id: '11', name: 'Receipt',access: this.accessItem(242) },
      //{ id: '12', name: 'Tax Invoice No' },
      // { id: '13', name: 'Credit Note' },
      { id: '14', name: 'Payment',access: this.accessItem(243) }
    ]);

        /*Mutiple Policy allocation code*/
        this.resultdata[0].forEach(row => {
            row.isChecked = false;
        });
        this.sharedService.getMessage().subscribe(val => {
            if (val == 'close' || val == true || val == undefined) {
                this.clearSnackBar();
            }
        });
        this.getPreviousItems();
    
  }
  accessItem(functionid){
    return this.allowAccess.isAllowed(functionid)
  }

    getPreviousItems() {
        let SnackbarAdded = localStorage.getItem('SnackbarAddedPlc');
        if (SnackbarAdded == 'true') {
            this.showSnackBar = true;
            let items = JSON.parse(localStorage.getItem('SelectedItems'));
            this.selectedItems = items;
            this.showSnackBar = (this.selectedItems.length > 0) ? true : false;
            this.selectedItems.forEach(item => {
                this.totalCount++;
                this.totalAmount = this.totalAmount + ((item.Amount != null && item.Amount != undefined) ? parseFloat(item.Amount) : 0)
                this.resultdata[0].forEach(row => {
                    if (row.PolicyID == item.PolicyID && row.Endt_ID == item.Endt_ID && row.Amount == item.Amount) {
                        row.isChecked = true;
                    }
                });
            });

        }
        else {
            this.selectedItems = [];
        }
    }
    updateSelectedItems() {
        if (this.selectedItems.length > 0) {
            localStorage.setItem('SnackbarAddedPlc', 'true');
            let items = this.selectedItems;
            localStorage.setItem('SelectedItems', JSON.stringify(items));
            console.log('ItemsSelected' + JSON.stringify(items));
        }
        else {
            this.clearSnackBar();
        }
    }
    selectReceiptData(policyID: string, endtID: string, amount: string, ev) {
        let isChecked = ev.target.checked;
        this.totalAmount = 0;
        this.totalCount = 0;
        this.resultdata[0].forEach(row => {
            if (row.PolicyID == policyID && row.Endt_ID == endtID && row.Amount == amount) {
                row.RefTranTypeName = row.RefTranType;
                row.CostCenter = row.CostCenterName;
                if (isChecked) {
                    this.selectedItems.push(row);
                }
            }
        });
        if (!isChecked) {
            this.selectedItems = this.selectedItems.filter(row => !(row.PolicyID == policyID && row.Endt_ID == endtID && row.Amount == amount));
        }
        this.showSnackBar = (this.selectedItems.length > 0) ? true : false;
        this.updateSelectedItems();
        if (this.selectedItems.length > 0) {
            this.selectedItems.forEach(item => {
                this.totalCount++;
                this.totalAmount = this.totalAmount + ((item.Amount != null && item.Amount != undefined) ? parseFloat(item.Amount) : 0)
            });
        }
        else {
            this.totalCount = 0;
            this.totalAmount = 0;
        }
    }
    /*end*/
    buttonHandler(e) {
        let flagDisplay = false;
        if (this.totalAmount > 0 && e === '14') {
            this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
            return false;
        } else if (this.totalAmount <= 0 && e === '11') {
            this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
            return false;
        }
        if (e === '14') {
            this.formatedPaymentData();
            // added  policyDetails to be set on payment screen-defect 5419
            const initialState = {
                backdrop: true,
                ignoreBackdropClick: true,
                selectedRowEntitiDataTable: this.newSelectedRowPaymentDataTable,
                customerName: this.customerName,
                totalAmount: this.totalAmount,
                ondemandFlag: false,
                paymentDetails: this.policyDetails,
                isPolicyPayment: true
            };
            this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
                class: 'create-modal-dailog',
                initialState
            });
        }
        else if (e === '11' && this.totalAmount > 0) {
            flagDisplay = true;
            this.bsModalRef = this.modalService.show(CreatePolicyReceiptComponent, {
                class: 'create-modal-dailog'
            });
        }
        else if (e === '12') {
            flagDisplay = true;
            this.bsModalRef = this.modalService.show(CreateDebitnotesComponent, {
                class: 'create-modal-dailog', backdrop: true,
                ignoreBackdropClick: false
            });
        }

        else if (e === '13') {
            flagDisplay = true;
            this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, {
                class: 'create-modal-dailog', backdrop: true,
                ignoreBackdropClick: false
            });
        }

        if (e === '12' && e === '13')
            this.bsModalRef.content.ondemandFlag = false;

        if (flagDisplay) {
            this.bsModalRef.content.totalamount = this.totalAmount;
            this.bsModalRef.content.totalcount = this.totalCount;
            this.bsModalRef.content.selectedRowEntitiDataTable = this.selectedItems;
        }


    }
    formatedPaymentData() {
        this.newSelectedRowPaymentDataTable = [];
        const selectedItems = this.selectedItems.map(item => Object.assign({}, item));
        for (let i = 0, l = selectedItems.length; i < l; i++) {
            const item = selectedItems[i];
            item.Amount = -(item.Amount);
            item.amt = (item.Amount);
            item.Description = item.Description;
            this.newSelectedRowPaymentDataTable[i] = item;
        }
        this.setPolcyDetails();
        console.log(this.newSelectedRowPaymentDataTable, 'newSelectedRowPaymentDataTable');
    }

    hideSnackBar(e) {
        this.clearSnackBar();
    }
    clearSnackBar() {
        this.totalCount = 0;
        this.totalAmount = 0;
        localStorage.setItem('SnackbarAddedPlc', 'false');
        this.selectedReceiptItems = [];
        this.selectedItems = [];
        let voucherDetail = { ButtonNames: this.buttonName, SelectedRowEntitiDataTable: this.selectedReceiptItems };
        localStorage.setItem('SelectedItems', JSON.stringify(voucherDetail));
        this.showSnackBar = false;
        this.resultdata[0].forEach(row => {
            row.isChecked = false;
        });
        this.sharedService.sendMessage("ClearState");
    }
    /* policyDetails to be set on payment screen-defect 5419 */
    onlyUnique(value, index, self) {
        return self.indexOf(value) === index;
    }
    setPolcyDetails() {
        if (this.newSelectedRowPaymentDataTable.length > 0) {
            const selectedIDs = this.newSelectedRowPaymentDataTable.map(({ PolicyNumber }) => PolicyNumber);
            this.policyDetails = "POL No's " + selectedIDs.filter(this.onlyUnique);
        }
    }
}
