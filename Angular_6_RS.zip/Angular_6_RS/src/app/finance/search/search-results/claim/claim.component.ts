import { filter, retry } from 'rxjs/operators';
import { Component, OnInit, Input, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { Router } from '@angular/router';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateClaimReceiptComponent } from 'src/app/finance/search/search-results/claim/create-claim-receipt/create-claim-receipt.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { LocaleDataIndex } from '@angular/common/src/i18n/locale_data';
import { CreateCreditnotesComponent } from 'src/app/finance/creditnotes/create-creditnotes/create-creditnotes.component';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { CreateDebitnotesComponent } from 'src/app/finance/debitnotes/create-debitnotes/create-debitnotes.component';
import { SharedService } from 'src/app/finance/services/shared.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { CreatejvComponent } from 'src/app/finance/createjv/createjv.component';

@Component({
  selector: 'rsa-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.scss']
})
export class ClaimComponent extends BaseSearchComponent implements OnInit, AfterViewChecked {
  @Input('resultdata') resultdata: any = [];
  @Input('claimNo') claimNo: any;
  @Input('category') category: any;
  @Input('userdata') userdata: any;
  @Input() lobtitle: any;
  selectedClaimboxLists = [];
  name = ' ';
  idnumber = '201838683';
  showtabledata: number;
  res;
  showSnackBar: boolean;
  totalAmount;
  configdialog: any;
  totalCount;
  bsModalRef: BsModalRef;
  amountCorrForClaimPayment: any = [];
  amountCorrForClaimCN: any = [];
  customerName: string;
  selectedTransactionType: string;
  cliamDetailsData: any = [];
  filterCliamDetailsData: any = [];
  currentTypeCode: any = [];
  seletcedCheckedBox: any = [];
  dnClaims: any = [];
  canGenerateReceipt: boolean = true;
  samePayeeFlag: boolean = false;
  cnClaims: any = [];
  paymentClaims: any = [];
  dirty = false;
  isDirty: boolean;
  headerDescription: string;
  chkboxIndex;
  cnClaimDetails: any;
  isClaim: boolean;
  isSalvage: boolean;
  isExpenses: boolean;
  private ClaimPaymentType: Array<string> = ['EXCESS', 'SALVAGE', 'THIRDPARTYRECOVERY'];
  private ClaimPaymentTypeOthers: Array<string> = ['CLAIM', 'SALVAGE FEE'];
  selectedRowItemWithVATDebit: any = [];
  selectedRowItemWithVATPayment: any = [];
  selectedRowItemWithVATCredit: any = [];

  constructor(private allowAccess: UserAutherizationService, private router: Router, private modalService: BsModalService,
    private sharedService: SharedService,
    private cdRef: ChangeDetectorRef,
    private alertService: AlertService) { super(); }

  ngOnInit() {
    this.reloadPageAfterClose();
    this.customerName = this.resultdata[0].CustomerName;
    console.log(this.resultdata[0], '<<<<<resultdata');
    if (this.resultdata) {
      this.cliamDetailsData = this.resultdata[0].ClaimsDetails;
    }
    this.currentTypeCode[1] = true;
    this.currentTypeCode[2] = true;
    this.currentTypeCode[3] = true;
    this.getMessageForUncheck();
    this.isClaim = this.accessItem(219);
    this.isSalvage = this.accessItem(225);
    this.isExpenses = this.accessItem(231);
  }
  ngAfterViewChecked() {
    if (this.isDirty != this.dirty) { // check if it change, tell CD update view
      this.isDirty = this.dirty;
      this.cdRef.detectChanges();
    }
  }

  /* need this method to get refresh the data after close in preview-Ankappa */
  reloadPageAfterClose() {
    this.sharedService.getMessage().subscribe((data) => {
      if (data == 'close-preview') {
        console.log(data, 'data');
        window.location.reload();
      }
    });
  }
  accessItem(functionid) {
    return this.allowAccess.isAllowed(functionid);
  }
  getMessageForUncheck() {
    this.sharedService.getMessage().subscribe(val => {
      if (val === 'close-cliam' || 'close') {
        this.unCheckAllSelectedCheckbox();
        this.selectedClaimboxLists = [];
        this.selectedRowItemWithVATDebit = [];
        this.dnClaims = [];
        this.cnClaims = [];
        this.paymentClaims = [];
        this.selectedRowItemWithVATCredit = [];
        this.amountCorrForClaimPayment = [];
        this.selectedRowItemWithVATPayment = [];
      }
    });
  }
  updateSelectedList(e, item, index, typecode) {
    console.log('typecode', e);
    const isCheckBoxSelect = e.srcElement.checked;
    item.EntryTypeCode = typecode;
    // this.seletcedCheckedBox.push({ item: item, i: index, eventRef: e.target });

    /*after selecting the checkbox push to some variable and campare  */


    if (isCheckBoxSelect) {
      // this.selectedClaimboxLists.push({ item: item, typecode: typecode });

      this.seletcedCheckedBox.push({ item: item, i: index, eventRef: e.target });
      if (!this.selectedClaimboxLists[typecode]) {
        this.selectedClaimboxLists[typecode] = [];
      }


      this.selectedClaimboxLists[typecode].push(item);
      this.totalAmount = this.getSeletectedCheckbox().reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      this.totalCount = this.getSeletectedCheckbox().length;
      let salvage = (this.selectedClaimboxLists[2] == null || this.selectedClaimboxLists[2] == undefined || this.selectedClaimboxLists[2] == []) ? 0 : this.selectedClaimboxLists[2].length;
      let claim = (this.selectedClaimboxLists[1] == null || this.selectedClaimboxLists[1] == undefined || this.selectedClaimboxLists[1] == []) ? 0 : this.selectedClaimboxLists[1].length;
      let expenses = (this.selectedClaimboxLists[3] == null || this.selectedClaimboxLists[3] == undefined || this.selectedClaimboxLists[3] == []) ? 0 : this.selectedClaimboxLists[3].length;
      if ((salvage >= 0 && claim <= 0 && expenses <= 0)) {
        this.createButton([
          { id: '1', name: 'Receipt', access: this.accessItem(226) },
          { id: '2', name: 'Claim Payment', access: this.accessItem(227) },
          { id: '3', name: 'Tax Invoice', access: this.accessItem(229) },
          { id: '4', name: 'Credit Note', access: this.accessItem(230) },
          { id: '5', name: 'Journal', access: this.accessItem(228) }
        ]);
      }
      else {
        this.createButton([
          { id: '2', name: 'Claim Payment', access: this.accessItem(227) },
          { id: '3', name: 'Tax Invoice', access: this.accessItem(229) },
          { id: '4', name: 'Credit Note', access: this.accessItem(230) },
          { id: '5', name: 'Journal', access: this.accessItem(228) }
        ]);
      }
      this.getButtons(typecode);
      this.showSnackBar = true;
      console.log(this.selectedClaimboxLists, ' this.seletcedCheckedBox ');
    } else {
      this.selectedClaimboxLists[typecode].filter((element, i) => {
        if (element === item) { this.chkboxIndex = i; }
      });
      this.selectedClaimboxLists[typecode].splice(this.chkboxIndex, 1);
      if (!this.getSeletectedCheckbox().length) {
        this.selectedTransactionType = undefined;
        this.showSnackBar = false;
      }
      this.totalAmount = this.getSeletectedCheckbox().reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      this.totalCount = this.getSeletectedCheckbox().length;
      let salvage = (this.selectedClaimboxLists[2] == null || this.selectedClaimboxLists[2] == undefined || this.selectedClaimboxLists[2] == []) ? 0 : this.selectedClaimboxLists[2].length;
      let claim = (this.selectedClaimboxLists[1] == null || this.selectedClaimboxLists[1] == undefined || this.selectedClaimboxLists[1] == []) ? 0 : this.selectedClaimboxLists[1].length;
      let expenses = (this.selectedClaimboxLists[3] == null || this.selectedClaimboxLists[3] == undefined || this.selectedClaimboxLists[3] == []) ? 0 : this.selectedClaimboxLists[3].length;
      if (salvage >= 0 && claim <= 0 && expenses <= 0) {
        this.createButton([
          { id: '1', name: 'Receipt', access: this.accessItem(226) },
          { id: '2', name: 'Claim Payment', access: this.accessItem(227) },
          { id: '3', name: 'Tax Invoice', access: this.accessItem(229) },
          { id: '4', name: 'Credit Note', access: this.accessItem(230) },
          { id: '5', name: 'Journal', access: this.accessItem(228) }
        ]);
      }
      this.getButtons(typecode);
    }
  }
  getButtons(typecode) {


    let selecteditem = this.getSeletectedCheckbox();
    console.log("selecteditem???", selecteditem);
    if (selecteditem != null && selecteditem != undefined && selecteditem.length != 0)
      this.samePayeeFlag = this.checkSamePayee(selecteditem);
    console.log('samePayeeFlag???', this.samePayeeFlag);

  }
  checkSamePayee(arraySelectedItem) {
    console.log("arraySelectedItem???", arraySelectedItem);
    let valPayee = arraySelectedItem[0].PayeeName;
    let cnt = 0;
    let typecnt = 0;
    let descFlag: boolean = false;

    arraySelectedItem.forEach((element, index) => {
      if (!descFlag
        && element.Description != null
        && element.Description != ""
        && element.Description != undefined) {
        descFlag = true;
        this.headerDescription = element.Description;
        console.log(' this.headerDescription???', this.headerDescription);
      }
      if (element.PayeeName != valPayee)
        cnt++;
      if (element.TypeCode != 2)
        typecnt++;
    });
    this.canGenerateReceipt = (typecnt > 0) ? false : true;
    console.log('canGenerateReceipt???', this.canGenerateReceipt);


    return (cnt > 0) ? false : true;

  }

  getSeletectedCheckbox() {
    let resultArray = [];
    resultArray = this.selectedClaimboxLists.reduce((prev, elem) => {
      elem.map(itema => prev.push(itema));
      return prev;
    }, []);

    return resultArray;
  }
  getTypeCodeArrayData(typecode) {
    let curType;
    curType = this.cliamDetailsData.filter(item => item.TypeCode === typecode);
    this.currentTypeCode[typecode] = curType.length > 0;
    this.dirty = true;
    return curType;
  }

  /* create claim receipt using snackbar  */
  createVoucher(e) {
    this.configdialog = {
      backdrop: true,
      ignoreBackdropClick: true,
    }


    if (this.totalAmount <= 0 && e === '1') {
      this.alertService.warn(RSAMSGConstants.MSGPAYMENTGREATERZERO);
      return false;
    }
    /* create-receipt */
    if (e === '1' && this.totalAmount > 0) {
      if (!this.canGenerateReceipt) {
        this.alertService.warn(RSAMSGConstants.MSGNORECEIPTGENERATION);
        return false;
      }
      this.selectedClaimboxLists = this.getSeletectedCheckbox();
      this.selectedClaimboxLists.map((item, index) => {
        if ((index % 2) == 0) {
          item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        }
      });
      const receiptClaims = this.selectedClaimboxLists.map(x => Object.assign({}, x));
      receiptClaims.map((item, index) => {
        item.RefTranTypeDesc = item.RefTranType;
      });
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedClaimboxLists: receiptClaims,
        CustomerName: this.resultdata[0].CustomerName,
        totalAmount: this.totalAmount,
        receiptVATFlag: true,
      };

      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreateClaimReceiptComponent,
        { class: 'create-modal-dailog', initialState, ignoreBackdropClick: false, keyboard: false });
    }
    // moved message here as it needs to be checked first.
    // if (this.totalAmount >= 0 && e === '2') {
    //   this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
    // }
    /* create-payment */
    if (e === '2') {
      console.log(this.currentTypeCode[1], 'this.currentTypeCode[1]');
      this.formatedAmountDataForCalimPayment();
      console.log(this.amountCorrForClaimPayment, 'this.amountCorrForClaimPayment');
      this.paymentClaims = this.amountCorrForClaimPayment.map(x => Object.assign({}, x));
      /* VAT Implemation changes start */

      this.paymentClaims.map((item) => {
        const copyItem = Object.assign({}, item);
        this.selectedRowItemWithVATPayment.push(item);
        this.selectedRowItemWithVATPayment.push(copyItem);
      });
      console.log(this.selectedRowItemWithVATPayment, 'selectedRowItemWithVATPayment');
      this.selectedRowItemWithVATPayment.map((item, index) => {
        console.log(index, 'index ouside if');
        if ((index % 2) !== 0) {
          console.log(index, 'indexinsideif');
          item.Amount = item.VATAmount || 0;
          item.Description = item.Description + '' + ' included With VAT Amount';
          item.TotallingAccCode = 1110;
          item.CostCenterCode = 11;
          item.GLCode = 4;
        }
      });
      console.log(this.selectedRowItemWithVATPayment, 'after-conversion-selectedRowItemWithVATCredit');
      const totalAmount = this.amountCorrForClaimPayment.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = this.amountCorrForClaimPayment.reduce((prevVal, elem) => prevVal + elem.VATAmount, 0);
      const totalAmountWithVat = (totalAmount + totalVatAmount);
      this.selectedRowItemWithVATPayment.map((item, index) => {
        if ((index % 2) == 0) {
          item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        }
      });
      /* VAT Implemation changes end */

      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedRowEntitiDataTable: this.selectedRowItemWithVATPayment,
        customerName: this.selectedRowItemWithVATPayment[0].PayeeName,
        totalAmount: -(totalAmountWithVat),
        title: 'Claim Payment',
        claimPayment: true,
        paymentVATFlag: true,
        isSetlementTypeForClaim: this.currentTypeCode[1],
        headerDescription: this.headerDescription
      };
      this.showSnackBar = false;
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        class: 'create-modal-dailog',
        initialState
      });
    }
    if (e === '4' && this.totalAmount > 0) {
      if (!this.samePayeeFlag) {
        this.alertService.warn(RSAMSGConstants.SAMEPAYEEMSG);
        return false;
      }
      this.selectedClaimboxLists = this.getSeletectedCheckbox();
      this.formatedAmountDataForCN();

      this.cnClaims = this.amountCorrForClaimCN.map(x => Object.assign({}, x));
      this.setClaimDetails();
      /* VAT Implemation changes start */
      this.cnClaims.map((item) => {
        const copyItem = Object.assign({}, item);
        this.selectedRowItemWithVATCredit.push(item);
        this.selectedRowItemWithVATCredit.push(copyItem);
      });
      console.log(this.selectedRowItemWithVATCredit, 'selectedRowItemWithVATCredit');
      this.selectedRowItemWithVATCredit.map((item, index) => {
        console.log(index, 'index ouside if');
        if ((index % 2) !== 0) {
          console.log(index, 'indexinsideif');
          item.Amount = item.CNVATAmount || 0;
          item.Description = item.Description + '' + ' included With VAT Amount';
          item.CNTotallingAcc = 2230;
          item.CostCenterCode = 11;
          item.CNGLCode = 151;
          item.TotallingAccCode = 2230;
          item.CostCenterCode = 11;
          item.GLCode = 151;

        }
      });

      this.selectedRowItemWithVATCredit.map((item, index) => {
        if ((index % 2) == 0) {
          item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        }
      });
      console.log(this.selectedRowItemWithVATCredit, 'after-conversion-selectedRowItemWithVATCredit');
      const totalAmount = this.cnClaims.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = this.cnClaims.reduce((prevVal, elem) => prevVal + elem.CNVATAmount, 0);
      console.log(totalVatAmount, '5totalvatamount');
      const totalAmountWithVat = (totalAmount + totalVatAmount);

      console.log(totalAmountWithVat, 'totalAmountWithVat');

      /* VAT Implemation changes end */

      this.showSnackBar = false;

      const initialState = {
        selectedRowItem: this.selectedRowItemWithVATCredit,
        totalAmount: totalAmountWithVat,
        customerName: this.customerName,
        ondemandFlagClaim: false,
        cnVATFlag: true,
        cnClaimsFlag: true,
        backdrop: true,
        cnClaimDetails: this.cnClaimDetails,
        ignoreBackdropClick: true,
        headerDescription: this.headerDescription
      };
      this.bsModalRef = this.modalService.show(CreateCreditnotesComponent, Object.assign({},
        this.configdialog, { class: 'create-modal-dailog', initialState }));
      this.bsModalRef.content.title = 'Credit Note';

    }
    if (e === '3' && this.totalAmount < 0) {
      if (!this.samePayeeFlag) {
        this.alertService.warn(RSAMSGConstants.SAMEPAYEEMSG);
        return false;
      }
      this.selectedClaimboxLists = this.getSeletectedCheckbox();
      this.dnClaims = this.selectedClaimboxLists.map(x => Object.assign({}, x));
      console.log(this.dnClaims, 'dn-flag');

      /* VAT Implemation changes start */
      this.dnClaims.map((item) => {
        const copyItem = Object.assign({}, item);
        this.selectedRowItemWithVATDebit.push(item);
        this.selectedRowItemWithVATDebit.push(copyItem);
      });
      console.log(this.selectedRowItemWithVATDebit, 'selectedRowItemWithVATDebit');
      this.selectedRowItemWithVATDebit.map((item, index) => {
        console.log(index, 'index ouside if');
        if ((index % 2) !== 0) {
          console.log(index, 'indexinsideif');
          item.Amount = item.DNVATAmount || 0;
          item.Description = item.Description + '' + ' included With VAT Amount';
          item.DNTotallingAcc = 2230;
          item.CostCenterCode = 11;
          item.DNGLCode = 151;
          item.TotallingAccCode = 2230;
          item.CostCenterCode = 11;
          item.GLCode = 151;
        }
      });
      console.log(this.selectedRowItemWithVATDebit, 'after-conversion-selectedRowItemWithVATDebit');

      this.selectedRowItemWithVATDebit.map((item, index) => {
        if ((index % 2) == 0) {
          item.Amount = item.TypeCode == 2 ? (item.Amount) * -1 : item.Amount;
        }
      });
      console.log(this.selectedRowItemWithVATDebit, 'Salvage / Recovery-selectedRowItemWithVATDebit');
      const totalAmount = this.dnClaims.reduce((prevVal, elem) => prevVal + elem.Amount, 0);
      const totalVatAmount = this.dnClaims.reduce((prevVal, elem) => prevVal + elem.DNVATAmount, 0);
      const totalAmountWithVat = (totalAmount + totalVatAmount);

      /* VAT Implemation changes start end */

      this.showSnackBar = false;
      const initialState = {
        selectedRowItem: this.selectedRowItemWithVATDebit,
        totalAmount: totalAmountWithVat,
        customerName: this.customerName,
        ondemandFlagClaim: false,
        dnVATFlag: true,
        dnClaimsFlag: true
      };

      this.bsModalRef = this.modalService.show(CreateDebitnotesComponent,
        Object.assign({}, this.configdialog, { class: 'create-modal-dailog', initialState }));
      this.bsModalRef.content.title = 'Tax Invoice';

    }

    if (e === '5') {
      const initialState = {
        selectedRowItem: [],
        customerName: this.name,
        ondemandFlagClaim: false,
        isRowPaymentEntity: true
      };
      this.bsModalRef = this.modalService.show(CreatejvComponent, { class: 'create-modal-dailog', initialState, keyboard: false });
      this.bsModalRef.content.title = 'JV';
    }
    if (this.totalAmount > 0) {
      // Commented below  line because claim payment can be crested for cr or dr values
      //if(e === '2')
      //this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
      if (e === '3')
        this.alertService.warn(RSAMSGConstants.MSGTAXINVOICE);
    }
    if (this.totalAmount < 0) {
      if (e === '1')
        this.alertService.warn(RSAMSGConstants.CREDITEXCEEDMSG);
      if (e === '4')
        this.alertService.warn(RSAMSGConstants.MSGCREDITNOTE);
    }
  }

  /* to unceck all the selected box*/
  unCheckAllSelectedCheckbox() {
    this.seletcedCheckedBox.map(element => {
      element.eventRef.checked = false;
    });
  }

  /* hide snackbar == make selected checkbox empty and reset selected TransactionType */
  hideSnackBar(e) {
    this.showSnackBar = false;
    this.unCheckAllSelectedCheckbox();
    this.selectedClaimboxLists = [];
  }

  /* converting postive to negtive */
  formatedAmountDataForCalimPayment() {
    this.selectedClaimboxLists = this.getSeletectedCheckbox();
    const amountCorrForClaimP = this.selectedClaimboxLists.map(x => Object.assign({}, x));
    this.amountCorrForClaimPayment = [];
    for (let i = 0, l = amountCorrForClaimP.length; i < l; i++) {
      const item = amountCorrForClaimP[i];
      item.Amount = item.TypeCode == 2 ? -(item.Amount) : item.Amount;
      this.amountCorrForClaimPayment[i] = item;
      console.log(this.amountCorrForClaimPayment, 'amountCorrForClaimPayment');
      console.log(this.selectedClaimboxLists, 'in loop');
    }

  }
  /* converting postive to negtive */
  formatedAmountDataForCN() {
    const amountCorrForCN = this.selectedClaimboxLists.map(x => Object.assign({}, x));
    this.amountCorrForClaimCN = [];
    for (let i = 0, l = amountCorrForCN.length; i < l; i++) {
      const item = amountCorrForCN[i];
      item.Amount = item.TypeCode == 2 ? -(item.Amount) : item.Amount;
      this.amountCorrForClaimCN[i] = item;
      console.log(this.amountCorrForClaimCN, 'amountCorrForClaimCN');
      console.log(this.selectedClaimboxLists, 'in loop');
    }

  }
  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  setClaimDetails() {
    if (this.cnClaims.length > 0) {
      console.log(this.cnClaims[0] + 'setClaimDetails');
      const topRecord = this.cnClaims[0];
      const typecode = topRecord.EntryTypeCode;
      let selectedIDs: any;
      if (typecode === 1) {
        selectedIDs = this.cnClaims.map(({ PolicyNumber }) => PolicyNumber);
        this.cnClaimDetails = "POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 2) {
        selectedIDs = this.cnClaims.map(({ PolicyNumber }) => PolicyNumber);
        this.cnClaimDetails = "SAL POL No's " + selectedIDs.filter(this.onlyUnique);
      }
      if (typecode === 3) {
        selectedIDs = this.cnClaims.map(({ ClaimNumber }) => ClaimNumber);
        this.cnClaimDetails = "Exp CL No's " + selectedIDs.filter(this.onlyUnique);
      }

    }
  }


}
