import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { CreateDebitNoteReceiptComponent } from './receipt/create-receipt.component';
import { CreatePaymentComponent } from 'src/app/finance/payments/create-payment/create-payment.component';
import { TaxinvoicepreviewComponent } from 'src/app/finance/preview/uae/taxinvoicepreview/taxinvoicepreview.component'
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
@Component({
  selector: 'rsa-debitnote',
  templateUrl: './tax.component.html',
  styleUrls: ['./tax.component.scss']
})
export class TaxComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('debitNoteNo') debitNoteNo: any;
  @Input('category') category: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;


  glnumber: string;
  idnumber = '';
  name = '';
  pageSize = 15;
  currentpage: any = 1;
  totalAmount = 0;
  totalCount = 0;
  showSnackBar = false;
  bsModalRef: BsModalRef;
  customerName;
  selectedItems = [];
  newSelectedRowEntitiDataTable = [];
  selectedTransactionItems = [];
  newSelectedRowPaymentDataTable = [];
 isTax:boolean;
  constructor(private allowAccess: UserAutherizationService, private searchService: SearchService,
    private modalService: BsModalService, private alertService: AlertService) { super() }

  ngOnInit() {
    super.ngOnInit();
    this.isTax = this.accessItem(212);
    this.customerName = this.resultdata[0].PolicyDetails[0].CustomerName;
    this.createButton([
        { id: '14', name: 'Receipt', access: this.accessItem(213) },
      { id: '15', name: 'Payment' , access: this.accessItem(244)}
    ]);
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data) {
    this.headerdata = data;
  }
  accessItem(functionid){
    console.log(this.allowAccess.isAllowed(functionid));
    return this.allowAccess.isAllowed(functionid)
  }

  selectDebitNoteData() {
    this.selectedItems = [];
    this.totalAmount = 0;
    this.totalCount = 0;
    this.resultdata[0].PolicyDetails.map((ele, index) => {
      if (this.selectedTransactionItems[index]) {
        ele.RefTranTypeName = 'Tax Invoice';
        ele.RefTransactionID = ele.DebitNoteNo;
        ele.RefTransactionType = 11;
        // ele.Description = ele.Description;
        this.selectedItems.push(ele);
        this.totalCount = this.totalCount + 1;
        this.totalAmount = this.totalAmount + ((ele.Amount != null && ele.Amount != undefined) ? parseFloat(ele.Amount) : 0);
      }
    });
    this.showSnackBar = (this.selectedItems.length > 0) ? true : false;
  }



  buttonHandler(e) {

    console.log(this.totalAmount, 'this.totalAmount');
    if (e === '14') {
      if (this.totalAmount < 0) {
        this.alertService.warn(RSAMSGConstants.MSGPAYMENTGREATERZERO);
        return false;
      }
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedRowEntitiDataTable: this.selectedItems,
        customerName: this.customerName,
        totalAmount: this.totalAmount,
        ondemandFlag: false,
      };
      this.hideSnackBar(e);
      this.bsModalRef = this.modalService.show(CreateDebitNoteReceiptComponent, {
        class: 'create-modal-dailog',
        initialState,
        ignoreBackdropClick: true
      });
    }
    if (e === '15') {
      if (this.totalAmount > 0) {
        this.alertService.warn(RSAMSGConstants.MSGPAYMENTLESSZERO);
        return false;
      }
      this.formatedPaymentData();
      const initialState = {
        backdrop: true,
        ignoreBackdropClick: false,
        selectedRowEntitiDataTable: this.newSelectedRowPaymentDataTable,
        customerName: this.customerName,
        totalAmount: this.totalAmount,
        ondemandFlag: false,
      };
      this.hideSnackBar(e);
      this.bsModalRef = this.modalService.show(CreatePaymentComponent, {
        class: 'create-modal-dailog',
        initialState,
        ignoreBackdropClick: true
      });
    }
  }
 /* to unceck all the selected box*/
//  unCheckAllSelectedCheckbox() {
//   this.selectedTransactionItems.map(element => {
//     element.eventRef.checked = false;
//   });
// }
formatedPaymentData() {
  this.newSelectedRowPaymentDataTable = [];
  const selectedItems = this.selectedItems.map(item => Object.assign({}, item));
  for (let i = 0, l = selectedItems.length; i < l; i++) {
    const item = selectedItems[i];
    item.Amount = -(item.Amount);
    item.amt = (item.Amount);
    this.newSelectedRowPaymentDataTable[i] = item;
  }
  console.log(this.newSelectedRowPaymentDataTable, 'newSelectedRowPaymentDataTable');
}
hideSnackBar(e) {
    this.showSnackBar = false;
    // this.unCheckAllSelectedCheckbox();
    this.selectedTransactionItems = [];
  }
  previewTaxIncoice(){
    this.bsModalRef = this.modalService.show(TaxinvoicepreviewComponent, { class: 'preview-modal-dailog', ignoreBackdropClick: true });
    this.bsModalRef.content.data = this.resultdata[0];
    this.bsModalRef.content.fromCategory = 6;
    this.bsModalRef.content.totalAmount =this.resultdata[0].totalAmount;
    this.bsModalRef.content.backdrop = true;
    this.bsModalRef.content.isView=true;
  }
}
