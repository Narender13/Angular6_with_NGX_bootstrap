import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../../service/search.service';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { BaseSearchComponent } from '../basesearch/basesearch.component';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { ReceiptpreviewComponent } from 'src/app/finance/preview/uae/receiptpreview/receiptpreview.component';

@Component({
  selector: 'rsa-approval-code',
  templateUrl: './approval-code.component.html',
  styleUrls: ['./approval-code.component.scss']
})
export class ApprovalCodeComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('approvalCode') approvalCode: any;
  @Input('category') category: any;
  @Input('ReceiptNo') ReceiptNo: any;
  @Input() settingsdata: any;
  @Input() headerdata: any;

  glnumber: string;
  isopen: boolean;
  pageSize = 15;
  currentpage: any = 1;
  idnumber = '';
  name = ' ';
  previewresult:any;
  bsModalRef: BsModalRef;
  errorMsg:string;
  constructor(private searchService: SearchService, private modalService: BsModalService) {
    super();
  }

  ngOnInit() {
    super.ngOnInit();
  }

  pageChanged(ev) {
    this.currentpage = ev;
  }

  updateTableHeader(data) {
    this.headerdata = data;
  }
  previewReceipt(data) {
    this.searchService.getPreviewReceipt(data).subscribe(
      (data) => {
        this.previewresult = data;
        console.log( this.previewresult,'this.previewresult');
        this.bsModalRef = this.modalService.show(ReceiptpreviewComponent, {ignoreBackdropClick:true, class: 'preview-modal-dailog' });
           this.bsModalRef.content.data = this.previewresult;
           this.bsModalRef.content.fromCategory = 2;
           //this.bsModalRef.content.totalAmount = this.previewresult.totalAmount;
     
       },
      errorRturn => {
       this.errorMsg = errorRturn;
     }
    )
   }
}
