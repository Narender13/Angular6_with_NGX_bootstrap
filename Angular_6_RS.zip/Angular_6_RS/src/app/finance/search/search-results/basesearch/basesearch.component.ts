import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-basesearch',
  templateUrl: './basesearch.component.html',
  styleUrls: ['./basesearch.component.css']
})
export class BaseSearchComponent implements OnInit {
  showtabledata = -1;
  constructor() { }
  symbol: string;
  buttonName = [];
  ngOnInit() {
    this.symbol = (localStorage.getItem("symbol"));
  }
  checkEmptyRecord(data, innerCollection) {
    if (innerCollection == '')
      return (
        data == null ||
        data == undefined ||
        data.length == 0
      );
    else
      return (
        data == null ||
        data == undefined ||
        data.length == 0 ||
        data[innerCollection] == null ||
        data[innerCollection] == undefined ||
        data[innerCollection].length == 0
      );
  }

  toggle(index: number): void {
    this.showtabledata = (this.showtabledata !== index) ? index : -1;
  }


  createButton(buttonNames) {
    this.buttonName = buttonNames;
  }

}
