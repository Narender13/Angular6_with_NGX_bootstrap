
export class CreateReceipt {
    ReceiptDate: string;
    ReceiptMode: number;
    PrintDate: string;
    ReceiptType: number;
    PreparedBy: number;
    ModifiedBy: string;
    Approvers: any[];
    CustomerID?: any;
    TerminalUserID: number;
    TerminalUserName?: any;
    CountryCode: number;
    LocationCode: string;
    RegionCode: string;
    TerminalID:any;
    ReprintNo?: any;
    InstrumentRefNo?: any;
    CostCenterCode: string;
    ArabicDescription?: any;
    TotallingAccCode: string;
    RecevierBankCode: string;
    PayeeBankCode: string;
    PayeeBankName: string;
    PayeeName: string;
    ChequeNo?: any;
    ChequeDate?: string;
    EnglishDescription: string;
    ReceiptDetails: ReceiptDetail[];
    Amount: string;
}



export class ReceiptDetail {
    CounterPartyRef?: any;
    LocationCode: string;
    LocationDesc: string;
    CountryCode: number;
    CostCenterCode: string;
    Description: string;
    Amount: string;
    RefTransactionID?: any;
    RefTransactionType: number;
    IsCreditEntry: boolean;
    PolicyID?: any;
    PolicyNumber?: any;
    ModifiedBy: string;
    ReceiptDate?: any;
    AnalysisCode: string;
    DepartmentCode?: any;
    Department?: any;
    RefTransactionSerialNo?: any;
    GLCode: number;
    GLCodeDesc: string;
    RegionCode: string;
    TotallingAccCode: number;
    ClassCode: string;
    PolicyYear?: any;
    PolicyType?: any;
}



