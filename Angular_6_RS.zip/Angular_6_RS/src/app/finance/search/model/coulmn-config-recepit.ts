export interface CoulmnConfigRecepit {
    id: number;
    name: string;
    checked: boolean;
    class: string;
}
