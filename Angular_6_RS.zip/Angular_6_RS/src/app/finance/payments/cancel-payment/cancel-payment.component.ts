import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap';
import { CreateService } from 'src/app/finance/receipts/create-receipt/service/create.service';
import { Subject } from 'rxjs';
import { MessageService } from 'src/app/core/message/service/message.service';
import { CreatePaymentService } from '../create-payment/service/create-payment.service';
import { DatePipe } from '@angular/common';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
@Component({
  selector: 'rsa-cancel-payment',
  templateUrl: './cancel-payment.component.html',
  styleUrls: ['./cancel-payment.component.scss']
})
export class CancelPaymentComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    public bsModalRef: BsModalRef,
    private alertService: AlertService,
    private createService: CreatePaymentService, private messageService: MessageService) { }
  public onClose: Subject<any>;
  cancelpaymentform: FormGroup;
  dataresult: any;
  ev: any;
  PaymentID: any;
  enableFlag = false;
  viewscreen = false;
  PaymentNo: any;
  CancelReceiptNo: any;
  errorMsg: string;
  Defaulttext;
  paymentData: any;
  currentDate;
  isClaimPayment: boolean;
  donloadLink = false;
  ngOnInit() {
    this.currentDate = new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy');
    this.Defaulttext = `Payment No:${this.PaymentID} is reversed on ${this.currentDate}`;
    this.cancelpaymentform = this.fb.group({
      Comments: [this.Defaulttext],
      VoucherNo: [],
      PaymentNo: []
    });
    console.log(this.paymentData, 'paymentData');
    if (this.paymentData[0] != null && this.paymentData[0].VoucherPaymentCollection.length > 0) {
      this.donloadLink = true;
    } else {
      this.donloadLink = false;
    }
  }

  changeComments() {
    let ctrl = this.cancelpaymentform.get('Comments');
    this.enableFlag = ctrl.pristine || ctrl.value.length > 0;
    console.log(this.enableFlag, 'this.enableFlag');
  }

  closeModal(ev) {
    this.bsModalRef.hide();
    ev.checked = false;
  }

  cancelPayment(paymentid, ev) {
    this.cancelpaymentform.controls['VoucherNo'].setValue(parseInt(paymentid));
    console.log(this.cancelpaymentform.value, 'this.cancelpaymentform.value');
    //this.viewscreen = true;
    this.createService.cancelPayment(this.cancelpaymentform.value, this.isClaimPayment).subscribe(
      (data) => {
        console.log(data, ' dataresult payment');
        if(data !=null)
        {
          this.dataresult = data;
          this.PaymentNo = data.VoucherNo;
          this.CancelReceiptNo = this.dataresult.ReceiptNo;
          this.viewscreen = true;
        }
        else
        {
          this.viewscreen=false;
          this.alertService.error('Payment Cannot be deleted');
          this.closeModal(ev);
        }       
        ev.disabled = true;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  exportPayment() {
    this.createService.exportPayment(this.paymentData[0]).subscribe(
      data => {
        console.log(data, ' dataresult payment');
        this.donloadList(data);
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  donloadList(blob: any) {
    const filename = 'CancelReceipt.csv';
    const type = 'text/csv;charset=utf-8';
    const blobfile = new Blob([blob], { type: type });
    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, filename);
    } else {
      const url = URL.createObjectURL(blobfile);
      // create hidden dom element (so it works in all browsers)
      const a = document.createElement('a');
      // create file, attach to hidden element and open hidden element
      a.href = url;
      a.download = 'CancelledVoucher(s).csv';
      document.body.appendChild(a);
      a.click();

      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  }
  viewPayment(ev) {
    ev.checked = false;
   // this.messageService.sendMessage(true);
   this.messageService.sendMessage({'isAuthorized':true});
    this.bsModalRef.hide();
  }

}
