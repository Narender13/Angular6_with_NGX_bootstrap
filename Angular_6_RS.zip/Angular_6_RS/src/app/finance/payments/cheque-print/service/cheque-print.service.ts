import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams, } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { ChequePrint } from '../model/cheque-print.model';


@Injectable({ providedIn: 'root' })
export class ChequePrintService {
    
    httpheaderspdf = new HttpHeaders(
        {
            'Content-Type': 'application/octet-stream',
            'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
            'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Origin': '*'
        });

    constructor(private http: HttpClient) { }

    getChequePrintData(param: any): Observable<ChequePrint[]> {
        return this.http.get<any>(RSAENDPOINTConstants.ChequePrintDetail + param).pipe(
            map(res => res as ChequePrint[]),
            // map(res => ({id: res.VoucherNo, VoucherDate: res.VoucherDate})),
            catchError(handleErrorObservable<any>('getChequePrintData')));
    }
    ChangeChequePrintPrinted(param: any): Observable<any> {
        return this.http.get(RSAENDPOINTConstants.ChequePrintStatusPrinted + param, {
            responseType: 'blob',
            headers: this.httpheaderspdf
        }).pipe(
            map(res => res),
            // map(res => this.printCheques(res, 'application/pdf', 'chequePrint.pdf')),
            catchError(handleErrorObservable<any>('ChangeChequePrintPrinted')));
    }

    ChangeChequePrintDamaged(param: any): Observable<any> {
        const body = JSON.stringify(param);
        console.log(body, 'body-chequeprint-damaged');
        return this.http.post(RSAENDPOINTConstants.ChequePrintStatusDamaged, body).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('ChangeChequePrintDamaged')));
    }
    printCheques(blob: any, type: string, filename: string): string {
        const blobfile = new Blob([blob], { type: type });
        const url = URL.createObjectURL(blob);
        const printWindow = window.open(url, filename);
        printWindow.print();
        // const url = window.URL.createObjectURL(blob); // <-- work with blob directly

        // // create hidden dom element (so it works in all browsers)
        // const a = document.createElement('a');
        // // a.setAttribute('style', 'display:none;');
        // document.body.appendChild(a);

        // // create file, attach to hidden element and open hidden element
        // a.href = url;
        // a.download = filename;
        // // a.click();
        return url;
    }
}
