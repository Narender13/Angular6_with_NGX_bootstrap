import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { handleErrorObservable } from '../../../../shared/utilites/helper';


@Injectable({ providedIn: 'root' })
export class CreatePaymentService {
    private cachedMasterData: Observable<any>;

    constructor(private http: HttpClient) { }


    createPayment(param: any) {
        console.log(param, 'param');
        return this.http.post<any>(RSAENDPOINTConstants.CREATEPAYMENT, param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createPayment')));
    }
    createClaimPayment(param: any) {
        console.log(param, 'param');
        return this.http.post<any>(RSAENDPOINTConstants.CREATECLAIMPAYMENT, param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('createClaimPayment')));
    }

    cancelPayment(param, isClmPayment) {
        const body = JSON.stringify(param);
        console.log(body, 'body');
        let url = '';
        if (isClmPayment) {
            url = RSAENDPOINTConstants.CLMPAYMENTCANCEL;
        }
        else {
            url = RSAENDPOINTConstants.PAYMENTCANCEL;
        }
        return this.http.post(url, body).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('cancelPayment')));
    }

    exportPayment(param) {
        const body = JSON.stringify(param);
        console.log(body, 'body');
        return this.http.post(RSAENDPOINTConstants.EXPORTPAYMENT, body, {
            responseType: 'arraybuffer'
        }).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('EXPORTPAYMENT')));
    }

    savePayment(param, flagClaimPayment) {
        const body = JSON.stringify({ 'vocherNo': param });
        let url = '';
        if (flagClaimPayment)
            url = RSAENDPOINTConstants.SAVECLAIMPAYMENT + param;
        else
            url = RSAENDPOINTConstants.SAVEPAYMENT + param;
        console.log(url, 'url');
        return this.http.post<any>(url, {}).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('savePayment')));
    }

    savePaymentUnapproved(param, flagClaimPayment?) {
        let body = JSON.stringify({ 'VoucherNo': param });
        let url = '';
        if (flagClaimPayment)
            url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
        else
            url = RSAENDPOINTConstants.FINIALIZEORREJECTED;
        console.log(url, 'url');
        return this.http.put<any>(url, body).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('savePaymentUnapproved')));
    }

    sendEmail(param) {
        console.log(param);
        const body = JSON.stringify(param);
        const url = RSAENDPOINTConstants.RECEIPTEMAIL;
        console.log(url, 'url');
        return this.http.post<any>(url, body).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('sendEmail')));
    }
    /* downloadCancelPaymentList(param) {
         const body = JSON.stringify(param);
         const url = RSAENDPOINTConstants.DOWNLOADCANCELPAYMENTLIST;
         console.log(url, 'url');
         return this.http.post (url, body).pipe(
             map(res => res),
             catchError(handleErrorObservable<any>('downloadCancelPaymentList')));
     }*/

}
