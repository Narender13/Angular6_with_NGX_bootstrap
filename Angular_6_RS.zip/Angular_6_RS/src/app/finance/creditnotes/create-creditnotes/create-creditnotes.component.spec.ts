import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCreditnotesComponent } from './create-creditnotes.component';

describe('CreateCreditnotesComponent', () => {
  let component: CreateCreditnotesComponent;
  let fixture: ComponentFixture<CreateCreditnotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateCreditnotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateCreditnotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
