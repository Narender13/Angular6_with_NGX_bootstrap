import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { map, catchError } from 'rxjs/operators';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';

@Injectable({
  providedIn: 'root'
})
export class CreateCreditnotesService {

  
constructor(private http: HttpClient) { }
  createCreditNote(param: any) {
    console.log(param, 'param');
    return this.http.post<any>(RSAENDPOINTConstants.CREATECREDITNOTE, param).pipe(
        map(res => res),
        catchError(handleErrorObservable<any>('createPayment')));
}
}
