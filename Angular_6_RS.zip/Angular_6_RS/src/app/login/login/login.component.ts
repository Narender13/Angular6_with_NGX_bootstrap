import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';

@Component({
  selector: 'rsa-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(
    private router: Router,
    private authService:AuthService,
    private userAutherizationService:UserAutherizationService
  ) { }
  private errorMsg:string="";
  private userData:any;
    ngOnInit() {
      
    }
   
    login(userName:string,password:string){
      this.authService.login(userName,password).subscribe(
        data => {
          this.userData=data;
          this.authService.setAuthToken(this.userData.token);
          this.authService.setRefreshToken(this.userData.refreshtoken);
          this.userAutherizationService.setAuthorizationFunctionIds(this.userData.functionids);
          this.authService.goHome();
         },
        errorRturn => {
            this.errorMsg=errorRturn;
        }); 
    }
    
}
