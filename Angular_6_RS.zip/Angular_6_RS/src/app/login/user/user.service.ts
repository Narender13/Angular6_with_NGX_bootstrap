import { Injectable } from '@angular/core';
import { RSAConstants } from '../../core/constants/rsaconstant';

@Injectable()
export class UserService {

  constructor() { }
 
  roleMatch(functionid:any): boolean {
    let allowedfunctionids: string = this.getFunctionIds();
    let isMatch : boolean =(allowedfunctionids.includes(functionid)) ? true : false;
    return isMatch;
  }
  setFunctionIds(data:any){
    localStorage.setItem(RSAConstants.functionids,JSON.stringify(data));
  }
  getFunctionIds():any{
    return JSON.parse(localStorage.getItem(RSAConstants.functionids));
  }
  clearUserRole(){
    return localStorage.removeItem(RSAConstants.functionids)
  }
}
