import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'rsa-approval-list',
  templateUrl: './approval-list.component.html',
  styleUrls: ['./approval-list.component.scss']
})
export class ApprovalListComponent implements OnInit {
 

  displayApprover = false;
  @Input() users = [];
  @Input() approverusers: string;
 
  @Output() userChangeOp = new EventEmitter();



  constructor() { }


  ngOnInit() {
  
  }

  onUserChange(event, item) {
    this.userChangeOp.emit({ event: event, item: item });
  }



 

}
