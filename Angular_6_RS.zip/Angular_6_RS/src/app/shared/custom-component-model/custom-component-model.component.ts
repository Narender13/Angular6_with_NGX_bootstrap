import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-custom-component-model',
  templateUrl: './custom-component-model.component.html',
  styleUrls: ['./custom-component-model.component.scss']
})
export class CustomComponentModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
