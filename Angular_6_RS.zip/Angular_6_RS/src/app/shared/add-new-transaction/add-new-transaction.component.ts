import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { BsModalService } from 'ngx-bootstrap/modal';
import { AlertService } from 'src/app/shared/alert-rsa/alert.service';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { AmtValidator } from 'src/app/shared/utilites/helper';



@Component({
  selector: 'rsa-add-new-transaction',
  templateUrl: './add-new-transaction.component.html',
  styleUrls: ['./add-new-transaction.component.scss']
})
export class AddNewTransactionComponent implements OnInit {
  voucherDetails: FormGroup;
  errorMsg;
  cachedDtlTot: any = [];
  branchdata: any[];
  pjctindicator: any[];
  department: any[];
  transactiontype: any[];
  glaccount: any[];
  isEntityPaymentFeildReq;
  dtltotallingacc: any[];
  costcentredata: any[];
  voucherDetailsLength;
  ondemandFlag = false;
  actionBtn: any;
  TotallingAccCode: any;
  GLCodeDesc: any;
  defaultGLCode: any;
  loccode: any;
  ccode: any;
  isPaymentFromEntity;
  totAccCode: any;
  list: any[] = [];
  cndnflag;
  cachedGL: any[];
  EnglishDescription: any;
  NewTransactionDetails: any;
  isDebit = true;
  @Output() valueChange = new EventEmitter();

  constructor(
    private fb: FormBuilder,
    private modalService: BsModalService,
    public bsModalRef: BsModalRef,
    private alertService: AlertService,
    private masterDataService: MasterDataService
  ) { }
  calculateNetAmt() {
    // this.voucherDetails.patchValue({
    //   NetAmount: Number(this.voucherDetails.get('Amount').value || 0) + Number(this.voucherDetails.get('Commision').value || 0) || 0
    // });
    this.NewTransactionDetails['NetAmount'] = Number(this.NewTransactionDetails['Amount']
      || 0) + Number(this.NewTransactionDetails['Commision'] || 0) || 0;
  }


  setCreditEntry(e, IsDebitEntry, voucherDetails) {
    console.log(e.target.checked);
    if (!e.target.checked) {
      this.isDebit = false;
    }
  }
  setTransactiontypeDesc(e: any) {
    const transaction: any = this.transactiontype.filter((data) => data.Code == e.srcElement.value);
    this.voucherDetails.patchValue({
      TransactionType: transaction[0].E_desc
    });

  }

  ngOnInit() {
    this.voucherDetails = this.createPaymentArrayGroup();
    setTimeout(() => {
      this.branchdata = this.branchdata || null;
      this.pjctindicator = this.pjctindicator || null;
      this.department = this.department || null;
      this.transactiontype = this.transactiontype || null;
      this.glaccount = this.glaccount[0] || null;
      this.isEntityPaymentFeildReq = this.isEntityPaymentFeildReq || false;
      this.TotallingAccCode = this.TotallingAccCode;
      this.GLCodeDesc = this.GLCodeDesc;
      console.log(this.isEntityPaymentFeildReq);
      this.dtltotallingacc = this.bsModalRef.content.dtltotallingacc[0] || null,
        this.costcentredata = this.costcentredata || null;
      this.voucherDetailsLength = this.voucherDetailsLength || 0;
      this.loccode = this.voucherDetails.get('LocationCode').value;
      this.EnglishDescription = this.EnglishDescription || null;

      this.totAccCode = this.totAccCode;
      this.ccode = this.ccode;
      this.isPaymentFromEntity = true;


    }, 0);


  }

  changeCostcenter(ev) {
    this.getAllCostCenterData(ev);
  }

  getAllCostCenterData(ev) {
    this.masterDataService.getLookupCostCenters().subscribe((data) => {
      this.costcentredata = data;
      console.log(data, 'costcentredata');
      this.getTotallingDetailData(ev);
    },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  getTotallingDetailData(ev) {
    console.log(ev);
    const index = ev.index;
    const initFlag = ev.flag;
    const ccentre = this.voucherDetails.get('CostCenterCode').value;

    const param = 'ccCode=' + ccentre;

    this.masterDataService.getDetailTotallingAccount(param).subscribe(
      dataReturn => {
        this.dtltotallingacc = dataReturn;
        console.log(this.dtltotallingacc[0]);
        const totcode = this.dtltotallingacc[0].Code;
        if (!initFlag) {
          if (this.isPaymentFromEntity) {
            this.voucherDetails.patchValue({ 'TotallingAccCode)': this.TotallingAccCode });
          }
          this.voucherDetails.patchValue({ 'TotallingAccCode': totcode });
        }
        if (initFlag) {
          this.cachedDtlTot = dataReturn;
          if (this.isPaymentFromEntity) {
            this.voucherDetails.patchValue({ 'TotallingAccCode': this.TotallingAccCode });
          }
        }
        if (this.isPaymentFromEntity) {
          this.getGLData({ ev: this.defaultGLCode, flag: initFlag });
        }
        this.getGLData({ ev: totcode, flag: initFlag });
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  getGLData(ev) {
    console.log(ev);
    const initFlag = ev.flag;
    const val = ev.ev;
    const ccentre = this.voucherDetails.get('CostCenterCode').value;
    const totcode = (initFlag) ? this.voucherDetails.get('TotallingAccCode').value : val;

    const param = 'totAccCode=' + totcode +
      '&ccCode=' + ccentre;
    console.log('param-GL', param);

    this.masterDataService.getDetailGlAccount(param).subscribe(
      dataReturn => {
        console.log(dataReturn, 'dataretrun');
        this.glaccount = dataReturn;
        console.log(this.glaccount[0].Code);
        if (!initFlag) {
          this.voucherDetails.patchValue({ 'GLCode': this.glaccount[0].Code });
          this.voucherDetails.patchValue({ 'GLCodeDesc': this.glaccount[0].E_Code_Desc });
        }
        if (initFlag) {
          this.cachedGL = dataReturn;
          if (this.isPaymentFromEntity) {
            this.voucherDetails.patchValue({ 'GLCode': this.defaultGLCode });
            this.voucherDetails.patchValue({ 'GLCodeDesc': this.GLCodeDesc });
          }
        }
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  /* set value for glcode */
 
  /* set value for glcode */
  setHiddenValue(event: any) {
    console.log(event);
    const ev = event.item.Code;
    this.voucherDetails.get('GLCode').setValue(ev);
  }

  clearGLCode() {
    const list = ['GLCode', 'GLCodeDesc'];
    list.forEach((item) => {
      this.voucherDetails.get(item).setValue('');
    });
  }

  /* form array for recept details */
  createPaymentArrayGroup(): FormGroup {
    return this.fb.group({
      CounterPartyRef: [],
      LocationCode: [localStorage.getItem('locationcode')],
      CountryCode: [1],
      ChequeDate: null,
      BranchCode: [localStorage.getItem('locationcode')],
      LocationDesc: ['Dubai'],
      CostCenterCode: [localStorage.getItem('costcentre')],
      Description: [''],
      Amount: ['', [Validators.required, AmtValidator]],
      RefTransactionID: [],
      RefTransactionType: [2],
      TransactionType: ['PAYMENT OTHERS'],
      IsDebitEntry: [true],
      PolicyID: [],
      PolicyNumber: [],
      ModifiedBy: ['1'],
      ReceiptDate: [new DatePipe('en-US').transform(new Date(), 'dd-MM-yyyy')],
      AnalysisCode: [],
      DepartmentCode: [],
      Department: [],
      VoucherDate: [new DatePipe('en-US').transform(new Date(), 'dd-MM-yyyy')],
      Commision: [0],
      NetAmount: 0,
      RefTransactionSerialNo: [],
      GLCode: [this.defaultGLCode, Validators.required],
      GLCodeDesc: [this.GLCodeDesc],
      RegionCode: [localStorage.getItem('regioncode')],
      TotallingAccCode: [this.TotallingAccCode],
      PolicyYear: [],
      PolicyType: [],
      PlaceHolderCode: [],
      GLAccountName: [],
      CostCenterName: [],
      TotallingAccName: [],
      BranchName: [],
      GLAccount: [],
      ClassCode: [0],
      ClaimID: [],
      VoucherType: [],
      TransactionNo: [],
      RefTranType: [],
      VoucherNo: [0],
      ExcelVoucherNo: [0],
      CityCode: [],
      // Aaded new formControlName to make row readonly if coming from selection rows
      newAddedRow: true,
      CauseOfLoss: '',
      NatureOfLoss: '',
      settlementType: ''
    });
  }

  addNewMatchedRecord() {
    this.voucherDetails.get('Amount').markAsTouched();
    if (this.voucherDetails.valid) {
      this.NewTransactionDetails = this.voucherDetails.value;
      if (!this.isDebit) {
        this.NewTransactionDetails['Amount'] = -Math.abs(this.NewTransactionDetails['Amount']);
      }
      this.calculateNetAmt();
      this.valueChange.emit(this.NewTransactionDetails);
      this.resetvoucherDetailsFormvalues();
      this.bsModalRef.hide();
    }
  }
  resetvoucherDetailsFormvalues() {
    // const voucherForm =  this.voucherDetails['controls'];
    this.voucherDetails['controls'].Amount.reset('');
    this.voucherDetails['controls'].Description.reset('');
    this.voucherDetails['controls'].RefTransactionID.reset('');
    this.voucherDetails['controls'].RefTransactionSerialNo.reset('');
    this.voucherDetails['controls'].CounterPartyRef.reset('');
  }
}
