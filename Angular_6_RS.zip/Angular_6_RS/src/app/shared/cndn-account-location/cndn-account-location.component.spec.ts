import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CndnAccountLocationComponent } from './cndn-account-location.component';

describe('CndnAccountLocationComponent', () => {
  let component: CndnAccountLocationComponent;
  let fixture: ComponentFixture<CndnAccountLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CndnAccountLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CndnAccountLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
