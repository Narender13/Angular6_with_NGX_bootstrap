import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';
@Component({
  selector: 'rsa-cndn-account-location',
  templateUrl: './cndn-account-location.component.html',
  styleUrls: ['./cndn-account-location.component.scss']
})
export class CndnAccountLocationComponent implements OnInit {
  @Input() accountInfo: FormGroup;
  @Input() branchdata = [];
  @Input() costcentredata = [];
  @Input() totallingacc = [];
  @Input() glaccount = [];
  @Input() index;
  @Output() getTotallingDataO = new EventEmitter();
  @Output() setBankDataO = new EventEmitter();
  @Output() getTotalAmount = new EventEmitter();
  @Output() deleteReceiptRow = new EventEmitter();
  @Output() getGLdataCnDnO = new EventEmitter();
  @Output() getTotallingDetailDataO = new EventEmitter();
  @Output() setHiddenValueO = new EventEmitter();
  @Output() clearGLCodeO = new EventEmitter();
  @Output() changeCostcenterO = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }


  getGLDataCnDn(ev) {
    this.getGLdataCnDnO.emit({ ev: ev.target.value });
  }

  getTotallingDetailData(index, flag) {
    this.getTotallingDetailDataO.emit({ index: index, flag: flag });
  }
  setHiddenValue(event, index, item, item1) {
    this.setHiddenValueO.emit({ event: event, index: index, item: item, item1: item1 });
  }
  clearGLCode(ev, index) {
    this.clearGLCodeO.emit({ event: ev, index: index });
  }

  changeCostcenter(ev, index, flag) {
    this.changeCostcenterO.emit({ event: ev, index: index, flag: flag });
  }

}
