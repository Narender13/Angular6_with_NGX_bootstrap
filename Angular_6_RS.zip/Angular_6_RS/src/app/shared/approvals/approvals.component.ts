import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MasterDataService } from 'src/app/finance/services/finance.masterdata.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'rsa-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.scss']
})
export class ApprovalsComponent implements OnInit {

  @Input() users: any = [];
  errorMsg: string;
  displayApprover = false;
   @Input() approverusers: string;
   @Input() approvererror: string;
   @Input() unApprovedHideFinalizeButton: boolean;
   @Output() userChangeOp = new EventEmitter();
  
  constructor(protected masterDataService: MasterDataService,private fb: FormBuilder) { }

  ngOnInit() {}
  
  onUserChange(event, item) {
    this.userChangeOp.emit({ event: event, item: item });
  }

   
}
