export interface Activity {
    id: number;
    menuid:number;
    imgpath: string;
    item: string;
    path: string;
    name: string;
    isChecked?: boolean;
}
