import { Component, OnInit } from '@angular/core';
import { SearchService } from '../finance/search/service/search.service';
import { Router, NavigationEnd, Params, ActivatedRoute } from '@angular/router';
import { HomeService } from './services/home.service';
import { Activity } from './modal/activity';
import { CategoryType } from '../finance/search/model/category';
import { MytaskRemainder, Unapproved, Draft, PendingApproval, AwaitingApproval } from './modal/mytaskremainder';
import { TypeaheadMatch } from 'ngx-bootstrap/typeahead';
import { SharedService } from 'src/app/finance/services/shared.service';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
//import {  distinctUntilChanged, switchMap, debounceTime } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { MessageService } from 'src/app/core/message/service/message.service';
import { UserAutherizationService } from 'src/app/core/authorization/userauth.service';
import { AlertService } from '../shared/alert-rsa/alert.service';
import { AuthService } from 'src/app/core/guard/services/auth.service';
import { RSAConstants } from 'src/app/core/constants/rsaconstant';
import { MatchUnMatchService } from '../finance/search/service/match-unmatch.service';
import { validateEmail } from '../shared/utilites/helper';
import { MonthEndDate } from '../shared/model/monthend';

@Component({
  selector: 'rsa-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  userdata: any = { 'welcomeMsg': 'HELLO!', 'msg1': 'what do you want to do', 'msg2': 'today?' };
  categorydata: any;
  activityData: Activity[];
  category: number;
  categoryItem: string;
  searchval = '';
  noResult;
  noTransaction = true;
  entitysearchlist: any[] = [];
  pendingApprovals: PendingApproval[] = [];
  drafts: Draft[] = [];
  unApproved: Unapproved[] = [];
  awaitingApproval: AwaitingApproval[] = [];
  invalidsearch = true;
  lobData: any = [];
  opentasks: number;
  username: string;
  entitySerachId;
  entitySerachType;
  entitySerachItem;
  titleText = 'Please select the LOB before selecting category';
  categoryselectedValue = 'Select Category';
  lobvalue = 'Select LOB';
  lob: number;
  lobItem: string;
  isVewedEnable = true;
  isDisabled = true;
  TaskCount: any;
  searchForm: FormGroup;
  errorMsg: string;
  predictiveResultLists: any = [];
  searchformfld: any;
  selectedResult: any;
  noPayeeName = true;
  resultData: any = [];
  successmsg: any;
  errorMsgEmail: any;
  isSearch: boolean;
  isTask: boolean;
  isDraft: boolean;
  isUnapprove: boolean;
  isReminder: boolean;
  examplefrom: FormGroup;
  value;
  enterKey = false;
  isAuthorized: boolean;
  isLocalAuthData: boolean;
  menucnt: number;
  selectedPayeeNameObj: any = [];
  entityUnMatchedorClaim: any;

  constructor(private messageService: MessageService, private allowAccess: UserAutherizationService,
    private searchService: SearchService, private homeservice: HomeService,
    private route: ActivatedRoute,
    private router: Router, private fb: FormBuilder, private alertService: AlertService,
    private _auth: AuthService, private matchUnMatchService: MatchUnMatchService) { }

  ngOnInit() {
    this.getmatchedOrCliamData();
    this.messageService.getMessage().subscribe((data) => {
      if (data != null || data != undefined) {
        this.isAuthorized = data.isAuthorized;
        if (this.isAuthorized) {
          this.getActivity();
          this.loadAuthorizationFunction();
          this.lobvalue = 'Select LOB';
          this.categoryselectedValue = 'Select Category';
          this.setLobDefaultsAccts();
          this.isVewedEnable = false;
        }

        // else
        // this.router.navigate(['accessdenied']);
      }
    });

    this.isLocalAuthData = (localStorage.getItem('isAuthorized')) ? true : false;
    if (this.isLocalAuthData) {
      this.loadAuthorizationFunction();

    }
    console.log("calling msg service in home component" + (localStorage.getItem('isAuthorized')));

    this.getCategorydataData();
    this.getActivity(); // fix for blank Activity section
    this.getMyTaskAndRemainder();
    this.getUserData();
    this.getLobData();
    this.getDraftCount();
    this.getMonthEndDate();
    this.predictiveResultLists = Observable.create((observer: any) => {
      const param = {
        category: this.category,
        classCode: this.lob,
        locationcode: localStorage.getItem('locationcode'),
      };
      const searchParam = this.searchformfld;
      console.log(this.category, 'this.category');
      if (this.category == 1) {
        param['policyNo'] = searchParam.trim();
      } else if (this.category == 10) {
        param['quoNo'] = searchParam.trim();
      } else if (this.category == 8) {
        param['claimNo'] = searchParam;
      } else if (this.category == 6) {
        param['taxInvoiceNo'] = searchParam.trim();
      } else if (this.category == 11) {
        param['payeeName'] = this.searchval;
      }
      if (this.category == 12) {
        param['chequeNo'] = searchParam;
      } else if (this.category == 5) {
        param['creditNoteNo'] = searchParam;
      }

      console.log(param, 'param');
      if (this.validateSearchLength()) {
        this.searchService.getPredictiveSearchList(param).subscribe((result: any) => {
          console.log(result, 'res');
          this.invalidsearch = true;
          this.resultData = result;
          observer.next(result);
        });
      }
    });

    console.log(this.predictiveResultLists, 'predictiveResultLists');
    this.getAsyncDataEntitysearchlist();
  }

  loadAuthorizationFunction() {
    this.isSearch = this.displayHomeItem(200);
    this.isTask = (this.displayHomeItem(260) ||
      this.displayHomeItem(261) ||
      this.displayHomeItem(262) ||
      this.displayHomeItem(263) ||
      this.displayHomeItem(264));
    this.isDraft = (this.displayHomeItem(265) || this.displayHomeItem(266));
    this.isUnapprove = this.displayHomeItem(267);
    this.isReminder = this.displayHomeItem(270);
    localStorage.setItem('isAuthorized', 'true');

    let menuItems = JSON.parse(localStorage.getItem(RSAConstants.allowedTasklists));
    this.isMenuEmpty(menuItems);

    // this.menucnt = menuItems.length;

  }

  isMenuEmpty(menuItems) {

    let menucnt = 0;
    console.log('menuItems>>>>>', menuItems);
    menuItems.forEach(item => {
      if (this.allowAccess.isAllowed(item.menuid))
        menucnt++;
    });
    this.menucnt = menucnt;
    console.log(this.menucnt, 'this.menucnt');
  }
  getAsyncDataEntitysearchlist() {
    this.entitysearchlist = Observable.create((observer: any) => {
      if (this.category == 4) {
        this.homeservice.getEntitySearchListData(this.searchval)
          .subscribe((searchlistdata) => {
            this.invalidsearch = true;
            if (searchlistdata) {
              console.log(searchlistdata, 'serass-obser');
              const data = searchlistdata.sort((one, two) => (one.entityType < two.entityType ? -1 : 1));
              observer.next(data);
            }
          });
      }
    });
  }

  getCategorydataData(): void {
    this.homeservice.getCategoryData().subscribe((dropDowndata) => {
      this.categorydata = dropDowndata;
      //  console.log(dropDowndata, 'dropdowndata');
    });
  }

  getLobData(): void {
    this.homeservice.getLobDataList().subscribe((data) => {
      this.lobData = data;
      //console.log(data, 'data');
    });
  }

  typeaheadNoResults(event: boolean): void {
    console.log(event, 'noresul;t');
    if (this.searchval.length > 0) {
      this.noResult = event;
    } else {
      this.noResult = false;
    }

    if (event) {
      this.invalidsearch = true;
    }
  }

  typeaheadNoTransactions(event: boolean): void {
    console.log(event, 'eventflag');
    if (this.searchformfld.length > 0) {
      this.noTransaction = !event;
    } else {
      this.noTransaction = true;
    }

    if (event) {
      this.invalidsearch = true;
    }
    this.selectedResult = '';
  }
  typeaheadNoPayeeName(event: boolean): void {
    console.log(event, 'eventflagpayeename');
    if (this.searchval.length > 0) {
      this.noPayeeName = !event;
    } else {
      this.noPayeeName = true;
    }

    if (event) {
      this.invalidsearch = true;
    }
    this.selectedResult = '';
  }
  getDraftCount() {
    var param = 'loggedInUserId=33';
    this.homeservice.getDraftCount(param).subscribe((data) => {
      this.TaskCount = data;
      console.log(data, 'draftdata');
    });
  }


  displayCheckedItem(activity: Activity) {
    this.activityData.forEach(item => {
      if (item.item === activity.item) {
        item.isChecked = activity.isChecked;

      }
    });
  }

  getActivity(): void {
    this.activityData = this.homeservice.populateDropDown();
  }
  getMyTaskAndRemainder(): void {
    this.homeservice.getMyTaskRemainder().subscribe((mytaskremainder: MytaskRemainder) => {
      this.pendingApprovals = mytaskremainder.Mytask.PendingApprovals;
      this.drafts = mytaskremainder.Mytask.Drafts;
      this.unApproved = mytaskremainder.Mytask.Unapproved;
      this.awaitingApproval = mytaskremainder.Reminders.AwaitingApprovals;

    });
  }
  typeaheadOnSelect(typeheadobj: TypeaheadMatch): void {
    console.log('Selected value: ', typeheadobj);
    this.entitySerachId = typeheadobj.item.id;
    this.entitySerachType = typeheadobj.item.entityEnum;
    this.entitySerachItem = typeheadobj.item.name;
    if (this.category == 4 && this.enterKey) {
      this.search();
    }
  }
  selectPredictiveSearch(typeheadobj: TypeaheadMatch): void {
    console.log(typeheadobj, " typeheadobj 255");
    if (this.category == 11 || this.category == 12) {
      this.selectedPayeeNameObj = typeheadobj;
    }
    this.selectedResult = typeheadobj.item.No || typeheadobj.item.Name;
    this.searchval = this.selectedResult;
    console.log('this.searchval>>>', this.searchval);
    this.noTransaction = true;
    this.noPayeeName = true;
  }
  setCategory(category: CategoryType) {
    this.category = category.id;
    this.categoryItem = category.item;
    this.categoryselectedValue = category.item;
    this.searchval = '';
    this.searchformfld = '';
    this.selectedResult = '';
    this.noResult = false;
    this.noTransaction = true;
    this.noPayeeName = true;
    this.invalidsearch = true;
  }

  setLobDefaults() {
    this.categorydata = [
      { id: 1, item: 'Policy No' },
      { id: 8, item: 'Claim No' },
      { id: 10, item: 'Quotation No' }
    ];
    this.isVewedEnable = false;
  }

  setLobDefaultsAccts() {
    this.categorydata = [
      { id: 2, item: 'Receipt No', menuid: 201 },
      { id: 3, item: 'Payment No', menuid: 202 },
      { id: 14, item: 'Claim Payment' },
      { id: 4, item: 'Entity', menuid: 203 },
      { id: 5, item: 'Credit Note No' },
      { id: 6, item: 'Tax Invoice No' },
      { id: 7, item: 'Journal No' },
      { id: 11, item: 'Payee Name' },
      { id: 12, item: 'Cheque No' },
      { id: 13, item: 'Approval Code', menuid: 203 }
    ];

  }

  setLob(lob: CategoryType) {
    this.lob = lob.id;
    this.lobItem = lob.item;
    this.searchformfld = '';
    this.selectedResult = '';
    this.searchval = '';
    this.titleText = '';
    this.isDisabled = false;
    this.noResult = false;
    this.noTransaction = true;
    this.noPayeeName = true;
    this.lobvalue = lob.item;
    this.invalidsearch = true;
    if (lob.id == 0) {
      this.categoryselectedValue = 'Select Category';
      this.setLobDefaultsAccts();
      this.isVewedEnable = true;
    } else {
      this.categoryselectedValue = 'select category';
      this.setLobDefaults();
    }

  }

  searchEntity(obj) {
    console.log(this.searchformfld, ' searchformfld ', obj);
    let typeheadobj1: TypeaheadMatch;
    if (obj.keyCode === 13) {
      this.enterKey = true;
      typeheadobj1 = obj;
      // this.searchformfld = typeheadobj1.item.name;
      this.searchformfld = obj.srcElement.value;
    } else {
      this.enterKey = false;
      this.search();
    }
  }

  search() {
    if (this.category == 4 && this.noResult) {
      return false;
    }
    if (this.category == 11 && !this.noPayeeName) {
      return false;
    }
    if (this.category == 11 && this.noPayeeName) {
      console.log(this.selectedPayeeNameObj, 'this.selectedPayeeNameObj');
      const transactionType = this.selectedPayeeNameObj.item ? this.selectedPayeeNameObj.item.TransactionType : null;
      switch (transactionType) {
        case 'Payment': { // directing to Payment No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.entitySerachItem = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Payment No';
          this.category = 3;
          break;
        }
        case 'RECEIPT': { // directing to Receipt No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Receipt No';
          this.category = 2;
          break;
        }
        case 'Claim Payment': { // directing to Claim Payment No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Claim Payment';
          this.category = 14;
          break;
        }
        default: {
          this.category = 11;
          break;
        }
      }
    }
    if (this.category == 12) { // Search Cheque Number
      console.log(this.selectedPayeeNameObj, 'this.selectedPayeeNameObj');
      const transactionType = this.selectedPayeeNameObj.item ? this.selectedPayeeNameObj.item.TransactionType : null;
      switch (transactionType) {
        case 'Payment': { // directing to Payment No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.entitySerachItem = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Payment No';
          this.category = 3;
          break;
        }
        case 'Receipt': { // directing to Receipt No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Receipt No';
          this.category = 2;
          break;
        }
        case 'Claim Payment': { // directing to Claim Payment No search
          this.searchval = this.selectedPayeeNameObj.item.VoucherNo;
          this.categoryItem = 'Claim Payment';
          this.category = 14;
          break;
        }
        default: {
          this.category = 12;
          break;
        }
      }
    }

    if (this.category == 2 || this.category == 3 || this.category == 14 || this.category == 7 || this.category == 13) {
      this.checkResultsData();
      return false;
    }
    if ((this.category == 1 || this.category == 5 || this.category == 8 || this.category == 10 || this.category == 6)
      && !this.noTransaction) {
      return false;

    }

    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.lob !== undefined) &&
      ((this.searchformfld !== undefined && this.searchformfld !== '' && this.searchformfld.toString().length > 0) || (this.searchval !== undefined && this.searchval !== '' && this.searchval.toString().length > 0));
    console.log("invalid search", this.invalidsearch);
    if (this.invalidsearch) {
      let params;
      if (this.category == 4) { //searchval
        if (this.entitySerachId == undefined || this.entitySerachId == '') {
          // this.invalidsearch = false;
          return false;
        }
        params = {
          'id': this.entitySerachId,
          'entityType': this.entitySerachType,
          'entityUnMatched': this.entityUnMatchedorClaim || 0,
          'categoryType': this.category,
          'entitySerachItem': this.entitySerachItem,
          'isFromHome': 'true',//For clearing localstorage in entity page.
        };
      } else {
        if ((this.category == 11 || this.category == 1 || this.category == 5 || this.category == 6 || this.category == 8 ||
          this.category == 10 || this.category == 12) && (this.selectedResult == undefined || this.selectedResult == '' ||
            this.selectedResult == null)) {
          return false;
        }
        params = {
          'inputData': (this.searchval !== undefined && this.searchval !== '' && this.searchval.toString().length > 0) ? this.searchval : this.searchformfld,
          'category': this.category,
          'categoryitem': this.categoryItem,
          'classCode': this.lob,
          'lobitem': this.lobItem,
          'isFromHome': 'true',//For clearing localstorage in policy page.
        };
      }
      this.router.navigate(['home/search/result'], {
        queryParams: params
      });
    }
  }

  opentasksList(ev: number) {
    this.opentasks = (this.opentasks === ev) ? -1 : ev;
    this.getDraftCount();
  }


  viewDrfat(draft) {
    console.log(draft, 'val');
    const params = {
      'totalCount': draft.TaskCount,
      'voucherName': draft.TaskName,
    };
    console.log(params);
    this.router.navigate(['home/search/draft'], {
      queryParams: params
    });
  }

  viewPendingApproval(pendingapproval) {
    //console.log(pendingapproval, 'val');
    const params = {
      'totalCount': pendingapproval.TaskCount,
      'voucherName': pendingapproval.TaskName,
    };
    //console.log(params);
    this.router.navigate(['home/search/pendingapproval'], {
      queryParams: params
    });
  }
  viewUnApproval(unApproved) {
    //console.log(pendingapproval, 'val');
    const params = {
      'totalCount': unApproved.TaskCount,
      'voucherName': unApproved.TaskName,
    };
    //console.log(params);
    this.router.navigate(['home/search/unapproved'], {
      queryParams: params
    });

  }

  getUserData(): void {
    this.homeservice.getUserInfo().subscribe((data) => {
      if (window.localStorage) {
        const accountingCode = localStorage.getItem('accountingCode');
        // localStorage.clear();
        for (const prop in data) {
          if (prop != 'locationcode') {
            if ((data[prop]) instanceof Array) {
              localStorage.setItem(prop, JSON.stringify(data[prop]));
            } else {
              localStorage.setItem(prop, data[prop]);
            }
          }
        }
        if (accountingCode) {
          localStorage.setItem('accountingCode', accountingCode);
        }
      }
      this.username = this._auth.getUserName();

      //this.username = localStorage.getItem('firstname') + ' ' + localStorage.getItem('lastname');

    },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  lookUpChange(e) {
    if (e.srcElement.value.length >= 2) {
      // this.getEntitySearchListData(e.srcElement.value);
    } else {
      this.entitysearchlist = [];
    }
    this.invalidsearch = true;
  }
  // defect 1126- Need to show No transaction found message  without predicticve search
  checkResultsData() {
    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.lob !== undefined) && ((this.searchval !== undefined && this.searchval !== '' && this.searchval.toString().length > 0));
    this.noTransaction = true;
    if (this.invalidsearch) {
      let params;
      params = {
        'inputData': this.searchval,
        'categoryitem': this.categoryItem,
        'category': this.category
      };
      this.searchService.checkSearchResult(params).subscribe(
        dataReturn => {
          if (dataReturn !== null && dataReturn !== undefined) {
            params = {
              'inputData': this.searchval,
              'category': this.category,
              'categoryitem': this.categoryItem,
              'classCode': this.lob,
              'lobitem': this.lobItem
            };
            this.router.navigate(['home/search/result'], {
              queryParams: params
            });
            this.noTransaction = true;
          } else {
            this.noTransaction = false;
          }
        }
      );
    }
  }
  validateSearchLength() {
    if (this.category == 11) {
      return (this.searchval == undefined || this.searchval.length < 3) ? false : true;
    }
    if (this.category == 1 || this.category == 5 || this.category == 10 || this.category == 8
      || this.category == 6 || this.category == 12) {
      return (this.searchformfld == undefined || this.searchformfld.length < 3) ? false : true;
    }
    return true;
  }
  displayHomeItem(functionid) {
    return this.allowAccess.isAllowed(functionid)
  }

  displayApprovalItem(taskName) {
    let tasks = {
      'Receipts': 260,
      'Payments': 261,
      'JV': 262,
      'Credit Note': 263,
      'Debit Note': 264

    }
    let functionidVal = tasks[taskName];
    //console.log('functionidVal>>>>',functionidVal);
    return this.displayHomeItem(parseInt(functionidVal));
  }

  sendRemainderEmail(userobj) {
    console.log(userobj, 'params');
    const email = userobj.EmailId;
    const toUserID = userobj.UserId;
    // const loggedInUserID = userobj.ToUserID;
    const userName = userobj.UserName;
    const param = {
      ToEmailID: email,
      LoggedInUserID: 1,
      ToUserID: toUserID,
      UserName: userName
    };
    if (email && !validateEmail(email)) {
      this.alertService.info('Email ID not valid for this User');
      return false;
    }
    if (email && validateEmail(email)) {
      console.log(param, 'param');
      this.homeservice.sendEmailReminder(param).subscribe(data => {
        console.log(data, 'data');
        this.successmsg = data;
        this.alertService.success(data);
      },
        errorRturn => {
          this.errorMsgEmail = errorRturn;
          this.alertService.info(this.errorMsgEmail);
        }
      );
    } else {
      this.errorMsgEmail = 'Email ID is not available for this User';
      this.alertService.info(this.errorMsgEmail);
    }
  }
  displayUserName() {
    return this._auth.getUserName();
  }

  getmatchedOrCliamData(): void {
    this.matchUnMatchService.getMatchUnMatchObserable().subscribe((res) => {
      this.entityUnMatchedorClaim = res.id;
      console.log('entityUnMatchedorClaim', this.entityUnMatchedorClaim);
    });
  }

  getMonthEndDate(): void {
    this.homeservice.getMonthEndDate('Accounts').subscribe((monthEndDate: MonthEndDate) => {
        console.log(monthEndDate);
        if(monthEndDate.Success && monthEndDate.isReqNxtMnthStrtDt){
          localStorage.setItem('tranAccntMnthStrtDate', monthEndDate.NextMonthStartDate.toString());
        }
    });
    //localStorage.setItem('tranAccntMnthStrtDate', "2019-04-01T00:00:00");
  }
}
