import { Injectable } from '@angular/core';
import { map, catchError, shareReplay } from 'rxjs/operators';

import { RSAENDPOINTConstants } from '../../core/constants/rsa.api.end.points';

import { Observable, of } from 'rxjs';
import { Area } from '../../shared/model/location';
import { UserProfile } from '../../shared/model/userprofile';
import { EntityTypeHead } from '../modal/entitytypehead';
import { SideNavRouteInfo } from '../modal/sidenav';
import { handleErrorObservable } from '../../shared/utilites/helper';
import { FoldMenu } from '../modal/foldmenu';
import { MytaskRemainder } from '../modal/mytaskremainder';
import { HttpHeaders, HttpErrorResponse, HttpClient, HttpParams } from '@angular/common/http';
//import { HttpParams } from '@angular/common/http';
import { CustomHttpParams } from 'src/app/core/interceptor/loader-interceptor';
import { MonthEndDate } from '../../shared/model/monthend';
@Injectable({
    providedIn: 'root'
})
export class HomeService {

    private cachedcategory: Observable<any>;
    private cachedLob: Observable<any>;
    private cachedentity: Observable<any>;
    private cachedarea: Observable<any>;
    private cachedcity: Observable<any>;
    private cachedTaskreaminder: Observable<any>;

    constructor(private http: HttpClient) {
    }

    // generateLeftMenu(): any {
    //     return JSON.parse(localStorage.getItem("allowedMenuitems"));
    // }


    populateDropDown(): any {
        if(window.localStorage)
        return JSON.parse(localStorage.getItem("allowedTasklists"));
       
    }

    getAreaData(): Observable<any> {
        return this.http.get<Area>(RSAENDPOINTConstants.AREA).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getAreaData')));
    }



    getCategoryList(): Observable<any> {
        return this.http.get<FoldMenu>(RSAENDPOINTConstants.CATEGORY).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getCategoryList')));
    }

    getEntitySearchListData(queryString: string): Observable<EntityTypeHead[]> {
        return this.http.get<EntityTypeHead[]>(RSAENDPOINTConstants.SEARCH_API_ADMIN_ENTITY_DROPDOWN + '&searchName=' + queryString).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getEntitySearchListData')));
    }
    getMyTaskRemainder(): Observable<MytaskRemainder> {
        const fakeurl = RSAENDPOINTConstants.MYTASKREMAINDER;
        const url = RSAENDPOINTConstants.SERVERAPI_MYTASK_REMINDER;
        return this.http.get<MytaskRemainder>(url).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMyTaskRemainder')));
    }
    getDraftCount(param){
           return this.http.get(RSAENDPOINTConstants.DRAFT_COUNT + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getDraftCount')));


    }

    getCategoryData() {
        if (!this.cachedcategory) {
            this.cachedcategory = this.getCategoryList().pipe(shareReplay(1));
        }
        return this.cachedcategory;
    }

    getArea() {
        if (!this.cachedarea) {
            this.cachedarea = this.getAreaData().pipe(shareReplay(1));
        }
        return this.cachedarea;
    }
    getUserData(): Observable<any> {
        return this.http.get<UserProfile>(RSAENDPOINTConstants.USERPROFILE).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getUserData')));
    }
    getUserInfo() {
        if (!this.cachedcity) {
            this.cachedcity = this.getUserData().pipe(shareReplay(1));
        }
        return this.cachedcity;
    }

    getLobData(): Observable<any> {
        return this.http.get<FoldMenu>(RSAENDPOINTConstants.LOB).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getLobData')));
    }

    getLobDataList(): Observable<any> {
        if (!this.cachedLob) {
            this.cachedLob = this.getLobData().pipe(shareReplay(1));
        }
        return this.cachedLob;
    }
    getMyTaskRemainderData(): Observable<any> {
        if (!this.cachedTaskreaminder) {
            this.cachedTaskreaminder = this.getMyTaskRemainder().pipe(shareReplay(1));
        }
        return this.cachedTaskreaminder;
    }

    sendEmailReminder(param) {
        console.log(param, 'paramsssss...');
        const body = JSON.stringify(param);
        const url = RSAENDPOINTConstants.REMINDEREMAIL;
        console.log(url, 'url');
        return this.http.post<any>(url, body).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('saveReceipt')));
    }
    getMonthEndDate(param): Observable<MonthEndDate> {
        const url = RSAENDPOINTConstants.MONTHENDSETTING;
        return this.http.get<MonthEndDate>(url + '/GetMonthEndDateByModule?Module=' + param).pipe(
            map(res => res),
            catchError(handleErrorObservable<any>('getMonthEndDate')));
    }

}
