export var MIME_TYPE = 'application/x-dnd';
export var EDGE_MIME_TYPE = 'application/json';
export var MSIE_MIME_TYPE = 'Text';
export var ALL_EFFECTS = ['move', 'copy', 'link'];
//# sourceMappingURL=constants.js.map