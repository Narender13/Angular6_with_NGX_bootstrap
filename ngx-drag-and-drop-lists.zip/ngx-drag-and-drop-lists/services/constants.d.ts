export declare const MIME_TYPE: string;
export declare const EDGE_MIME_TYPE: string;
export declare const MSIE_MIME_TYPE: string;
export declare const ALL_EFFECTS: Effects[];
export declare type Effects = 'move' | 'copy' | 'link';
