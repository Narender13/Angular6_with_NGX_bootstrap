export declare class DndListModule {
}
